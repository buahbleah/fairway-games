# Cutover runbook

Goal:

```
fairway.games          →  this marketing site
fairway.games/play/    →  the game web app (unchanged, just proxied)
fairway.games/api/     →  the app's API (unchanged, just proxied)
```

Nothing in the app repository has to change. The app keeps its own Vercel
project and its own `*.vercel.app` address; this site simply owns the domain and
passes `/play` and `/api` through to it.

Work top to bottom. Steps 1–4 are safe — the live site is untouched until
step 5.

---

## 1 · Undo the bad link (2 min)

The earlier `vercel` run attached this folder to the **app's** project, which is
why it failed looking for `dist/`.

```powershell
cd "C:\Projekte\fairway games"
Remove-Item -Recurse -Force .vercel
Remove-Item -Force .env.local
```

`.env.local` holds the app project's development variables, including the Neon
`DATABASE_URL`. It is gitignored so nothing leaked, but this site has no use for
a live database credential.

Rename the folder so the CLI stops suggesting the app's project name:

```powershell
cd C:\Projekte
Rename-Item "fairway games" "fairway-web"
```

---

## 2 · Create a separate project (5 min)

```powershell
cd C:\Projekte\fairway-web
npm install
npx vercel --scope phils-projects-a6db7377
```

| Question | Answer |
| --- | --- |
| Set up and deploy? | `y` |
| Link to existing project? | **`n`** ← the step that went wrong last time |
| Project name | `fairway-web` |
| In which directory is your code? | `./` |
| Modify these settings? | `n` |

It prints a preview URL. **Open it and click around** — the whole site should
work apart from `/play`, which 404s until step 3.

---

## 3 · Set the environment variables (3 min)

**Vercel → fairway-web → Settings → Environment Variables.** Add all three to
Production, Preview and Development:

| Name | Value |
| --- | --- |
| `NEXT_PUBLIC_SITE_URL` | `https://www.fairway.games` |
| `NEXT_PUBLIC_APP_URL` | `https://www.fairway.games/play/` |
| `APP_ORIGIN` | `https://fairway-games-phils-projects-a6db7377.vercel.app` |

`APP_ORIGIN` must be the app project's **stable production alias**, not a
per-deployment URL — a deployment URL would pin `/play` to one frozen build for
ever. Confirm the alias serves the app before you paste it:

```powershell
curl.exe -I https://fairway-games-phils-projects-a6db7377.vercel.app/api/ping
```

Then redeploy so the variables take effect:

```powershell
npx vercel --prod --scope phils-projects-a6db7377
```

---

## 4 · Test the proxy on the Vercel URL (5 min)

Before touching DNS, everything is testable on `fairway-web-….vercel.app`:

| Check | Expected |
| --- | --- |
| `/` | the marketing site |
| `/play/` | the app loads, styled, no console errors |
| `/play` | redirects to `/play/` |
| `/api/ping` | the app's API answers |
| sign in at `/play/`, then reload | still signed in |

If `/play/` loads but is unstyled, the assets are 404ing — check you kept the
trailing slash. That is the one failure mode this setup has, and it is why every
link on the site points at `/play/`.

**Do not go past this step until all five pass.**

---

## 5 · Move the domain (5 min, this is the live change)

**Vercel → fairway-web → Settings → Domains → Add.**

Add `fairway.games`. Vercel will notice it is attached to the `fairway-games`
project and offer to move it — accept. Repeat for `www.fairway.games`.

Moving it this way means there is no window where the domain points at nothing.
Do **not** remove it from the app project first.

Pick one as primary and let Vercel redirect the other. The site is configured
for `www` as canonical; if you would rather the bare domain be primary, change
`NEXT_PUBLIC_SITE_URL` to `https://fairway.games` and redeploy — that one
variable drives every canonical tag, the sitemap, the OpenGraph URLs and the QR
code.

The app project keeps working on its `*.vercel.app` address throughout, which is
also what the Android build talks to. **No new AAB is needed.**

---

## 6 · Right after the switch (5 min)

Run through the same five checks on the real domain, then two more that only
matter on this domain:

**a. The old service worker.** Every browser that ever opened the app at the
root of this domain has its service worker registered at scope `/`. Left alone
it would keep serving the app's cached shell instead of your website. This site
ships a kill-switch worker at `/sw.js` that clears the caches and unregisters
itself — one visit and the old one is gone.

Test it on a browser that used the old app:

1. Open `https://fairway.games`
2. DevTools → Application → Service Workers
3. It should show the new worker briefly, then **no registration at all**
4. Reload — the marketing site, not the app

**b. Old home-screen icons.** Anyone who used Add to Home Screen before the move
has an icon whose start URL is `/`. The site detects a standalone launch on the
home page and sends it to `/play/`, so those icons keep opening the app. Worth
testing on a phone that has one.

---

## 7 · Tell Google (5 min)

- Search Console → add `fairway.games` if it is not there
- Submit `https://www.fairway.games/sitemap.xml`
- Check `/games/wolf` in the Rich Results Test — FAQPage and BreadcrumbList
  should both be detected

Re-run the audits against the live site:

```powershell
node qa.mjs https://www.fairway.games
node a11y.mjs https://www.fairway.games
node perf.mjs https://www.fairway.games
```

---

## 8 · Then, separately: lock `/play` to the store version

Not part of the cutover — do it once the domain is settled.

By default the app's production deploys follow `main`, so `/play` will run ahead
of whatever is in Play. Making them match is one Vercel setting plus three lines
in the release workflow. **`PLAY-ROUTE.md`** has it.

---

## If something goes wrong

The move is reversible in about a minute: **Vercel → fairway-games → Settings →
Domains → Add `fairway.games`**, and it moves back. The app project is never
modified during any of this, so there is nothing to restore.

The one thing that outlives a rollback is the kill-switch service worker on
browsers that already fetched it — but all that did was unregister the old
worker, and the app re-registers its own on the next visit. No harm either way.
