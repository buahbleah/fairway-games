# Deploying this site — two commands

The site is built and verified. It has never been deployed from the build
environment because that has no Vercel credentials, so the first deploy is
yours. It takes about a minute.

## ⚠ If you already ran `vercel` and got "No Output Directory named dist"

That error means the CLI linked this folder to your **existing `fairway-games`
project — the one that hosts the app**. It offered `fairway-games` because that
is what your folder name (`fairway games`) normalises to, and you accepted.

That project is configured for the Vite app: `vercel.json` there sets
`outputDirectory: dist`. Next.js does not produce a `dist/`, so the build
failed. The build failing is lucky — had it succeeded it would have published
this marketing site over the app's deployments.

Two things to clean up:

```powershell
cd "C:\Projekte\fairway games"
Remove-Item -Recurse -Force .vercel      # unlink from the app's project
Remove-Item -Force .env.local            # see the note below
```

`vercel` also pulled the app project's **development environment variables**
into `.env.local` — that will include the Neon `DATABASE_URL`. It is gitignored,
so nothing leaked, but this site has no use for a live database credential.
Delete it.

Then deploy again into a **new, separate project**:

```powershell
npx vercel --scope phils-projects-a6db7377
```

and answer:

| Question | Answer |
| --- | --- |
| Set up and deploy? | `y` |
| Link to existing project? | **`n`** ← this is the one that went wrong |
| What's your project's name? | `fairway-web` |
| In which directory is your code? | `./` |
| Want to modify these settings? | `n` (it detects Next.js correctly) |

Renaming the folder to `fairway-web` first will stop the CLI suggesting the
app's project name again.

Then promote it:

```powershell
npx vercel --prod --scope phils-projects-a6db7377
```

## Option A — Vercel CLI (fresh start)

From this folder:

```bash
npm install
npx vercel --scope phils-projects-a6db7377
```

Answer **no** to "Link to existing project" and name it `fairway-web`. It
detects Next.js and builds. Then `npx vercel --prod --scope phils-projects-a6db7377`.

## Option B — Git (better long-term)

Push this folder to a repository, then import it at
[vercel.com/new](https://vercel.com/new). Every push to `main` redeploys.

## Environment variables — set these before the domain goes live

**Vercel → the project → Settings → Environment Variables**

| Name | Value | Why |
| --- | --- | --- |
| `NEXT_PUBLIC_SITE_URL` | `https://www.fairway.games` | Canonicals, OpenGraph URLs, the sitemap and the QR code. Without it they point at the `*.vercel.app` preview domain. |
| `NEXT_PUBLIC_APP_URL` | `https://www.fairway.games/play` | Where the iPhone / "open the web app" buttons go. |
| `APP_ORIGIN` | `https://fairway-games-phils-projects-a6db7377.vercel.app` | Turns on the `/play` → app proxy and keeps `/api` first-party. Leave unset until you move the domain. See **PLAY-ROUTE.md**. |

## The domain

Right now `www.fairway.games` serves the **app**. The plan you described is:

- `www.fairway.games` → this marketing site
- `www.fairway.games/play` → the app

So move the domain to this project and set `APP_ORIGIN` to the app project's
production alias. The rewrites in `next.config.ts` then proxy `/play/` and
`/api/` straight back to it.

**Good news: the app needs no changes.** It already builds with `base: './'`
and a relative manifest `scope`, so it works under a subpath as-is.

**PLAY-ROUTE.md** covers this in full, including how to make `/play` always
serve the same build that is live in the Play Store — which does not happen
automatically and needs one Vercel setting plus three lines in your release
workflow.

## After the first deploy

- Submit `https://www.fairway.games/sitemap.xml` in Google Search Console.
- Check `/games/wolf` in the Rich Results Test — FAQPage and BreadcrumbList
  should both be detected.
- Re-run the audits against the live URL:

```bash
node qa.mjs https://www.fairway.games
node a11y.mjs https://www.fairway.games
node perf.mjs https://www.fairway.games
```
