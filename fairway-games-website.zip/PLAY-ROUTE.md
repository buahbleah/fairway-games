# Keeping `/play` identical to the Play Store build

You asked how to guarantee that `www.fairway.games/play` always serves the same
version of the app that is live in Google Play.

**It does not happen by itself, and by default it is guaranteed *not* to.**
Right now the app's Vercel project deploys production on every push to `main`,
while Play only changes when you upload a new bundle. So the web is always
ahead. Making them match means giving them a single trigger.

---

## The mechanism: one branch decides both

```
                    ┌──────────────────────────────┐
   push to main ───►│ Vercel: Preview deployment   │  (not /play)
                    └──────────────────────────────┘

   "Play Store release" workflow
        │
        ├─ npm test, npm run build   ──►  dist/
        ├─ npx cap sync android      ──►  app-release.aab   ──► Play Console
        └─ fast-forward `release` branch
                    │
                    ▼
                    ┌──────────────────────────────┐
                    │ Vercel: Production           │  ◄── /play proxies here
                    └──────────────────────────────┘
```

One commit produces the AAB *and* the production web deployment, so the two
cannot drift.

### Step 1 — stop `main` deploying to production

In the **app** project on Vercel: **Settings → Git → Production Branch**, change
`main` to `release`.

From then on, pushes to `main` build previews only. Nothing reaches `/play`
until `release` moves.

### Step 2 — create the branch, pointing at what is live now

```bash
cd C:\Projekte\golf
git checkout -b release
git push -u origin release
```

### Step 3 — let the release workflow move it

Add this as the last step of `.github/workflows/release.yml`, after
**"Upload the bundle"**:

```yaml
      # The AAB is built and signed. The exact same commit now becomes the
      # production web deployment, so www.fairway.games/play and the Play Store
      # build are the same code.
      - name: Point the release branch at this commit
        run: |
          git config user.name "github-actions[bot]"
          git config user.email "github-actions[bot]@users.noreply.github.com"
          git push origin HEAD:release
```

and give the job permission to push, directly under `runs-on`:

```yaml
    permissions:
      contents: write
```

That is the whole change. Run **Actions → Play Store release**, upload the AAB
it produces, and `/play` is already serving the matching build.

### Step 4 — make the match visible

Right now you cannot tell by looking. Stamp the version into the web build so
you can check it in two seconds.

In `release.yml`, change the build step:

```yaml
      - run: npm run build
        env:
          VITE_APP_VERSION: ${{ inputs.versionName }}
```

Then show it somewhere in the app — the Settings screen is the natural place:

```ts
const version = import.meta.env.VITE_APP_VERSION ?? 'dev'
```

Open `/play`, open Settings, and the version there should equal the one in Play
Console. If it does not, something skipped a step.

---

## The honest caveat

This ties `/play` to **the release you cut**, not to **whatever Google is
currently serving**. Between building the AAB and Google finishing the rollout —
a review, a staged rollout, testers on an older version — the web can be a
version ahead.

For most groups that is fine and arguably what you want: the web should not be
stale. If you need them *exactly* aligned, move the branch by hand at the moment
you promote in Play Console instead:

```bash
git push origin <the-released-commit>:release --force
```

Or split it into its own one-click workflow so you never have to remember the
commit:

```yaml
name: Promote web to match the store

on:
  workflow_dispatch:
    inputs:
      sha:
        description: 'Commit that is live in Play Console'
        required: true

jobs:
  promote:
    runs-on: ubuntu-latest
    permissions:
      contents: write
    steps:
      - uses: actions/checkout@v4
        with: { fetch-depth: 0 }
      - run: git push origin ${{ inputs.sha }}:release --force
```

---

## Why a proxy, and not a redirect

`/play` is a Vercel **rewrite**, not a redirect: the URL stays
`www.fairway.games/play/` and the app is served through it. That costs a little
configuration and buys three things a redirect would not:

- **The session cookie is first-party.** `/api` is proxied to the app under the
  same domain, so the browser is not handling a cross-site cookie — which
  Safari's ITP would eventually break.
- **One domain in the store listing, the QR code and every share.** No
  second hostname for anyone to be confused by.
- **The Android app is unaffected.** It talks to `VITE_API_ORIGIN` absolutely
  with a bearer token, exactly as before. Nothing about the native path changes.

Three details make the proxy work, all in `next.config.ts` with the reasoning
written next to each:

1. **The trailing slash.** The Vite build uses `base: './'`, so `/play` without
   a slash resolves every asset against the site root and 404s. `/play`
   redirects to `/play/`, and `skipTrailingSlashRedirect` stops Next undoing it.

   That redirect lives in **`src/middleware.ts`**, and it has to. Two traps,
   both of which produce `ERR_TOO_MANY_REDIRECTS` and neither of which shows up
   until something is actually proxied:

   - A `redirects()` rule in `next.config.ts` written as `source: '/play'`
     **also matches `/play/`**, because Next normalises the trailing slash when
     matching. The rule then fires on its own destination, forever.
   - Inside middleware, `request.nextUrl.clone()` re-normalises the trailing
     slash the moment you assign `pathname`, so `/play/` becomes `/play` and you
     get the same loop. Build the target with a plain `new URL(request.url)`
     instead.

   If you ever touch this, test it: `curl -I https://…/play` must answer 308
   pointing at `/play/`, and `curl -I https://…/play/` must **not** be a
   redirect at all.
2. **`/api/*` is proxied too**, because in the browser the app calls `/api`
   from the origin root.
3. **The service worker** is served at `/play/sw.js`, so its scope is `/play/`
   and it cannot take over the marketing site. The app's manifest already uses
   relative `start_url` and `scope`, so it adapts on its own — nothing to change
   in the app.

### What to set

On **this** project (the marketing site), once the domain has moved to it:

| Variable | Value |
| --- | --- |
| `APP_ORIGIN` | `https://fairway-games-phils-projects-a6db7377.vercel.app` |
| `NEXT_PUBLIC_SITE_URL` | `https://www.fairway.games` |
| `NEXT_PUBLIC_APP_URL` | `https://www.fairway.games/play/` |

Use the app project's **stable production alias** for `APP_ORIGIN`, not a
per-deployment URL — otherwise `/play` freezes on one old deployment.

### Check it worked

```
https://www.fairway.games/play/        the app loads, assets and all
https://www.fairway.games/play         redirects to the slash version
https://www.fairway.games/api/ping     the app's API answers
https://www.fairway.games/             the marketing site
```

Then sign in at `/play/` and reload — if the session survives, the cookie is
landing first-party and the proxy is doing its job.
