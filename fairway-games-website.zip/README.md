# Fairway Games — marketing website

The website for [Fairway Games](https://github.com), the golf side-game scorer.
Six games, six SEO landing pages, and one download page.

> **More golf. Less scorekeeping.**

The site and the app are one product. The design tokens here are ported
one-for-one from the app's `src/design/tokens.css`, the icon set is the app's
own `src/ui/icons.tsx`, and every phone mockup is a real screenshot from the
built product — not a redrawn marketing mock-up.

---

**Moving the domain over? Start with `CUTOVER.md`** — a step-by-step runbook,
including the two things that break silently if you skip them (the app's old
service worker, and old home-screen icons).

## Running it

```bash
npm install
npm run dev          # http://localhost:3000
```

| Command | What it does |
| --- | --- |
| `npm run dev` | Dev server with hot reload |
| `npm run build` | Production build — 33 static pages, no server rendering |
| `npm start` | Serve the production build |
| `npm run typecheck` | `tsc --noEmit` |
| `npm run lint` | ESLint |
| `npm run check` | typecheck + lint + build, in that order |
| `node qa.mjs [url]` | Layout/a11y sweep: every route at 320 / 390 / 768 / 1440 |
| `node a11y.mjs [url]` | WCAG contrast + keyboard focus, in both themes |
| `node perf.mjs [url]` | Core Web Vitals on throttled 4G with 4× CPU slowdown |

The three audit scripts run against a **running production build**, not the dev
server. Start `npm start` first, then point them at it.

---

## The one file you will actually edit

**`site.config.ts`** holds everything that changes between now and launch:

```ts
url:        'https://www.fairway.games'        // canonicals, OG, sitemap, QR code
webAppUrl:  'https://www.fairway.games/play'   // the playing app

stores: {
  android: { status: 'testing', url: 'https://play.google.com/apps/internaltest/…' },
  ios:     { status: 'web',     url: webAppUrl },
},
launchListUrl: null,                           // a real form, or null for mailto:
analytics: { enabled: false, … },              // off by default, cookieless when on
```

Each platform has one of four statuses, and **every** download button on the
site follows it — hero, header, sticky mobile bar, download page, the six
game-page CTAs, the install cards and the FAQ:

| Status | Button says | Behaviour |
| --- | --- | --- |
| `live` | Get it on **Google Play** / Download on the **App Store** | Opens the store in a new tab |
| `testing` | Join the test on **Google Play** | Same, plus the tester caveat underneath |
| `web` | On iPhone — open the **Web App** | Opens `/play` in the same tab |
| `coming-soon` | Coming soon to … | Dashed, non-interactive; the launch list shows instead |

**Today:** Android is on the internal test track, iPhone points at the web app.
When the public Play listing goes live, change `android.status` to `'live'`,
swap the URL and delete the `note` — nothing else.

There are no invented store links anywhere in this repository. A dead store
link is worse than an honest "not yet".

### Two apps, one domain

`www.fairway.games` serves **this site at the root** and **the playing app at
`/play`**. One origin matters for more than tidiness: the app's session cookie
stays first-party, and "open the app" never looks like a handoff to somewhere
else.

They are separate deployments, so this project owns the domain and proxies the
app through a rewrite in `next.config.ts`. Set one environment variable on this
project:

| Name | Value |
| --- | --- |
| `APP_ORIGIN` | the app deployment's own origin, e.g. `https://fairway-games.vercel.app` |

With it set, `/play` and `/play/*` proxy to the app. Without it, `/play` 404s
here — which is the honest behaviour while the app is still served from the
root of the domain.

**The app needs no changes.** It already builds with `base: './'` and a
relative manifest `scope`, so it works under a subpath as it stands. `/api/*`
is proxied too, because in the browser the app calls `/api` from the origin
root — which also keeps its session cookie first-party.

**See `PLAY-ROUTE.md`** for the full picture, including the trailing-slash trap
and how to guarantee `/play` always serves the build that is live in the Play
Store. That last part does not happen by itself: by default the app's
production deploys track `main` while Play only moves when you upload a bundle,
so the web runs ahead. One Vercel setting and three lines in the release
workflow fix it.

---

## Placeholders that must be filled before launch

Search for `Placeholder` in `src/components/LegalPage.tsx` — it renders visibly
in sand so nobody can ship past it by accident.

| Where | What is missing |
| --- | --- |
| `site.config.ts` → `contact.company` | The legal entity name |
| `site.config.ts` → `contact.address` | Registered address |
| `site.config.ts` → `contact.email` | Currently `hello@fairway.games` — point it at a mailbox somebody reads |
| `/terms` | Place of jurisdiction; the whole document needs a Swiss lawyer's eyes |
| `/privacy` | Controller details, otherwise complete — it mirrors the policy shipped inside the app |

`/privacy` is the URL both app stores require before they will accept a build
with sign-in. It deliberately mirrors `src/screens/Privacy.tsx` in the app
repository. **If the app starts collecting something else, both have to change.**

---

## Architecture

```
site.config.ts          stores, URL, brand, analytics — the launch switch
src/
  app/
    tokens.css          the app's design tokens, ported verbatim + web additions
    globals.css         Tailwind bridge, base, layout primitives, motion
    layout.tsx          shell, metadata defaults, theme script, JSON-LD graph
    page.tsx            homepage
    games/page.tsx      games index + comparison table
    games/[slug]/       one template, six static pages
    how-it-works/  features/  download/  faq/  about/  privacy/  terms/
    opengraph-image.tsx one per section, plus one per game
    sitemap.ts  robots.ts  manifest.ts
    not-found.tsx  error.tsx  loading.tsx
  components/           Header Footer CTAButton GameCard PhoneMockup
                        GameRulesExample GameVisuals FeatureCard FAQ
                        DownloadButtons QRCode SectionHeading Breadcrumbs
                        Icons Art JsonLd LegalPage ThemeToggle StickyMobileCTA
                        Analytics
  content/
    types.ts            the Game shape
    games/              wolf skins nassau vegas dots team-match-play + index
    site.ts             features, the four steps, the general FAQ, navigation
  lib/
    seo.ts              metadata builder + Schema.org nodes
    og.tsx              the OpenGraph template
public/
  app/                  23 real screenshots, cropped to a phone viewport
  brand/                app icon (SVG + PNG), crest, apple-touch-icon
```

### Adding a seventh game

Exactly like adding one to the app:

1. Create `src/content/games/<slug>.ts` exporting a `Game`.
2. Add two lines to `src/content/games/index.ts`.
3. Add the mark to `GAME_MARKS` in `src/components/Icons.tsx`.
4. Add its four colour tokens to `tokens.css` (`--game-X`, `-soft`, `-text`,
   `-deep`) in the light block **and both** dark blocks.
5. Optionally add a bespoke visual to `GAME_VISUALS` in `GameVisuals.tsx`.

The route, the card, the nav, the footer, the comparison table, the sitemap
entry, the OpenGraph card and the FAQ schema all follow automatically. No page
file changes.

`GAME_RESEARCH.md` in the app repository has the shortlist: Bingo Bango Bongo
and Sixes are next.

### Dark by default

The app follows the phone's setting, because it is used outdoors. The website
does not: dark is its default, and light is opt-in through the toggle in the
header.

That is expressed structurally, not with a media query — the dark palette sits
on bare `:root` and light on `:root[data-theme='light']`. So dark is what a
visitor gets with no JavaScript, no stored preference, and whatever the
operating system says, and the inline theme script only ever *adds* an
attribute. There is no flash of the wrong ground in either direction.

`a11y.mjs` switches themes by setting the stored preference, not the browser's
`colorScheme` — the site ignores the latter, so testing that way would silently
measure the same theme twice.

### Why the colours have four roles

One colour per game cannot do everything and still pass WCAG. `--game-skins`
is `#a9823a`; as link text on cream that is **3.48:1**, which fails AA. So each
game has four tokens:

| Token | Used for | Bar |
| --- | --- | --- |
| `--game-X` | marks, fills, rules | 3:1 (graphical) |
| `--game-X-soft` | the field behind a mark or an emphasised row | — |
| `--game-X-text` | anything that is **text** | 4.5:1 on bg, surface and its own `-soft` |
| `--game-X-deep` | a solid band carrying cream text | 4.5:1 |

Same reasoning behind `--good-text`, `--bad-text` and `--on-accent-soft`.

---

## Technology, and why

**Next.js 15 (App Router) + TypeScript + Tailwind CSS v4.**

- **Static.** All 33 routes prerender at build time. There is no server
  rendering and no database — the site is a CDN artefact.
- **SEO.** The game pages are informational content that has to rank for
  "wolf golf rules" and the like. Static HTML with real metadata, canonicals,
  a sitemap and FAQ structured data is the shortest path to that.
- **No web fonts.** The app deliberately uses a system condensed stack so it
  works offline; the site keeps the same stack. Nothing blocks first paint and
  there is no font swap.
- **Almost no JavaScript.** ~102 kB shared, and only four client components:
  the header (mobile menu), the theme toggle, the sticky mobile CTA and the
  error boundary. The FAQ accordions are native `<details>`, so the answers are
  in the DOM for crawlers and work with JavaScript off.
- **One dependency beyond the framework:** `qrcode-generator`, so the download
  page's QR code is generated on the server as inline SVG rather than by
  calling a third-party QR service that would leak the visitor's IP.

Tailwind's custom classes live in `@layer components` on purpose. Unlayered CSS
beats Tailwind's layered utilities, which silently broke `lg:hidden` on the
showcase rail during the build.

---

## Analytics and consent

**There is no cookie banner because there are no cookies.** The site sets none
and runs no analytics. The only browser storage is the light/dark preference,
kept in `localStorage` on the visitor's own device.

To switch analytics on, set `analytics` in `site.config.ts` to a **cookieless**
provider (Plausible or Umami). Neither sets cookies nor tracks people across
sites, so under the GDPR and the Swiss DSG neither needs consent.

Conceptual events are already marked up across the site with `data-event`
attributes, so no component changes when analytics goes on:

```
download-cta-header · download-cta-menu · download-cta-sticky
download-cta-hero   · download-cta-final · download-cta-<game>
store-click-android · store-click-ios    · launch-list-click
qr-shown            · faq-expand
```

**If a provider that needs consent is ever added** — Google Analytics, Meta
Pixel, anything with cross-site identifiers — a consent gate has to be built
first. Do not just add the script.

---

## Deploying

The site is static, so anything that serves files will do. Vercel is the
shortest path and matches where the app's API already lives.

### Vercel

1. Import the repository at [vercel.com/new](https://vercel.com/new). It
   detects Next.js; no build settings need changing.
2. Add one environment variable:

   | Name | Value |
   | --- | --- |
   | `NEXT_PUBLIC_SITE_URL` | `https://www.fairway.games` |
   | `NEXT_PUBLIC_APP_URL` | `https://www.fairway.games/play` |
   | `APP_ORIGIN` | the app deployment's origin — see "Two apps, one domain" |

   Without it the site falls back to `VERCEL_PROJECT_PRODUCTION_URL`, which
   works but puts a `*.vercel.app` domain in your canonicals and OpenGraph
   tags. Set it before you let Google index anything.
3. Add the custom domain under **Settings → Domains**.
4. Deploy. Every push to `main` redeploys.

### Anywhere else

```bash
npm run build
npm start          # Node, port 3000
```

For a pure static host, add `output: 'export'` to `next.config.ts`. Note that
this turns the OpenGraph images into build-time files rather than edge
functions — fine, but the build gets slower.

### After the first deploy

- Submit `https://<domain>/sitemap.xml` in Google Search Console.
- Check one game page in the
  [Rich Results Test](https://search.google.com/test/rich-results) — the
  FAQPage and BreadcrumbList should both be picked up.
- Paste the homepage into a social debugger to confirm the OG card renders.

---

## Verification

Everything below was run against the production build, not the dev server.

### Build

```
✓ Compiled successfully
✓ Generating static pages (33/33)
First Load JS shared by all: 102 kB
```

### Layout and accessibility — `node qa.mjs`

16 routes × 4 widths (320 / 390 / 768 / 1440) = **64 combinations, all clean**:
no horizontal overflow, no console errors, no image without `alt`, exactly one
`h1` per page, no heading-level jumps, no unnamed control, nothing below the
44px touch target outside body copy.

The overflow check deliberately disables `overflow-x: clip` on `<body>` before
measuring. Leaving it on hides real layout bugs — it hid a 30px overflow at
320px caused by a fixed-width phone mockup dragging its grid column.

### Contrast and keyboard — `node a11y.mjs`

Every text node measured against its nearest opaque background, in **both**
themes, plus 22 tab stops per page checked for a visible focus ring.

```
CONTRAST + KEYBOARD CLEAN
```

Dark mode is audited separately because, like the app's, it is a separate
composition rather than an inversion. That audit is what caught cream text on
the light-green dark-mode brand button at 2.8:1.

### Core Web Vitals — `node perf.mjs`

Throttled to fast 4G with a 4× CPU slowdown, on a 390px viewport:

| Route | LCP | CLS |
| --- | --- | --- |
| `/` | 1072 ms | 0.000 |
| `/games` | 500 ms | 0.000 |
| `/games/vegas` | 320 ms | 0.000 |
| `/download` | 284 ms | 0.000 |
| `/how-it-works` | 316 ms | 0.000 |
| `/faq` | 476 ms | 0.000 |

Thresholds are 2500 ms and 0.1. CLS is zero everywhere because every image has
explicit dimensions and no font is downloaded.

---

## Design review

Six reviews were run against the built site, in the spirit of the three the app
went through. Each produced changes; the ones that mattered are recorded here.

### Golfers — can someone understand this in five seconds?

| Finding | Action |
| --- | --- |
| The hero headline broke into five lines, orphaning "No" | Widened the text column, capped the display scale, and set explicit line breaks so it reads as three lines at every width |
| "House rules" showed the account settings screen while the copy talked about points and carries | Swapped to the Wolf settings sheet, which shows the actual point steppers |

### UI designers — does it feel premium?

| Finding | Action |
| --- | --- |
| The showcase rendered both the mobile rail and the desktop fan at once | Custom CSS was unlayered and beating Tailwind's `lg:hidden`. Moved into `@layer components` |
| The desktop device fan overlapped so heavily the middle screens were unreadable | Reduced the overlap and the rotation |
| The three "first tee" phones were too small to read | Gave the column more width and the devices 230px |

### UX designers — is navigation obvious?

| Finding | Action |
| --- | --- |
| Hero CTAs were two different widths on a phone | Full-width stacked below `sm` |
| The sticky CTA covered the hero on first paint | It now appears only after 620px of scroll, and never on `/download` |
| Breadcrumbs, footer links and the logo were 20–40px tall | All raised to at least 44px |

### Conversion — are the CTAs clear?

| Finding | Action |
| --- | --- |
| The final CTA's game list wrapped with a separator stranded at the end of a line | Rendered as a list with the separator inside the item |
| Nothing said what happens if the stores are not live yet | The download page now states it plainly and offers the launch list rather than a dead button |

### SEO — can the game pages rank?

| Finding | Action |
| --- | --- |
| `/games` and `/features` jumped from `h1` straight to `h3` | Added `sr-only` `h2` section headings |
| The OG cards repeated the tagline twice on the homepage | Footer right now carries the domain |
| The OG dawn-glow rendered as a black disc | Satori does not handle radial gradients; redrawn as concentric SVG rings |

### Developers — is it maintainable?

| Finding | Action |
| --- | --- |
| One fixed-width mockup could drag a whole grid column past the viewport | `PhoneMockup` takes a *maximum* width; grid columns use `minmax(0,…)` |
| A wide example table widened the page on a 320px phone | Tables scroll inside their own box |
| The per-game accents were used as both fill and text | Split into four roles — see "Why the colours have four roles" |

---

## Quality assessment

Rated after the six reviews. The bar was 8/10, the same one the app set.

| Category | Score | Note |
| --- | --- | --- |
| Visual quality | 9 | The palette, the condensed display face and the abstract course geometry carry it without a single stock golf photograph |
| Golf identity | 9 | Fairway green, clubhouse cream, bunker sand, the crest, contour lines. It could not be a SaaS landing page |
| Mobile UX | 9 | Verified at 320px, full-width CTAs, a sticky bar that waits its turn, horizontal snap rails |
| Desktop UX | 9 | The layered device fan and the sticky worked example on the game pages are the two moments that feel designed rather than assembled |
| Product understanding | 9 | Hero, value strip and "made for the first tee" tell the whole story before the fold ends. Every rules page carries a worked example |
| Conversion potential | 8 | The path to `/download` is never more than one tap. The honest gap: with the stores not live there is no way to measure it yet, and the launch list is a `mailto:` until a real form exists |
| SEO | 9 | Six pages written for real informational queries, full metadata, FAQ + breadcrumb structured data, a sitemap, and a content model built to add a seventh game |
| Performance | 10 | LCP 0.3–1.1s on throttled 4G, CLS 0, no web fonts, ~102 kB of JavaScript for the whole site |
| Accessibility | 9 | AA contrast verified in both themes, 44px targets, keyboard-complete, semantic `<details>` FAQs, reduced-motion honoured |
| Brand consistency | 10 | Tokens, icons and screenshots come from the app itself. There is nothing on this site that the product does not do |

**Nothing scored below 8.** The one 8 — conversion potential — is a measurement
gap rather than a design one, and it closes the day the stores go live and
analytics is switched on.

### What would be next

1. A real launch-list form, replacing the `mailto:` link.
2. A `/blog` and `/guides` section: "golf games for 3 players", "best golf side
   games for a trip" are queries the game pages cannot answer on their own.
3. German localisation, once the app itself is localised — a German site
   leading to an English app reads badly, and reviewers notice.
4. Custom illustration for the six game cards, replacing the icon marks. This
   is the same item at the top of the app's own list.
