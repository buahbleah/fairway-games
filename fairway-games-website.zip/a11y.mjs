/**
 * Contrast and keyboard audit.
 *
 * Walks every text node's computed colour against its nearest opaque
 * background and reports anything under WCAG AA (4.5:1 for body text, 3:1 for
 * large text). Then tabs through each page and checks that every stop has a
 * visible focus indicator.
 *
 * Runs in both themes. Dark is the site's default and light is opt-in, so the
 * light pass sets the stored preference rather than the OS colorScheme — the
 * site deliberately ignores the latter.
 */
import { chromium } from 'playwright'

const base = process.argv[2] ?? 'http://localhost:4321'
const routes = ['/', '/games', '/games/vegas', '/games/wolf', '/how-it-works', '/features', '/download', '/faq', '/about', '/terms']

const contrastAudit = () => {
  const parse = (c) => {
    const m = c.match(/rgba?\(([\d.]+),\s*([\d.]+),\s*([\d.]+)(?:,\s*([\d.]+))?\)/)
    if (!m) return null
    return { r: +m[1], g: +m[2], b: +m[3], a: m[4] === undefined ? 1 : +m[4] }
  }
  const lum = ({ r, g, b }) => {
    const f = (v) => {
      v /= 255
      return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4)
    }
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)
  }
  const ratio = (a, b) => {
    const l1 = lum(a), l2 = lum(b)
    return (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05)
  }
  const over = (fg, bg) => {
    // composite fg (with alpha) over an opaque bg
    const a = fg.a
    return { r: fg.r * a + bg.r * (1 - a), g: fg.g * a + bg.g * (1 - a), b: fg.b * a + bg.b * (1 - a), a: 1 }
  }

  const bgOf = (el) => {
    let n = el
    while (n && n !== document.documentElement) {
      const c = parse(getComputedStyle(n).backgroundColor)
      if (c && c.a > 0.85) return c
      n = n.parentElement
    }
    return parse(getComputedStyle(document.body).backgroundColor) || { r: 255, g: 255, b: 255, a: 1 }
  }

  const fails = []
  document.querySelectorAll('body *').forEach((el) => {
    if (el.closest('svg')) return
    const hasText = [...el.childNodes].some((n) => n.nodeType === 3 && n.textContent.trim().length > 0)
    if (!hasText) return
    const cs = getComputedStyle(el)
    if (cs.visibility === 'hidden' || cs.display === 'none' || +cs.opacity < 0.1) return
    const r = el.getBoundingClientRect()
    if (r.width === 0 || r.height === 0) return

    const fg = parse(cs.color)
    if (!fg) return
    const bg = bgOf(el)
    const c = ratio(over(fg, bg), bg)

    const px = parseFloat(cs.fontSize)
    const bold = +cs.fontWeight >= 700
    const large = px >= 24 || (bold && px >= 18.66)
    const need = large ? 3 : 4.5

    if (c < need) {
      fails.push({
        text: el.textContent.trim().slice(0, 32),
        ratio: c.toFixed(2),
        need,
        px: Math.round(px),
        color: cs.color,
      })
    }
  })
  return fails
}

const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' })
let problems = 0

for (const theme of ['light', 'dark']) {
  console.log(`\n══ ${theme} theme ═══════════════════════`)
  // The site ignores the OS setting — dark is its default and light is opt-in
  // via the stored preference. So the light run has to set that preference,
  // not the browser's colorScheme, or both runs would test the same theme.
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 }, colorScheme: theme })
  if (theme === 'light') {
    await ctx.addInitScript(() => {
      try {
        localStorage.setItem('fw-theme', 'light')
      } catch {
        /* ignore */
      }
    })
  }
  for (const route of routes) {
    const page = await ctx.newPage()
    await page.goto(base + route, { waitUntil: 'domcontentloaded' })
    await page.waitForTimeout(200)
    // Confirm the theme actually applied before trusting any measurement.
    const applied = await page.evaluate(
      () => document.documentElement.getAttribute('data-theme') ?? 'dark',
    )
    if (applied !== theme) {
      console.log(`  ! ${route} — expected ${theme}, got ${applied}; skipping`)
      await page.close()
      problems++
      continue
    }

    const fails = await page.evaluate(contrastAudit)

    // keyboard: tab through the first 22 stops and require a visible focus ring
    const noRing = []
    for (let i = 0; i < 22; i++) {
      await page.keyboard.press('Tab')
      const info = await page.evaluate(() => {
        const el = document.activeElement
        if (!el || el === document.body) return null
        const cs = getComputedStyle(el)
        const visible =
          (cs.outlineStyle !== 'none' && parseFloat(cs.outlineWidth) > 0) ||
          cs.boxShadow !== 'none'
        return { visible, tag: el.tagName, label: (el.textContent || el.getAttribute('aria-label') || '').trim().slice(0, 20) }
      })
      if (info && !info.visible) noRing.push(`${info.tag}:${info.label}`)
    }

    if (fails.length || noRing.length) {
      problems++
      console.log(`  ✗ ${route}`)
      fails.slice(0, 4).forEach((f) => console.log(`      contrast ${f.ratio}:1 (need ${f.need}) ${f.px}px "${f.text}" ${f.color}`))
      if (noRing.length) console.log(`      no focus ring: ${noRing.slice(0, 4).join(', ')}`)
    } else {
      console.log(`  ✓ ${route}`)
    }
    await page.close()
  }
  await ctx.close()
}

await browser.close()
console.log(`\n${problems === 0 ? 'CONTRAST + KEYBOARD CLEAN' : `${problems} findings`}`)
