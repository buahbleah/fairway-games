import type { NextConfig } from 'next'

/**
 * TWO APPS, ONE DOMAIN
 *
 * www.fairway.games serves this marketing site at the root and the playing app
 * at /play. They are separate Vercel projects: this one owns the domain and
 * proxies the app through.
 *
 * Set APP_ORIGIN to the app project's stable production alias — currently
 * https://fairway-games-phils-projects-a6db7377.vercel.app — and the rewrites
 * below activate. Leave it unset and /play 404s here, which is the honest
 * behaviour while the app is still served from the root of the domain.
 *
 * Three details make this work, and all three are easy to get wrong:
 *
 * 1. TRAILING SLASH. The app's Vite build uses `base: './'`, so index.html
 *    asks for `./assets/…`. Served at `/play` (no slash) the browser resolves
 *    that against `/` and every asset 404s. It has to be `/play/`. Next
 *    normally strips trailing slashes, which would undo that — hence
 *    skipTrailingSlashRedirect plus our own redirect in the other direction.
 *
 * 2. THE API. In the browser the app calls `/api/…` from the origin root (see
 *    src/net/api.ts: BASE = '/api'). Under this domain that would hit the
 *    marketing site, so /api is proxied to the app too. A useful side effect:
 *    the session cookie stays first-party on www.fairway.games.
 *
 * 3. THE SERVICE WORKER. It is served at /play/sw.js, so its scope is /play/
 *    and it cannot claim this marketing site. The app's manifest already uses
 *    relative `start_url` and `scope`, so it adapts to the subpath on its own.
 */
const appOrigin = process.env.APP_ORIGIN?.replace(/\/$/, '')

const nextConfig: NextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,

  // Required for the /play/ proxy — see note 1 above.
  skipTrailingSlashRedirect: true,

  images: {
    formats: ['image/avif', 'image/webp'],
  },

  // The /play → /play/ redirect lives in src/middleware.ts, NOT here: Next
  // normalises the trailing slash when matching a redirect source, so a rule
  // written as '/play' also matches '/play/' and redirects to itself forever.

  async rewrites() {
    if (!appOrigin) return []
    return [
      { source: '/play/', destination: `${appOrigin}/` },
      { source: '/play/:path*', destination: `${appOrigin}/:path*` },
      // The app's API, kept first-party under this domain.
      { source: '/api/:path*', destination: `${appOrigin}/api/:path*` },
    ]
  },

  async headers() {
    return [
      {
        source: '/:path*',
        headers: [
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
          { key: 'X-Frame-Options', value: 'SAMEORIGIN' },
        ],
      },
      {
        source: '/app/:path*',
        headers: [{ key: 'Cache-Control', value: 'public, max-age=31536000, immutable' }],
      },
      {
        source: '/brand/:path*',
        headers: [{ key: 'Cache-Control', value: 'public, max-age=31536000, immutable' }],
      },
      {
        // The kill-switch worker must never be cached, or a browser holding the
        // old app worker will keep serving the old one. See public/sw.js.
        source: '/sw.js',
        headers: [
          { key: 'Cache-Control', value: 'no-store, must-revalidate' },
          { key: 'Service-Worker-Allowed', value: '/' },
        ],
      },
    ]
  },
}

export default nextConfig
