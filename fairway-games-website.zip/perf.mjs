/**
 * Core Web Vitals check against the production build.
 *
 * Measures LCP, CLS and the transferred bytes for a cold load of each page on
 * a throttled connection, which is what a golfer opening the site from
 * Instagram on 4G actually gets.
 */
import { chromium } from 'playwright'

const base = process.argv[2] ?? 'http://localhost:4321'
const routes = ['/', '/games', '/games/vegas', '/download', '/how-it-works', '/faq']

const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' })

console.log('route                 LCP     CLS     JS      total   requests')
console.log('─'.repeat(66))

for (const route of routes) {
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 } })
  const page = await ctx.newPage()

  let js = 0
  let total = 0
  let requests = 0
  page.on('response', async (res) => {
    requests++
    try {
      const len = Number(res.headers()['content-length'] || 0)
      total += len
      if ((res.headers()['content-type'] || '').includes('javascript')) js += len
    } catch {
      /* ignore */
    }
  })

  // Fast 4G: 9 Mbps down, 40ms RTT, 4x CPU slowdown
  const client = await ctx.newCDPSession(page)
  await client.send('Network.enable')
  await client.send('Network.emulateNetworkConditions', {
    offline: false,
    downloadThroughput: (9 * 1024 * 1024) / 8,
    uploadThroughput: (1.5 * 1024 * 1024) / 8,
    latency: 40,
  })
  await client.send('Emulation.setCPUThrottlingRate', { rate: 4 })

  await page.goto(base + route, { waitUntil: 'load' })
  await page.waitForTimeout(2500)

  const vitals = await page.evaluate(
    () =>
      new Promise((resolve) => {
        let lcp = 0
        let cls = 0
        new PerformanceObserver((l) => {
          for (const e of l.getEntries()) lcp = Math.max(lcp, e.startTime)
        }).observe({ type: 'largest-contentful-paint', buffered: true })
        new PerformanceObserver((l) => {
          for (const e of l.getEntries()) if (!e.hadRecentInput) cls += e.value
        }).observe({ type: 'layout-shift', buffered: true })
        setTimeout(() => resolve({ lcp, cls }), 400)
      }),
  )

  const kb = (n) => `${(n / 1024).toFixed(0)}k`
  const lcpMs = Math.round(vitals.lcp)
  const flag = (ok) => (ok ? ' ' : '!')

  console.log(
    `${route.padEnd(20)} ${(lcpMs + 'ms').padEnd(7)}${flag(lcpMs < 2500)}` +
      `${vitals.cls.toFixed(3).padEnd(7)}${flag(vitals.cls < 0.1)}` +
      `${kb(js).padEnd(7)} ${kb(total).padEnd(7)} ${requests}`,
  )

  await ctx.close()
}

await browser.close()
console.log('\nThresholds: LCP < 2500ms, CLS < 0.1. "!" marks a miss.')
