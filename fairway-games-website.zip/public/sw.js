/**
 * SELF-DESTRUCTING SERVICE WORKER
 *
 * This exists because of the domain cutover, not because this site wants one.
 *
 * Before the move, the app was served from the root of www.fairway.games, so
 * its Workbox service worker registered at scope "/" on every device that ever
 * opened it. A service worker survives the site it came from: once the domain
 * points at this marketing site, those browsers would keep being handed the
 * app's cached shell instead of the website — and would go on doing so until
 * the registration happened to be replaced.
 *
 * Browsers re-fetch /sw.js periodically and on navigation. When they fetch it
 * they get this file instead of the old one, and this one deletes every cache
 * and unregisters itself. One visit and the old worker is gone for good.
 *
 * Keep this file until the analytics (or your own patience) say nobody is
 * running the old registration any more. It costs nothing to leave in place.
 */

self.addEventListener('install', () => {
  // Take over immediately rather than waiting for every tab to close.
  self.skipWaiting()
})

self.addEventListener('activate', (event) => {
  event.waitUntil(
    (async () => {
      try {
        const keys = await caches.keys()
        await Promise.all(keys.map((key) => caches.delete(key)))
      } catch {
        // A browser with storage blocked has nothing to clear anyway.
      }

      await self.registration.unregister()

      // Reload any open tab so it renders the real site rather than whatever
      // the old worker last cached.
      const clients = await self.clients.matchAll({ type: 'window' })
      for (const client of clients) {
        try {
          client.navigate(client.url)
        } catch {
          // Not all browsers allow navigate(); the next reload picks it up.
        }
      }
    })(),
  )
})

// Explicitly pass every request straight to the network while this worker is
// still alive, so nothing is served from the old caches in the meantime.
self.addEventListener('fetch', (event) => {
  event.respondWith(fetch(event.request))
})
