/**
 * QA sweep.
 *
 * Runs every route at four widths and reports, per page:
 *   - true horizontal overflow (measured with body's overflow-x clip disabled,
 *     because that clip hides real layout bugs)
 *   - console errors and page errors
 *   - images missing alt text
 *   - heading-level jumps
 *   - interactive elements below the 44px touch-target minimum
 *   - links whose accessible name is empty
 *
 * Usage: node qa.mjs [baseUrl]
 */
import { chromium } from 'playwright'

const base = process.argv[2] ?? 'http://localhost:4321'

const routes = [
  '/',
  '/games',
  '/games/wolf',
  '/games/skins',
  '/games/nassau',
  '/games/vegas',
  '/games/dots',
  '/games/team-match-play',
  '/how-it-works',
  '/features',
  '/download',
  '/faq',
  '/about',
  '/privacy',
  '/terms',
  '/this-page-does-not-exist',
]

const widths = [320, 390, 768, 1440]

const audit = () => {
  // Reveal any overflow the decorative clip is hiding.
  const prev = document.body.style.overflowX
  document.body.style.overflowX = 'visible'
  const de = document.documentElement
  const vw = de.clientWidth

  const offenders = []
  document.querySelectorAll('body *').forEach((el) => {
    if (el.closest('svg')) return
    const cs = getComputedStyle(el)
    if (cs.position === 'fixed') return
    // Decorative absolutely-positioned art is allowed to bleed; it is clipped
    // by an ancestor with overflow hidden.
    if (el.getAttribute('aria-hidden') === 'true' && cs.position === 'absolute') return
    // Anything inside a deliberately scrollable container (a wide table, a
    // snap rail) is meant to extend past the viewport.
    for (let a = el.parentElement; a; a = a.parentElement) {
      const ao = getComputedStyle(a).overflowX
      if (ao === 'auto' || ao === 'scroll') return
    }
    const r = el.getBoundingClientRect()
    if (r.width > 0 && r.right > vw + 1) {
      offenders.push({
        tag: el.tagName,
        cls: String(el.getAttribute('class') || '').slice(0, 56),
        right: Math.round(r.right),
      })
    }
  })

  const noAlt = [...document.querySelectorAll('img')].filter((i) => i.getAttribute('alt') === null)
    .length

  const headings = [...document.querySelectorAll('h1,h2,h3,h4,h5,h6')].map((h) =>
    Number(h.tagName[1]),
  )
  const h1Count = headings.filter((l) => l === 1).length
  const jumps = []
  for (let i = 1; i < headings.length; i++) {
    if (headings[i] - headings[i - 1] > 1) jumps.push(`${headings[i - 1]}→${headings[i]}`)
  }

  const small = []
  document.querySelectorAll('a[href], button, summary, [role="button"]').forEach((el) => {
    const r = el.getBoundingClientRect()
    if (r.width === 0 || r.height === 0) return
    const cs2 = getComputedStyle(el)
    if (cs2.display === 'inline') return // inline text links: exempt (WCAG 2.5.8)
    if (el.closest('.prose-fw')) return // links inside body copy
    if (el.closest('nav[aria-label="Breadcrumb"]')) return // breadcrumb text links
    if (r.height < 40) {
      small.push(`${el.tagName}.${String(el.getAttribute('class') || '').slice(0, 24)}@${Math.round(r.height)}`)
    }
  })

  const unnamed = [...document.querySelectorAll('a[href], button')].filter((el) => {
    const name =
      (el.getAttribute('aria-label') || '').trim() ||
      (el.textContent || '').trim() ||
      (el.querySelector('img')?.getAttribute('alt') || '').trim() ||
      (el.querySelector('svg [role], svg title')?.textContent || '').trim()
    return !name
  }).length

  document.body.style.overflowX = prev
  return { overflow: offenders.slice(0, 4), noAlt, h1Count, jumps, small: small.slice(0, 5), unnamed }
}

const browser = await chromium.launch({
  executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
})

let failures = 0

for (const width of widths) {
  const ctx = await browser.newContext({ viewport: { width, height: 900 }, reducedMotion: 'reduce' })
  console.log(`\n══ ${width}px ═══════════════════════════════════════════`)

  for (const route of routes) {
    const page = await ctx.newPage()
    const errs = []
    page.on('console', (m) => {
      if (m.type() === 'error' && !m.text().includes('404 (Not Found)')) errs.push(m.text().slice(0, 90))
    })
    page.on('pageerror', (e) => errs.push('PE:' + e.message.slice(0, 90)))

    await page.goto(base + route, { waitUntil: 'domcontentloaded' })
    await page.waitForTimeout(220)
    const r = await page.evaluate(audit)

    const problems = []
    if (r.overflow.length) problems.push(`OVERFLOW ${r.overflow.map((o) => `${o.tag}[${o.cls}]@${o.right}`).join(' ')}`)
    if (r.noAlt) problems.push(`${r.noAlt} img without alt`)
    if (r.h1Count !== 1) problems.push(`${r.h1Count} h1`)
    if (r.jumps.length) problems.push(`heading jump ${r.jumps.join(',')}`)
    if (r.small.length) problems.push(`small target ${r.small.join(',')}`)
    if (r.unnamed) problems.push(`${r.unnamed} unnamed control`)
    if (errs.length) problems.push(`console: ${errs[0]}`)

    if (problems.length) {
      failures++
      console.log(`  ✗ ${route}\n      ${problems.join('\n      ')}`)
    } else {
      console.log(`  ✓ ${route}`)
    }
    await page.close()
  }
  await ctx.close()
}

await browser.close()
console.log(`\n${failures === 0 ? 'ALL CLEAN' : `${failures} page/width combinations with findings`}`)
