/**
 * SITE CONFIGURATION — the one file to edit when things change.
 *
 * Store links, the public URL, brand names and analytics all live here so a
 * launch is a config change rather than a search-and-replace across pages.
 */

/**
 * How a platform is currently available.
 *
 *  'live'         a public store listing — renders a normal store button
 *  'testing'      a closed / internal test track: real link, but it only works
 *                 for opted-in testers, so the button says so rather than
 *                 sending strangers to a page that will reject them
 *  'web'          no store build yet, but the app runs in the browser — the
 *                 button opens the web app instead
 *  'coming-soon'  nothing to link to; renders the launch-list CTA
 */
export type StoreStatus = 'live' | 'testing' | 'web' | 'coming-soon'

export interface StoreConfig {
  status: StoreStatus
  /** Required for every status except 'coming-soon'. Never invent one. */
  url?: string
  /** Optional one-line caveat shown under the button, e.g. tester instructions. */
  note?: string
}

/**
 * Where the running web app lives — the Vite build with the sign-in screen.
 *
 * NOTE THE TRAILING SLASH. The app's Vite build uses `base: './'`, so its
 * assets are requested relative to the current directory. Link to /play and the
 * browser resolves them against the site root and they all 404; link to /play/
 * and they resolve correctly. next.config.ts redirects the slashless form, but
 * every link on the site should carry the slash already.
 * This is what the iPhone button opens, and what "play in your browser" points
 * at everywhere on the site.
 *
 * It sits on the SAME domain as this site, at /play, so the two feel like one
 * product and a session cookie set by the app is not cross-site. See
 * next.config.ts → rewrites and the README's "Two apps, one domain".
 *
 * Set NEXT_PUBLIC_APP_URL in the environment (Vercel → Settings → Environment
 * Variables) rather than editing this line, so a preview deployment can point
 * at a different app build.
 */
export const webAppUrl =
  process.env.NEXT_PUBLIC_APP_URL?.replace(/\/$/, '') ?? 'https://www.fairway.games/play/'

export const siteConfig = {
  /** Product name, as it appears on the store and in the app. */
  name: 'Fairway Games',
  /** Used in <title> suffixes and the wordmark. */
  shortName: 'Fairway',
  tagline: 'More golf. Less scorekeeping.',
  description:
    'Play Wolf, Skins, Nassau, Vegas, Dots and Team Match Play with your group. Fairway Games tracks the rules, points, teams and standings so you can focus on golf.',

  /**
   * Public origin, without a trailing slash. Used for canonicals, OpenGraph
   * URLs, the sitemap and QR-code generation.
   *
   * On Vercel this is filled in automatically from the deployment URL when
   * NEXT_PUBLIC_SITE_URL is not set.
   */
  url:
    process.env.NEXT_PUBLIC_SITE_URL?.replace(/\/$/, '') ??
    (process.env.VERCEL_PROJECT_PRODUCTION_URL
      ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}`
      : 'https://www.fairway.games'),

  /** Android app id, shared with capacitor.config.ts in the app repo. */
  appId: 'ch.fairwaygames.app',

  /**
   * Store availability. Change a status here and every download button on the
   * site updates — hero, header, sticky mobile bar, download page, and the six
   * game-page CTAs.
   *
   * Android is on Google Play's internal test track: the link is real, but it
   * only opens for an email that has been added as a tester. When the public
   * listing goes live, change the status to 'live' and drop the note.
   *
   * iPhone has no store build yet. The app is an installable web app, so the
   * iOS button opens it in the browser rather than saying "coming soon" — the
   * whole product works there, including Add to Home Screen.
   */
  stores: {
    android: {
      status: 'testing',
      url: 'https://play.google.com/apps/internaltest/4700479860462359863',
      note: 'Internal test — join with the Google account you were added with.',
    } as StoreConfig,
    ios: {
      status: 'web',
      url: webAppUrl,
      note: 'Open in Safari, then Share → Add to Home Screen.',
    } as StoreConfig,
  },

  /**
   * Where the "Join the launch list" button points while the stores are not
   * live. Leave null to render a mailto: link to contact.email instead.
   */
  launchListUrl: null as string | null,

  contact: {
    email: 'hello@fairway.games',
    /** Placeholder — replace before the legal pages go live. See PLACEHOLDERS in README. */
    company: '[Company name]',
    address: '[Street, postcode, city, Switzerland]',
    country: 'Switzerland',
  },

  social: {
    /** Leave null to hide the link entirely. */
    instagram: null as string | null,
    x: null as string | null,
  },

  /**
   * Analytics is off by default and adds no cookies. Set the provider and the
   * site will load a single cookieless script; nothing else changes.
   */
  analytics: {
    enabled: false,
    /** 'plausible' | 'umami' | null */
    provider: null as 'plausible' | 'umami' | null,
    domain: null as string | null,
    scriptUrl: null as string | null,
  },
} as const

/** True when the platform has somewhere real to send people. */
export const isStoreLinked = (store: StoreConfig): store is StoreConfig & { url: string } =>
  store.status !== 'coming-soon' && typeof store.url === 'string' && store.url.length > 0

/** True only for a public store listing — used where the copy says "on the store". */
export const isStorePublic = (store: StoreConfig): store is StoreConfig & { url: string } =>
  store.status === 'live' && typeof store.url === 'string' && store.url.length > 0

/** Is there any way at all to get the app right now? */
export const anyStoreLive = () =>
  isStoreLinked(siteConfig.stores.android) || isStoreLinked(siteConfig.stores.ios)
