import type { Metadata } from 'next'
import { siteConfig } from '@config'
import { pageMetadata, jsonLd, breadcrumbSchema } from '@/lib/seo'
import { CTAButton } from '@/components/CTAButton'
import { Breadcrumbs } from '@/components/Breadcrumbs'
import { JsonLd } from '@/components/JsonLd'
import { ContourBackdrop, FairwayScene } from '@/components/Art'

export const metadata: Metadata = pageMetadata({
  title: 'About Fairway Games',
  description:
    'Why Fairway Games exists, what it will never do, and what is coming next. Built for golf groups who want to play side games without doing the arithmetic.',
  path: '/about',
})

export default function AboutPage() {
  return (
    <>
      <section className="relative overflow-hidden border-b border-[var(--line)]">
        <ContourBackdrop
          opacity={0.08}
          className="pointer-events-none absolute inset-0 h-full w-full text-[var(--brand)]"
        />
        <div className="rail relative py-14 sm:py-20">
          <Breadcrumbs crumbs={[{ name: 'Home', path: '/' }, { name: 'About', path: '/about' }]} />
          <h1 className="display-1 max-w-[16ch]">Built for the group, not the golfer.</h1>
          <p className="lede mt-6">
            There are plenty of apps that record your score. There were not many that could run a
            Wolf round with a blind declaration, a carried pot and three different handicaps —
            which is what a golf group actually needs.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="rail grid gap-14 lg:grid-cols-[minmax(0,1.15fr)_minmax(0,1fr)] lg:items-start">
          <div className="prose-fw">
            <h2>Why it exists</h2>
            <p>
              Every golf group has the same five minutes on the first tee. Somebody suggests a
              game. Somebody else remembers the rules differently. A third person volunteers to
              keep track, and by the sixth hole nobody is sure what the score is or who is winning.
            </p>
            <p>
              The games themselves are not complicated. What is tedious is the bookkeeping: whose
              turn it is to be Wolf, how many skins have carried, which press is still live, what
              the difference between 45 and 36 comes to when the multiplier is two. All of it is
              easy and none of it is fun, and it happens at exactly the moment you want to be
              hitting your next shot.
            </p>
            <p>
              So the app does that part. You play the hole and enter the number. It handles the
              rest.
            </p>

            <h2>What it will not do</h2>
            <p>
              There are no adverts. There is no third-party tracking and no analytics inside the
              app. Points are points — there is no real money anywhere in the product, no payments,
              no wallet, no gambling of any kind. Whether your group settles up afterwards is
              entirely your business and happens nowhere near the software.
            </p>
            <p>
              You can delete your account and everything attached to it from inside Settings,
              whenever you like, without asking anybody.
            </p>

            <h2>How it is built</h2>
            <p>
              Offline first, and verified rather than assumed: a script loads the production build,
              switches the network off, reloads, plays a hole and reloads again. Every one of the
              six scoring engines has its own test suite — 138 tests covering Wolf scenarios, skins
              carries and validation, Nassau presses and re-presses, Vegas number construction and
              flips, every Dots rule variation, and match-play notation including dormie and
              closeouts.
            </p>
            <p>
              The design followed the same discipline. Three reviews were run against the built
              product — golf brand identity, on-course usability, and product polish — and each one
              produced changes. Nothing shipped below eight out of ten.
            </p>

            <h2>What is next</h2>
            <p>
              A seventh game, and then an eighth. The app is built so a new format is a
              self-contained module rather than a rewrite: its own rules, its own settings, its own
              tests, and one line added to the registry. Bingo Bango Bongo and Sixes are top of the
              list.
            </p>
            <p>
              Beyond that: custom illustration for the six game cards, richer moments when a hole is
              won, and an image export for the share card.
            </p>

            <h2>Get in touch</h2>
            <p>
              Something wrong, something missing, or a game your group plays that is not here?{' '}
              <a href={`mailto:${siteConfig.contact.email}`}>{siteConfig.contact.email}</a>. A
              description of how your group plays it is more useful than a feature request.
            </p>
          </div>

          <aside className="lg:sticky lg:top-24">
            <div className="card overflow-hidden">
              <FairwayScene className="h-auto w-full" />
              <div className="p-6">
                <h2 className="text-[1.125rem]">The one-line version</h2>
                <p className="mt-2 text-[0.9375rem] leading-[1.55] text-[var(--text-muted)]">
                  Open phone → enter result → put phone away.
                </p>
                <p className="mt-4 border-t border-[var(--line)] pt-4 text-[0.9375rem] leading-[1.55] text-[var(--text-muted)]">
                  The website sells the promise. The app delivers it.
                </p>
                <CTAButton href="/download" size="md" className="mt-5 w-full" event="download-cta-about">
                  Get the App
                </CTAButton>
              </div>
            </div>
          </aside>
        </div>
      </section>

      <JsonLd
        data={jsonLd(
          breadcrumbSchema([
            { name: 'Home', path: '/' },
            { name: 'About', path: '/about' },
          ]),
        )}
      />
    </>
  )
}
