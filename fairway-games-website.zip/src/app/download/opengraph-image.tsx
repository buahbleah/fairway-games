import { ogImage, OG_SIZE, OG_CONTENT_TYPE } from '@/lib/og'

export const alt = 'Get the app. — Fairway Games'
export const size = OG_SIZE
export const contentType = OG_CONTENT_TYPE

export default function Image() {
  return ogImage({
    eyebrow: 'Download',
    headline: 'Get the app.',
    sub: 'Six golf side games, scored in seconds between two shots.',
  })
}
