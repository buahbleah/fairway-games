import type { Metadata } from 'next'
import Link from 'next/link'
import { siteConfig, webAppUrl } from '@config'
import { pageMetadata, jsonLd, breadcrumbSchema, appSchema } from '@/lib/seo'
import { AppLanding } from '@/components/AppLanding'
import { Breadcrumbs } from '@/components/Breadcrumbs'
import { JsonLd } from '@/components/JsonLd'
import { Check, ChevronRight } from '@/components/Icons'

/** Badge wording per store status, so the cards and the buttons never disagree. */
const STATUS_LABEL: Record<string, string> = {
  live: 'Available now',
  testing: 'Internal test',
  web: 'In the browser',
  'coming-soon': 'Coming soon',
}

export const metadata: Metadata = pageMetadata({
  title: 'Download Fairway Games',
  description:
    'Get Fairway Games for Android and iPhone — six golf side games, scored in seconds. No adverts, no tracking, no real money.',
  path: '/download',
  keywords: ['golf games app download', 'wolf golf app', 'golf skins app', 'golf side games app'],
})

export default function DownloadPage() {
  const downloadUrl = `${siteConfig.url}/download`

  return (
    <>
      <AppLanding
        headline="Get the app."
        lede="Six golf side games, scored in seconds between two shots. Open the phone, tap a number, put it back in your pocket."
        phoneSrc="/app/01-home.webp"
        phoneAlt="The Fairway Games home screen, with Start Round and the six game cards."
        qrTarget={downloadUrl}
        breadcrumbs={
          <Breadcrumbs
            crumbs={[{ name: 'Home', path: '/' }, { name: 'Download', path: '/download' }]}
          />
        }
      />

      {/* Install options, honest about what exists today */}
      <section className="section-tight bg-[var(--bg-deep)]">
        <div className="rail">
          <h2 className="display-3">Ways to install it</h2>
          <div className="mt-8 grid gap-5 lg:grid-cols-3">
            {([
              {
                t: 'Google Play',
                s: STATUS_LABEL[siteConfig.stores.android.status],
                b: 'The Android build is signed and on the internal test track. Once you are added as a tester the link installs it like any other app, and updates arrive the same way.',
                href: siteConfig.stores.android.url,
              },
              {
                t: 'App Store',
                s: STATUS_LABEL[siteConfig.stores.ios.status],
                b: 'No iPhone store build yet. Until there is, the web app below is the whole product on iOS — same games, same offline scoring, same account.',
              },
              {
                t: 'Add to home screen',
                s: 'Works today',
                b: 'Open the app in Safari or Chrome and use Add to Home Screen. It installs with the app icon, runs full screen with no browser chrome, and works with no signal.',
                href: webAppUrl,
              },
            ] as { t: string; s: string; b: string; href?: string }[]).map((card) => (
              <article key={card.t} className="card flex flex-col p-6">
                <div className="flex items-center justify-between gap-3">
                  <h3 className="text-[1.1875rem]">{card.t}</h3>
                  <span
                    className="shrink-0 rounded-[var(--r-pill)] px-3 py-1 text-[0.6875rem] font-bold uppercase tracking-[0.08em]"
                    style={{
                      background:
                        card.s === 'Coming soon' ? 'var(--accent-soft)' : 'var(--good-soft)',
                      color:
                        card.s === 'Coming soon' ? 'var(--on-accent-soft)' : 'var(--good-text)',
                    }}
                  >
                    {card.s}
                  </span>
                </div>
                <p className="mt-3 flex-1 text-[0.9375rem] leading-[1.55] text-[var(--text-muted)]">
                  {card.b}
                </p>
                {card.href && (
                  <a
                    href={card.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-4 inline-flex min-h-[44px] items-center gap-1.5 font-display text-[0.875rem] font-bold uppercase tracking-[0.06em] text-[var(--brand-strong)]"
                  >
                    Open it
                    <ChevronRight size={16} />
                  </a>
                )}
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="on-dark">
        <div className="rail py-[var(--section-y-tight)]">
          <div className="mx-auto max-w-[46rem] text-center">
            <h2 className="display-3">What you get on day one</h2>
            <ul className="mt-8 grid gap-3 text-left sm:grid-cols-2">
              {[
                'All six games, fully playable',
                'Every rule adjustable before the round',
                'Handicaps with proper stroke-index allocation',
                'Offline scoring, verified rather than assumed',
                'Saved players and saved presets',
                'Hole history, undo and hole editing',
                'Friends, leagues and shared live rounds',
                'Dark mode and a high-contrast sunlight mode',
              ].map((line) => (
                <li key={line} className="flex gap-3">
                  <Check size={19} className="mt-0.5 shrink-0 text-[var(--accent)]" />
                  <span className="text-[0.9375rem] text-[var(--on-dark-muted)]">{line}</span>
                </li>
              ))}
            </ul>

            <p className="mt-10 text-[0.9375rem] text-[var(--on-dark-muted)]">
              Not sure which game to start with?{' '}
              <Link href="/games" className="text-[var(--accent)] underline underline-offset-4">
                Compare all six
              </Link>
              .
            </p>
          </div>
        </div>
      </section>

      <JsonLd
        data={jsonLd(
          breadcrumbSchema([
            { name: 'Home', path: '/' },
            { name: 'Download', path: '/download' },
          ]),
          appSchema(),
        )}
      />
    </>
  )
}
