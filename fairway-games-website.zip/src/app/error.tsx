'use client'

import { useEffect } from 'react'
import { CTAButton } from '@/components/CTAButton'
import { EmptyGreen } from '@/components/Art'

/**
 * The polished error state. No stack traces, no "Application error: a
 * client-side exception has occurred" — just the golf-shaped version of "try
 * again", with a real retry that re-renders the segment.
 */
export default function ErrorBoundary({
  error,
  reset,
}: {
  error: Error & { digest?: string }
  reset: () => void
}) {
  useEffect(() => {
    // Kept so the failure is visible in the browser console during development
    // and in Vercel's runtime logs in production.
    console.error(error)
  }, [error])

  return (
    <section className="rail flex flex-col items-center py-20 text-center sm:py-28">
      <EmptyGreen className="h-auto w-[220px] max-w-full" />

      <p className="eyebrow mt-8">Something went wrong</p>
      <h1 className="display-2 mt-3 max-w-[18ch]">Something went into the rough.</h1>
      <p className="lede mx-auto mt-5">
        That did not load properly. Give it another go — and if it keeps happening, it is our fault
        rather than yours.
      </p>

      <div className="mt-9 flex flex-wrap justify-center gap-3">
        <button
          type="button"
          onClick={reset}
          className="inline-flex min-h-[56px] items-center justify-center rounded-[var(--r-md)] bg-[var(--brand)] px-7 font-display font-bold uppercase tracking-[0.04em] text-[var(--text-on-brand)] transition-[filter] hover:brightness-110"
        >
          Try again
        </button>
        <CTAButton href="/" variant="secondary">
          Back to the Clubhouse
        </CTAButton>
      </div>

      {error.digest && (
        <p className="mt-8 text-[0.8125rem] text-[var(--text-faint)]">
          Reference: <span className="num">{error.digest}</span>
        </p>
      )}
    </section>
  )
}
