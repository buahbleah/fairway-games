import { ogImage, OG_SIZE, OG_CONTENT_TYPE } from '@/lib/og'

export const alt = 'Questions, answered. — Fairway Games'
export const size = OG_SIZE
export const contentType = OG_CONTENT_TYPE

export default function Image() {
  return ogImage({
    eyebrow: 'Questions',
    headline: 'Questions, answered.',
    sub: 'Offline, players, handicaps, house rules — everything golfers ask first.',
  })
}
