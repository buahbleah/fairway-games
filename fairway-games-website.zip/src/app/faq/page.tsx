import type { Metadata } from 'next'
import Link from 'next/link'
import { generalFaq } from '@/content/site'
import { games } from '@/content/games'
import { pageMetadata, jsonLd, breadcrumbSchema, faqSchema } from '@/lib/seo'
import { FAQ } from '@/components/FAQ'
import { CTAButton } from '@/components/CTAButton'
import { Breadcrumbs } from '@/components/Breadcrumbs'
import { JsonLd } from '@/components/JsonLd'
import { ContourBackdrop } from '@/components/Art'
import { GAME_MARKS, ChevronRight } from '@/components/Icons'

export const metadata: Metadata = pageMetadata({
  title: 'Frequently Asked Questions',
  description:
    'Does it work offline? How many players? Can we change the Wolf scoring? Does it do handicaps? Every question golfers ask about Fairway Games, answered.',
  path: '/faq',
  keywords: ['golf games app faq', 'golf scoring app questions', 'offline golf app'],
})

export default function FaqPage() {
  return (
    <>
      <section className="relative overflow-hidden border-b border-[var(--line)]">
        <ContourBackdrop
          opacity={0.08}
          className="pointer-events-none absolute inset-0 h-full w-full text-[var(--brand)]"
        />
        <div className="rail relative py-14 sm:py-20">
          <Breadcrumbs crumbs={[{ name: 'Home', path: '/' }, { name: 'FAQ', path: '/faq' }]} />
          <h1 className="display-1 max-w-[14ch]">Questions, answered.</h1>
          <p className="lede mt-6">
            The things golfers ask before they hand their phone to somebody on the first tee.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="rail-narrow">
          <FAQ items={generalFaq} />
        </div>
      </section>

      <section className="section-tight bg-[var(--bg-deep)]">
        <div className="rail-narrow">
          <h2 className="display-3">Questions about a particular game</h2>
          <p className="lede mt-4">
            Each game page has its own FAQ — the rule disputes that actually come up, answered for
            that game.
          </p>
          <ul className="mt-8 grid gap-3 sm:grid-cols-2">
            {games.map((g) => {
              const Mark = GAME_MARKS[g.slug]
              return (
                <li key={g.slug}>
                  <Link
                    href={`/games/${g.slug}#how-it-works`}
                    className="card flex min-h-[64px] items-center gap-3.5 p-4 transition-[transform,box-shadow] hover:-translate-y-0.5 hover:shadow-[var(--shadow-2)]"
                  >
                    <span
                      className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-[var(--r-sm)]"
                      style={{
                        background: `var(${g.accentVar}-soft)`,
                        color: `var(${g.accentVar})`,
                      }}
                    >
                      <Mark size={20} />
                    </span>
                    <span className="flex-1">
                      <span className="block font-display text-[1rem] font-bold">
                        {g.name} questions
                      </span>
                      <span className="block text-[0.8125rem] text-[var(--text-muted)]">
                        {g.faq.length} answers
                      </span>
                    </span>
                    <ChevronRight size={17} className="text-[var(--text-faint)]" />
                  </Link>
                </li>
              )
            })}
          </ul>
        </div>
      </section>

      <section className="on-dark">
        <div className="rail py-[var(--section-y-tight)] text-center">
          <h2 className="display-3 mx-auto max-w-[20ch]">Still wondering? Just play a round.</h2>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <CTAButton href="/download" variant="accent" event="download-cta-faq">
              Get the App
            </CTAButton>
          </div>
        </div>
      </section>

      <JsonLd
        data={jsonLd(
          breadcrumbSchema([
            { name: 'Home', path: '/' },
            { name: 'FAQ', path: '/faq' },
          ]),
          faqSchema(generalFaq),
        )}
      />
    </>
  )
}
