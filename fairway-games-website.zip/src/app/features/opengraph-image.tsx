import { ogImage, OG_SIZE, OG_CONTENT_TYPE } from '@/lib/og'

export const alt = 'Less math. More golf. — Fairway Games'
export const size = OG_SIZE
export const contentType = OG_CONTENT_TYPE

export default function Image() {
  return ogImage({
    eyebrow: 'Features',
    headline: 'Less math. More golf.',
    sub: 'Custom rules, handicaps, offline scoring, leagues and live shared rounds.',
  })
}
