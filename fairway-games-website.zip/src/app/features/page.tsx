import type { Metadata } from 'next'
import { features } from '@/content/site'
import { pageMetadata, jsonLd, breadcrumbSchema } from '@/lib/seo'
import { FeatureCard } from '@/components/FeatureCard'
import { CTAButton } from '@/components/CTAButton'
import { SectionHeading } from '@/components/SectionHeading'
import { PhoneMockup } from '@/components/PhoneMockup'
import { Breadcrumbs } from '@/components/Breadcrumbs'
import { JsonLd } from '@/components/JsonLd'
import { ContourBackdrop } from '@/components/Art'

export const metadata: Metadata = pageMetadata({
  title: 'Features: Custom Rules, Handicaps, Offline Scoring and Leagues',
  description:
    'Everything Fairway Games does: custom house rules, live leaderboards, offline scoring, saved players and presets, hole history, undo, handicaps and shared rounds.',
  path: '/features',
  keywords: [
    'golf scoring app features',
    'golf handicap app',
    'offline golf scorer',
    'golf league app',
  ],
})

export default function FeaturesPage() {
  return (
    <>
      <section className="relative overflow-hidden border-b border-[var(--line)]">
        <ContourBackdrop
          opacity={0.08}
          className="pointer-events-none absolute inset-0 h-full w-full text-[var(--brand)]"
        />
        <div className="rail relative grid items-center gap-12 py-14 sm:py-20 lg:grid-cols-[minmax(0,1.2fr)_minmax(0,1fr)]">
          <div>
            <Breadcrumbs
              crumbs={[{ name: 'Home', path: '/' }, { name: 'Features', path: '/features' }]}
            />
            <h1 className="display-1 max-w-[16ch]">Less math. More golf.</h1>
            <p className="lede mt-6">
              Everything here exists because a golf group needed it on a course, not because it
              looked good on a feature list.
            </p>
            <div className="mt-8">
              <CTAButton href="/download" event="download-cta-features-hero">
                Get the App
              </CTAButton>
            </div>
          </div>

          <div className="flex justify-center lg:justify-end">
            <PhoneMockup
              src="/app/03-rules-vegas.webp"
              alt="The in-app rules screen for Vegas, written for someone who has never played it, with a worked example using the settings the group chose."
              width={290}
              priority
              glow
              sizes="(max-width: 640px) 90vw, 290px"
            />
          </div>
        </div>
      </section>

      <section className="section" aria-labelledby="all-features">
        <div className="rail">
          {/* Each feature card carries an h3; the outline needs an h2 above
              them. Visually redundant under the h1, so sr-only. */}
          <h2 id="all-features" className="sr-only">
            Everything the app does
          </h2>
          <ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {features.map((f) => (
              <li key={f.title}>
                <FeatureCard feature={f} />
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* Shared rounds — the feature that needed its own explanation */}
      <section className="section bg-[var(--bg-deep)]">
        <div className="rail grid items-center gap-14 lg:grid-cols-[minmax(0,1fr)_minmax(0,0.9fr)]">
          <div>
            <SectionHeading
              eyebrow="Playing together"
              title="Four phones. One card."
              lede="Sign in and the whole group can score the same round. Everybody enters from their own phone and the card fills in on every screen as it happens."
            />
            <ul className="mt-8 space-y-5">
              {[
                {
                  t: 'Friends and leagues',
                  b: 'Add friends by email. Start a league with a join code and keep every round your group has played in one place.',
                },
                {
                  t: 'Merged key by key',
                  b: 'Scores are merged player by player in the database. A phone that was offline for twenty minutes replays its writes without wiping out anybody else’s numbers.',
                },
                {
                  t: 'Still optional',
                  b: 'A solo round needs no account and no connection at all. Signing in only adds the things that need other people.',
                },
              ].map((item) => (
                <li key={item.t} className="border-l-2 border-[var(--brand)] pl-5">
                  <h3 className="text-[1.0625rem]">{item.t}</h3>
                  <p className="mt-1.5 text-[0.9375rem] leading-[1.55] text-[var(--text-muted)]">
                    {item.b}
                  </p>
                </li>
              ))}
            </ul>
          </div>

          <div className="flex justify-center gap-4">
            <PhoneMockup
              src="/app/13-leaderboard.webp"
              alt="The live leaderboard, filling in as the group scores."
              width={230}
              tilt={-3}
              sizes="(max-width: 640px) 45vw, 230px"
            />
            <PhoneMockup
              src="/app/15-share-card.webp"
              alt="A designed share card showing the winner and final standings."
              width={230}
              tilt={3}
              sizes="(max-width: 640px) 45vw, 230px"
              className="mt-10"
            />
          </div>
        </div>
      </section>

      <section className="on-dark">
        <div className="rail py-[var(--section-y-tight)] text-center">
          <h2 className="display-2 mx-auto max-w-[22ch]">
            Your group has its own rules. The app can handle them.
          </h2>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <CTAButton href="/download" variant="accent" event="download-cta-features-footer">
              Get the App
            </CTAButton>
            <CTAButton href="/games" variant="ghost">
              Explore Games
            </CTAButton>
          </div>
        </div>
      </section>

      <JsonLd
        data={jsonLd(
          breadcrumbSchema([
            { name: 'Home', path: '/' },
            { name: 'Features', path: '/features' },
          ]),
        )}
      />
    </>
  )
}
