import { ogImage, OG_SIZE, OG_CONTENT_TYPE } from '@/lib/og'
import { games, gameBySlug } from '@/content/games'

export const alt = 'Fairway Games golf game rules'
export const size = OG_SIZE
export const contentType = OG_CONTENT_TYPE

/** One card per game, generated at build time alongside the pages. */
export function generateStaticParams() {
  return games.map((g) => ({ slug: g.slug }))
}

/** Per-game accents, repeated as literals because Satori cannot read CSS vars. */
const ACCENTS: Record<string, string> = {
  wolf: '#8fc4ab',
  skins: '#d9b472',
  nassau: '#8fb9d3',
  vegas: '#dd9089',
  dots: '#c9c77e',
  'team-match-play': '#8ac2a9',
}

export default async function Image({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  const game = gameBySlug(slug)

  if (!game) {
    return ogImage({ headline: 'Golf side games', sub: 'Scored for you, between two shots.' })
  }

  return ogImage({
    eyebrow: `${game.players} · ${game.complexity}`,
    headline: game.seo.ogHeadline,
    sub: game.tagline,
    accent: ACCENTS[game.slug] ?? '#d9b472',
  })
}
