import type { Metadata } from 'next'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import { games, gameBySlug } from '@/content/games'
import { pageMetadata, jsonLd, breadcrumbSchema, faqSchema } from '@/lib/seo'
import { CTAButton } from '@/components/CTAButton'
import { PhoneMockup } from '@/components/PhoneMockup'
import { SectionHeading } from '@/components/SectionHeading'
import { GameRulesExample } from '@/components/GameRulesExample'
import { GAME_VISUALS } from '@/components/GameVisuals'
import { FAQ } from '@/components/FAQ'
import { Breadcrumbs } from '@/components/Breadcrumbs'
import { JsonLd } from '@/components/JsonLd'
import { ContourBackdrop } from '@/components/Art'
import { GAME_MARKS, Players, Check, ChevronRight, Settings, Info } from '@/components/Icons'

/** Six static pages, generated at build time. Nothing renders on request. */
export function generateStaticParams() {
  return games.map((g) => ({ slug: g.slug }))
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>
}): Promise<Metadata> {
  const { slug } = await params
  const game = gameBySlug(slug)
  if (!game) return {}

  return pageMetadata({
    title: game.seo.title,
    description: game.seo.description,
    path: `/games/${game.slug}`,
    keywords: game.seo.keywords,
    type: 'article',
  })
}

export default async function GamePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  const game = gameBySlug(slug)
  if (!game) notFound()

  const Mark = GAME_MARKS[game.slug]
  const Visual = GAME_VISUALS[game.slug]
  const others = games.filter((g) => g.slug !== game.slug)
  const accent = game.accentVar

  return (
    <>
      {/* ------------------------------------------------------------- hero */}
      <section className="relative overflow-hidden border-b border-[var(--line)]">
        <span
          aria-hidden
          className="pointer-events-none absolute -right-[18%] -top-[38%] h-[130%] w-[70%] rounded-full opacity-[0.55]"
          style={{ background: `var(${accent}-soft)` }}
        />
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0"
          style={{ color: `var(${accent})` }}
        >
          <ContourBackdrop opacity={0.08} className="h-full w-full" />
        </div>

        <div className="rail relative grid items-center gap-12 py-12 sm:py-16 lg:grid-cols-[minmax(0,1.15fr)_minmax(0,1fr)]">
          <div>
            <Breadcrumbs
              crumbs={[
                { name: 'Home', path: '/' },
                { name: 'Games', path: '/games' },
                { name: game.name, path: `/games/${game.slug}` },
              ]}
            />

            <span
              className="mb-6 inline-flex h-16 w-16 items-center justify-center rounded-[var(--r-lg)]"
              style={{ background: `var(${accent}-deep)`, color: 'var(--cream-100)' }}
            >
              <Mark size={32} />
            </span>

            <h1 className="display-1">{game.pageTitle}</h1>
            <p className="lede mt-5">{game.tagline}</p>

            {game.alsoKnownAs && (
              <p className="mt-4 text-[0.9375rem] text-[var(--text-muted)]">
                Also known as {game.alsoKnownAs.join(', ')}.
              </p>
            )}

            <dl className="mt-8 flex flex-wrap gap-3">
              {[
                { icon: Players, term: 'Players', desc: game.players },
                { icon: Settings, term: 'Complexity', desc: game.complexity },
                { icon: Info, term: 'Explaining it', desc: game.explainTime },
              ].map(({ icon: Icon, term, desc }) => (
                <div
                  key={term}
                  className="flex items-center gap-2.5 rounded-[var(--r-pill)] border border-[var(--line-strong)] bg-[var(--surface)] px-4 py-2.5"
                >
                  <Icon size={17} style={{ color: `var(${accent})` }} />
                  <dt className="sr-only">{term}</dt>
                  <dd className="text-[0.875rem] font-medium">{desc}</dd>
                </div>
              ))}
            </dl>

            <div className="mt-8 flex flex-wrap gap-3">
              <CTAButton href="/download" event={`download-cta-${game.slug}`}>
                Play it in the App
              </CTAButton>
              <CTAButton href="#how-it-works" variant="secondary">
                Learn the Rules
              </CTAButton>
            </div>
          </div>

          <div className="flex justify-center lg:justify-end">
            <PhoneMockup
              src={game.screenshot}
              alt={game.screenshotAlt}
              width={300}
              priority
              glow
              sizes="(max-width: 640px) 90vw, 300px"
            />
          </div>
        </div>
      </section>

      {/* ------------------------------------------------------------- hook */}
      <section className="border-b border-[var(--line)] bg-[var(--surface)]">
        <div className="rail-narrow py-12 text-center">
          <p className="display-3" style={{ color: `var(${accent}-text)` }}>
            {game.hook}
          </p>
        </div>
      </section>

      {/* ------------------------------------------------------ how it works */}
      <section id="how-it-works" className="section scroll-mt-24">
        <div className="rail grid gap-14 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,1fr)] lg:items-start">
          <div className="min-w-0">
            <SectionHeading eyebrow="How it works" title={`${game.name}, explained`} lede={game.summary} />

            <div className="mt-10 space-y-9">
              {game.sections.map((section) => (
                <div key={section.title}>
                  <h3 className="text-[1.25rem]">{section.title}</h3>
                  <ul className="mt-3 space-y-2.5">
                    {section.body.map((line) => (
                      <li key={line} className="flex gap-3">
                        <span
                          aria-hidden
                          className="mt-[0.62em] h-1.5 w-1.5 shrink-0 rounded-full"
                          style={{ background: `var(${accent})` }}
                        />
                        <span className="text-[0.9375rem] leading-[1.6] text-[var(--text-muted)] sm:text-base">
                          {line}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>

          <div className="min-w-0 lg:sticky lg:top-24">
            <GameRulesExample example={game.example} accentVar={accent} />
          </div>
        </div>
      </section>

      {/* --------------------------------------------------- bespoke visual */}
      {Visual && (
        <section className="section-tight bg-[var(--bg-deep)]">
          <div className="rail">
            <SectionHeading
              eyebrow="See it"
              title={visualHeading(game.slug)}
              lede={visualLede(game.slug)}
              align="center"
            />
            <div className="mx-auto mt-10 max-w-[760px]">
              <Visual />
            </div>
          </div>
        </section>
      )}

      {/* ------------------------------------------------- adjustable rules */}
      <section className="section">
        <div className="rail">
          <SectionHeading
            eyebrow="Adjustable rules"
            title="Set it up the way your group plays."
            lede={`Nobody plays ${game.name} exactly the same way. Rather than pick a winner, the app makes every one of these a setting you change before the round — and saves it as a preset for next time.`}
          />

          <ul className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {game.adjustable.map((rule) => (
              <li key={rule.name} className="card flex flex-col p-5">
                <div className="flex items-start justify-between gap-3">
                  <h3 className="text-[1.0625rem] leading-snug">{rule.name}</h3>
                  {rule.isDefault && (
                    <span
                      className="shrink-0 rounded-[var(--r-pill)] px-2.5 py-1 text-[0.6875rem] font-bold uppercase tracking-[0.08em]"
                      style={{ background: `var(${accent}-soft)`, color: `var(${accent}-text)` }}
                    >
                      Default
                    </span>
                  )}
                </div>
                <p className="mt-2 text-[0.875rem] leading-[1.5] text-[var(--text-muted)]">
                  {rule.text}
                </p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* --------------------------------------------------- why use the app */}
      <section className="on-dark relative overflow-hidden">
        <ContourBackdrop
          opacity={0.09}
          className="pointer-events-none absolute inset-0 h-full w-full text-[var(--sand-300)]"
        />
        <div className="rail relative grid gap-12 py-[var(--section-y)] lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)] lg:items-center">
          <div>
            <SectionHeading
              eyebrow="Why use the app"
              title={`What the app works out while you play ${game.name}.`}
              lede="None of this is hard. It is just tedious, and it is tedious at exactly the moment you want to be hitting your next shot."
            />
          </div>

          <ul className="space-y-4">
            {game.appDoes.map((line) => (
              <li key={line} className="flex gap-3.5">
                <Check size={20} className="mt-0.5 shrink-0 text-[var(--accent)]" />
                <span className="text-[0.9375rem] leading-[1.55] text-[var(--on-dark-muted)] sm:text-base">
                  {line}
                </span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* ------------------------------------------------------- vocabulary */}
      <section className="section-tight">
        <div className="rail">
          <SectionHeading
            eyebrow="Vocabulary"
            title={`${game.name} words worth knowing`}
            lede="The words that get used on the tee as though everyone already knows them."
          />
          <dl className="mt-10 grid gap-x-10 gap-y-6 sm:grid-cols-2 lg:grid-cols-3">
            {game.definitions.map((d) => (
              <div key={d.term} className="border-t border-[var(--line-strong)] pt-4">
                <dt
                  className="font-display text-[0.9375rem] font-bold uppercase tracking-[0.08em]"
                  style={{ color: `var(${accent}-text)` }}
                >
                  {d.term}
                </dt>
                <dd className="mt-1.5 text-[0.9375rem] leading-[1.5] text-[var(--text-muted)]">
                  {d.text}
                </dd>
              </div>
            ))}
          </dl>
        </div>
      </section>

      {/* -------------------------------------------------------------- FAQ */}
      <section className="section-tight bg-[var(--bg-deep)]">
        <div className="rail-narrow">
          <SectionHeading eyebrow="FAQ" title={`${game.name} questions`} align="center" />
          <FAQ items={game.faq} className="mt-10" />
        </div>
      </section>

      {/* ------------------------------------------------------ other games */}
      <section className="section-tight">
        <div className="rail">
          <h2 className="eyebrow mb-6">The other five games</h2>
          <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
            {others.map((g) => {
              const OtherMark = GAME_MARKS[g.slug]
              return (
                <li key={g.slug}>
                  <Link
                    href={`/games/${g.slug}`}
                    className="card flex min-h-[64px] items-center gap-3 p-4 transition-[transform,box-shadow] hover:-translate-y-0.5 hover:shadow-[var(--shadow-2)]"
                  >
                    <span
                      className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-[var(--r-sm)]"
                      style={{
                        background: `var(${g.accentVar}-soft)`,
                        color: `var(${g.accentVar})`,
                      }}
                    >
                      <OtherMark size={19} />
                    </span>
                    <span className="flex-1 font-display text-[0.9375rem] font-bold">{g.name}</span>
                    <ChevronRight size={16} className="text-[var(--text-faint)]" />
                  </Link>
                </li>
              )
            })}
          </ul>
        </div>
      </section>

      {/* -------------------------------------------------------------- CTA */}
      <section style={{ background: `var(${accent}-deep)`, color: 'var(--cream-100)' }}>
        <div className="rail py-[var(--section-y-tight)] text-center">
          <h2 className="display-2 mx-auto max-w-[18ch]">Play {game.name} this weekend.</h2>
          <p className="mx-auto mt-4 max-w-[46ch] text-[1.0625rem] opacity-85">
            The app explains it to whoever needs it and keeps the score for everybody.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <CTAButton
              href="/download"
              variant="accent"
              event={`download-cta-${game.slug}-footer`}
              className="!bg-[var(--cream-100)] !text-[var(--ink-900)]"
            >
              Get the App
            </CTAButton>
            <CTAButton
              href="/games"
              variant="ghost"
              className="!border-[rgba(255,255,255,0.4)] !text-[var(--cream-100)]"
            >
              Explore Games
            </CTAButton>
          </div>
        </div>
      </section>

      <JsonLd
        data={jsonLd(
          breadcrumbSchema([
            { name: 'Home', path: '/' },
            { name: 'Games', path: '/games' },
            { name: game.name, path: `/games/${game.slug}` },
          ]),
          faqSchema(game.faq),
        )}
      />
    </>
  )
}

/* ---------------------------------------------------------------- helpers */

function visualHeading(slug: string): string {
  switch (slug) {
    case 'vegas':
      return 'A 4 and a 5 make 45.'
    case 'skins':
      return 'One tie, and the tee is worth double.'
    case 'nassau':
      return 'Three matches, running at once.'
    case 'dots':
      return 'The dots, and the ones you invent.'
    case 'wolf':
      return 'Three ways to play the hole.'
    default:
      return 'How the match is written.'
  }
}

function visualLede(slug: string): string {
  switch (slug) {
    case 'vegas':
      return 'Not added. Written side by side, lowest first. The gap between the two numbers is what the hole is worth.'
    case 'skins':
      return 'The pot is always on screen before you hit, so everybody knows exactly what is at stake.'
    case 'nassau':
      return 'The front nine, the back nine and the overall — each one its own bet, each one settled separately.'
    case 'dots':
      return 'Six on by default, five more waiting, and room for whatever your group calls the one nobody else has heard of.'
    case 'wolf':
      return 'Safe and small, or alone and large. Every hole, one player has to decide.'
    default:
      return 'AS, 1 UP, dormie, 4 & 3 — the notation every match-play result is written in.'
  }
}
