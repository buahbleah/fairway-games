import { ogImage, OG_SIZE, OG_CONTENT_TYPE } from '@/lib/og'

export const alt = 'Six games. One app. — Fairway Games'
export const size = OG_SIZE
export const contentType = OG_CONTENT_TYPE

export default function Image() {
  return ogImage({
    eyebrow: 'The games',
    headline: 'Six games. One app.',
    sub: 'Wolf, Skins, Nassau, Vegas, Dots and Team Match Play — rules and scoring.',
  })
}
