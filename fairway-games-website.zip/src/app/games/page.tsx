import type { Metadata } from 'next'
import Link from 'next/link'
import { games } from '@/content/games'
import { pageMetadata, jsonLd, breadcrumbSchema } from '@/lib/seo'
import { GameCard } from '@/components/GameCard'
import { SectionHeading } from '@/components/SectionHeading'
import { CTAButton } from '@/components/CTAButton'
import { Breadcrumbs } from '@/components/Breadcrumbs'
import { JsonLd } from '@/components/JsonLd'
import { ContourBackdrop } from '@/components/Art'
import { GAME_MARKS } from '@/components/Icons'

export const metadata: Metadata = pageMetadata({
  title: 'Golf Side Games: Wolf, Skins, Nassau, Vegas, Dots and Match Play',
  description:
    'The six golf side games explained and compared — how many players each needs, how hard it is, and how long it takes to explain on the first tee. Rules for every one.',
  path: '/games',
  keywords: [
    'golf side games',
    'golf betting games',
    'golf games for four players',
    'golf games for 3 players',
    'golf games for friends',
    'best golf side games',
  ],
})

export default function GamesPage() {
  return (
    <>
      <section className="relative overflow-hidden border-b border-[var(--line)]">
        <ContourBackdrop
          opacity={0.08}
          className="pointer-events-none absolute inset-0 h-full w-full text-[var(--brand)]"
        />
        <div className="rail relative py-14 sm:py-20">
          <Breadcrumbs crumbs={[{ name: 'Home', path: '/' }, { name: 'Games', path: '/games' }]} />
          <h1 className="display-1 max-w-[16ch]">Six games. One app.</h1>
          <p className="lede mt-6">
            Every game below has its own rules page with a worked example, the settings you can
            change, and the answers to the questions that always come up on the first tee.
          </p>
        </div>
      </section>

      <section className="section" aria-labelledby="all-games">
        <div className="rail">
          {/* The cards are the page's main content and each carries an h3, so
              the outline needs an h2 here. It is visually redundant under the
              h1, hence sr-only rather than a decorative heading. */}
          <h2 id="all-games" className="sr-only">
            All six golf side games
          </h2>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {games.map((game) => (
              <GameCard key={game.slug} game={game} />
            ))}
          </div>
        </div>
      </section>

      {/* The comparison table — the thing people actually want on a games index */}
      <section className="section-tight bg-[var(--bg-deep)]">
        <div className="rail">
          <SectionHeading
            eyebrow="At a glance"
            title="Which game for which group?"
            lede="Three players and half an hour of daylight is a different problem from four players on the first tee of a golf trip."
          />

          <div className="mt-10 overflow-x-auto">
            <table className="w-full min-w-[680px] border-separate border-spacing-0">
              <caption className="sr-only">
                Comparison of the six golf side games by player count, complexity and how long they
                take to explain
              </caption>
              <thead>
                <tr>
                  {['Game', 'Players', 'Complexity', 'Explaining it', 'Best for'].map((h) => (
                    <th
                      key={h}
                      scope="col"
                      className="eyebrow border-b border-[var(--line-strong)] px-4 py-3 text-left"
                    >
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {games.map((g) => {
                  const Mark = GAME_MARKS[g.slug]
                  return (
                    <tr key={g.slug} className="group">
                      <th scope="row" className="border-b border-[var(--line)] px-4 py-4 text-left">
                        <Link
                          href={`/games/${g.slug}`}
                          className="inline-flex min-h-[44px] items-center gap-3 font-display text-[1.0625rem] font-bold transition-colors hover:text-[var(--brand)]"
                        >
                          <span
                            className="inline-flex h-9 w-9 items-center justify-center rounded-[var(--r-sm)]"
                            style={{
                              background: `var(${g.accentVar}-soft)`,
                              color: `var(${g.accentVar})`,
                            }}
                          >
                            <Mark size={19} />
                          </span>
                          {g.name}
                        </Link>
                      </th>
                      <td className="border-b border-[var(--line)] px-4 py-4 text-[0.9375rem] text-[var(--text-muted)]">
                        {g.players}
                      </td>
                      <td className="border-b border-[var(--line)] px-4 py-4 text-[0.9375rem] text-[var(--text-muted)]">
                        {g.complexity}
                      </td>
                      <td className="border-b border-[var(--line)] px-4 py-4 text-[0.9375rem] text-[var(--text-muted)]">
                        {g.explainTime}
                      </td>
                      <td className="border-b border-[var(--line)] px-4 py-4 text-[0.9375rem] text-[var(--text-muted)]">
                        {g.tagline}
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <section className="on-dark">
        <div className="rail py-[var(--section-y-tight)] text-center">
          <h2 className="display-3">Play any of them this weekend.</h2>
          <p className="mx-auto mt-4 max-w-[46ch] text-[var(--on-dark-muted)]">
            The app explains the rules to whoever needs them and does the maths for everybody.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <CTAButton href="/download" variant="accent">
              Get the App
            </CTAButton>
            <CTAButton href="/how-it-works" variant="ghost">
              See How It Works
            </CTAButton>
          </div>
        </div>
      </section>

      <JsonLd
        data={jsonLd(
          breadcrumbSchema([
            { name: 'Home', path: '/' },
            { name: 'Games', path: '/games' },
          ]),
          {
            '@type': 'ItemList',
            name: 'Golf side games supported by Fairway Games',
            itemListElement: games.map((g, i) => ({
              '@type': 'ListItem',
              position: i + 1,
              name: g.name,
              url: `/games/${g.slug}`,
            })),
          },
        )}
      />
    </>
  )
}
