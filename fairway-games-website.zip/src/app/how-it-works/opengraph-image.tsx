import { ogImage, OG_SIZE, OG_CONTENT_TYPE } from '@/lib/og'

export const alt = 'Four steps. Then play golf. — Fairway Games'
export const size = OG_SIZE
export const contentType = OG_CONTENT_TYPE

export default function Image() {
  return ogImage({
    eyebrow: 'How it works',
    headline: 'Four steps. Then play golf.',
    sub: 'Pick a game, add your group, enter scores, let the app do the maths.',
  })
}
