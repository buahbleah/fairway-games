import type { Metadata } from 'next'
import { steps } from '@/content/site'
import { games } from '@/content/games'
import { pageMetadata, jsonLd, breadcrumbSchema } from '@/lib/seo'
import { PhoneMockup } from '@/components/PhoneMockup'
import { CTAButton } from '@/components/CTAButton'
import { SectionHeading } from '@/components/SectionHeading'
import { Breadcrumbs } from '@/components/Breadcrumbs'
import { JsonLd } from '@/components/JsonLd'
import { ContourBackdrop } from '@/components/Art'
import { GAME_MARKS, Check } from '@/components/Icons'

export const metadata: Metadata = pageMetadata({
  title: 'How It Works: Golf Side Games in Four Steps',
  description:
    'Pick a game, add your group, play golf, and let the app do the maths. How Fairway Games scores Wolf, Skins, Nassau, Vegas, Dots and Team Match Play as you go.',
  path: '/how-it-works',
  keywords: ['golf scoring app how it works', 'golf side game scorer', 'golf games app tutorial'],
})

export default function HowItWorksPage() {
  return (
    <>
      <section className="relative overflow-hidden border-b border-[var(--line)]">
        <ContourBackdrop
          opacity={0.08}
          className="pointer-events-none absolute inset-0 h-full w-full text-[var(--brand)]"
        />
        <div className="rail relative py-14 sm:py-20">
          <Breadcrumbs
            crumbs={[{ name: 'Home', path: '/' }, { name: 'How It Works', path: '/how-it-works' }]}
          />
          <h1 className="display-1 max-w-[18ch]">Four steps. Then you go and play golf.</h1>
          <p className="lede mt-6">
            The whole point of the app is that it gets out of the way. Setup takes under a minute,
            and each hole takes a few seconds between two shots.
          </p>
          <div className="mt-8">
            <CTAButton href="/download" event="download-cta-hiw-hero">
              Get the App
            </CTAButton>
          </div>
        </div>
      </section>

      {steps.map((step, i) => (
        <section
          key={step.n}
          className={`section ${i % 2 === 1 ? 'bg-[var(--bg-deep)]' : ''}`}
        >
          <div
            className={`rail grid items-center gap-12 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)] lg:gap-16 ${
              i % 2 === 1 ? 'lg:[&>*:first-child]:order-2' : ''
            }`}
          >
            <div>
              <span
                className="num inline-flex h-14 w-14 items-center justify-center rounded-[var(--r-md)] text-[1.75rem]"
                style={{ background: 'var(--brand-soft)', color: 'var(--brand)' }}
              >
                {step.n}
              </span>
              <h2 className="display-2 mt-5">{step.title}</h2>
              <p className="lede mt-4">{step.body}</p>

              {step.n === 1 && (
                <ul className="mt-7 flex flex-wrap gap-2.5">
                  {games.map((g) => {
                    const Mark = GAME_MARKS[g.slug]
                    return (
                      <li
                        key={g.slug}
                        className="inline-flex min-h-[44px] items-center gap-2.5 rounded-[var(--r-pill)] border border-[var(--line-strong)] bg-[var(--surface)] px-4 text-[0.9375rem]"
                      >
                        <Mark size={17} style={{ color: `var(${g.accentVar})` }} />
                        {g.name}
                      </li>
                    )
                  })}
                </ul>
              )}

              {step.n === 2 && (
                <ul className="mt-7 space-y-3">
                  {[
                    'Saved players make it a few taps, not a form.',
                    'One switch evens it up with handicaps — and shows what everyone plays off before anyone tees off.',
                    'Save the whole setup as a preset for next Saturday.',
                  ].map((line) => (
                    <li key={line} className="flex gap-3">
                      <Check size={19} className="mt-0.5 shrink-0 text-[var(--good)]" />
                      <span className="text-[0.9375rem] leading-[1.55] text-[var(--text-muted)]">
                        {line}
                      </span>
                    </li>
                  ))}
                </ul>
              )}

              {step.n === 3 && (
                <ul className="mt-7 space-y-3">
                  {[
                    'Score entry defaults to par, so a par is one tap and a birdie is two.',
                    'The steppers are 56px squares, sized for a gloved thumb rather than a mouse.',
                    'Nothing advances underneath you — the result stays on screen until you leave it.',
                    'Undo is always one tap away and says what it will undo.',
                  ].map((line) => (
                    <li key={line} className="flex gap-3">
                      <Check size={19} className="mt-0.5 shrink-0 text-[var(--good)]" />
                      <span className="text-[0.9375rem] leading-[1.55] text-[var(--text-muted)]">
                        {line}
                      </span>
                    </li>
                  ))}
                </ul>
              )}

              {step.n === 4 && (
                <ul className="mt-7 space-y-3">
                  {[
                    'Points, teams, carries, presses and match status all update themselves.',
                    'The leaderboard shows movement as well as position.',
                    'Any earlier hole can be corrected and everything recalculates instantly.',
                    'The final result is on screen the moment the 18th is in.',
                  ].map((line) => (
                    <li key={line} className="flex gap-3">
                      <Check size={19} className="mt-0.5 shrink-0 text-[var(--good)]" />
                      <span className="text-[0.9375rem] leading-[1.55] text-[var(--text-muted)]">
                        {line}
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <div className="flex justify-center">
              <PhoneMockup
                src={step.screenshot}
                alt={step.alt}
                width={300}
                glow={i === 0}
                sizes="(max-width: 640px) 90vw, 300px"
              />
            </div>
          </div>
        </section>
      ))}

      <section className="on-dark relative overflow-hidden">
        <ContourBackdrop
          opacity={0.1}
          className="pointer-events-none absolute inset-0 h-full w-full text-[var(--sand-300)]"
        />
        <div className="rail relative py-[var(--section-y)]">
          <SectionHeading
            eyebrow="Underneath"
            title="One idea makes all of it work."
            lede="A round is stored as the setup plus a list of holes. Everything else — standings, match status, presses, carries, the final result — is worked out from those holes every time they change."
            align="center"
          />
          <ul className="mx-auto mt-10 grid max-w-[900px] gap-4 sm:grid-cols-3">
            {[
              { t: 'Undo works', b: 'Because nothing is stored as a running total, undoing a hole is just removing it.' },
              { t: 'Editing works', b: 'Fix the 4th on the 12th tee and the whole round recalculates in front of you.' },
              { t: 'Resuming works', b: 'Close the app mid-round and reopen it: there is no hidden state to lose.' },
            ].map((c) => (
              <li
                key={c.t}
                className="rounded-[var(--r-lg)] border border-[var(--on-dark-line)] p-6"
                style={{ background: 'var(--on-dark-surface)' }}
              >
                <h3 className="text-[1.125rem]">{c.t}</h3>
                <p className="mt-2 text-[0.9375rem] leading-[1.5] text-[var(--on-dark-muted)]">
                  {c.b}
                </p>
              </li>
            ))}
          </ul>

          <div className="mt-12 flex flex-wrap justify-center gap-3">
            <CTAButton href="/download" variant="accent" event="download-cta-hiw-footer">
              Start Playing
            </CTAButton>
            <CTAButton href="/games" variant="ghost">
              Explore Games
            </CTAButton>
          </div>
        </div>
      </section>

      <JsonLd
        data={jsonLd(
          breadcrumbSchema([
            { name: 'Home', path: '/' },
            { name: 'How It Works', path: '/how-it-works' },
          ]),
          {
            '@type': 'HowTo',
            name: 'How to score a golf side game with Fairway Games',
            step: steps.map((s) => ({
              '@type': 'HowToStep',
              position: s.n,
              name: s.title,
              text: s.body,
            })),
          },
        )}
      />
    </>
  )
}
