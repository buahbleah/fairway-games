import type { Metadata, Viewport } from 'next'
import { siteConfig } from '@config'
import { Header } from '@/components/Header'
import { Footer } from '@/components/Footer'
import { StickyMobileCTA } from '@/components/StickyMobileCTA'
import { JsonLd } from '@/components/JsonLd'
import { jsonLd, organizationSchema, websiteSchema, appSchema } from '@/lib/seo'
import { Analytics } from '@/components/Analytics'
import './globals.css'

export const metadata: Metadata = {
  metadataBase: new URL(siteConfig.url),
  title: {
    default: `${siteConfig.name} — Golf Side Games, Scored For You`,
    template: `%s · ${siteConfig.name}`,
  },
  description: siteConfig.description,
  applicationName: siteConfig.name,
  authors: [{ name: siteConfig.name }],
  creator: siteConfig.name,
  publisher: siteConfig.name,
  category: 'sports',
  formatDetection: { telephone: false },
  icons: {
    icon: [
      { url: '/brand/app-icon.svg', type: 'image/svg+xml' },
      { url: '/brand/app-icon-192.png', sizes: '192x192', type: 'image/png' },
    ],
    apple: [{ url: '/brand/apple-touch-icon.png', sizes: '180x180' }],
  },
  manifest: '/manifest.webmanifest',
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, 'max-image-preview': 'large', 'max-snippet': -1 },
  },
}

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  viewportFit: 'cover',
  // Dark is the default, so the browser chrome matches the green ground
  // regardless of the operating system's setting.
  themeColor: '#0a1f17',
}

/**
 * Applies a stored LIGHT preference before first paint.
 *
 * Dark is the default and lives on bare `:root` in tokens.css, so this script
 * only ever has to add an attribute, never remove one — which means a visitor
 * with JavaScript off, or blocked storage, still gets the intended green
 * ground rather than a flash of cream.
 */
const THEME_SCRIPT = `try{var t=localStorage.getItem('fw-theme');if(t==='light'){document.documentElement.setAttribute('data-theme','light')}}catch(e){}`

/**
 * LEGACY HOME-SCREEN INSTALLS
 *
 * The app used to live at the root of this domain, so anyone who used "Add to
 * Home Screen" back then has an icon whose start_url is "/". After the domain
 * moved they would tap it and land on a marketing page instead of the app.
 *
 * This site's own manifest is display:'browser', so it can never launch
 * standalone. A standalone launch on this origin therefore means exactly one
 * thing — a leftover install of the app — and the right response is to send it
 * where it meant to go. Only from the home page, so a shared deep link into the
 * site still opens the page it points at.
 */
const LEGACY_APP_SCRIPT = `try{
var standalone = (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) || window.navigator.standalone === true;
if (standalone && (location.pathname === '/' || location.pathname === '')) { location.replace('/play/'); }
}catch(e){}`

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: THEME_SCRIPT }} />
        <script dangerouslySetInnerHTML={{ __html: LEGACY_APP_SCRIPT }} />
      </head>
      <body className="flex min-h-dvh flex-col">
        <a href="#main" className="skip-link">
          Skip to content
        </a>
        <Header />
        <main id="main" className="flex-1">
          {children}
        </main>
        <Footer />
        <StickyMobileCTA />
        <Analytics />
        <JsonLd data={jsonLd(organizationSchema(), websiteSchema(), appSchema())} />
      </body>
    </html>
  )
}
