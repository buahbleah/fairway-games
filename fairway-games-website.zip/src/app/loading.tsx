/**
 * The loading state.
 *
 * Deliberately a skeleton in the shape of a page rather than a spinner: it
 * shows up on a slow connection between route transitions, and a layout that
 * already looks like the destination feels faster than a spinner does.
 */
export default function Loading() {
  return (
    <div className="rail py-16" aria-busy="true" aria-live="polite">
      <span className="sr-only">Loading</span>
      <div className="max-w-[36rem] space-y-4">
        <div className="h-4 w-32 rounded-[var(--r-xs)] bg-[var(--surface-2)]" />
        <div className="h-12 w-full rounded-[var(--r-sm)] bg-[var(--surface-2)]" />
        <div className="h-12 w-3/4 rounded-[var(--r-sm)] bg-[var(--surface-2)]" />
        <div className="h-4 w-full rounded-[var(--r-xs)] bg-[var(--surface-2)]" />
        <div className="h-4 w-5/6 rounded-[var(--r-xs)] bg-[var(--surface-2)]" />
      </div>
      <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {[0, 1, 2, 3, 4, 5].map((i) => (
          <div key={i} className="h-56 rounded-[var(--r-lg)] bg-[var(--surface-2)]" />
        ))}
      </div>
    </div>
  )
}
