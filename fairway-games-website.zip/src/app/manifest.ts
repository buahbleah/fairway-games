import type { MetadataRoute } from 'next'
import { siteConfig } from '@config'

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: siteConfig.name,
    short_name: siteConfig.shortName,
    description: siteConfig.description,
    start_url: '/',
    // Deliberately 'browser': this is a website, not an app. The app itself
    // lives at /play and ships its own manifest.
    display: 'browser',
    background_color: '#0e2b21',
    theme_color: '#0e2b21',
    categories: ['sports'],
    icons: [
      { src: '/brand/app-icon-192.png', sizes: '192x192', type: 'image/png' },
      { src: '/brand/app-icon-512.png', sizes: '512x512', type: 'image/png' },
    ],
  }
}
