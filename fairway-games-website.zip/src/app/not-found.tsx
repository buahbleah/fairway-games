import Link from 'next/link'
import { CTAButton } from '@/components/CTAButton'
import { EmptyGreen, ContourBackdrop } from '@/components/Art'
import { games } from '@/content/games'
import { GAME_MARKS } from '@/components/Icons'

export const metadata = {
  title: 'Page not found',
  robots: { index: false, follow: true },
}

export default function NotFound() {
  return (
    <section className="relative overflow-hidden">
      <ContourBackdrop
        opacity={0.08}
        className="pointer-events-none absolute inset-0 h-full w-full text-[var(--brand)]"
      />
      <div className="rail relative flex flex-col items-center py-20 text-center sm:py-28">
        <EmptyGreen className="h-auto w-[240px] max-w-full" />

        <p className="eyebrow mt-8">Error 404</p>
        <h1 className="display-1 mt-3 max-w-[16ch]">Lost your ball?</h1>
        <p className="lede mx-auto mt-5">
          We could not find this page. It might have moved, or the link might have been mistyped.
        </p>

        <div className="mt-9 flex flex-wrap justify-center gap-3">
          <CTAButton href="/">Back to the Clubhouse</CTAButton>
          <CTAButton href="/games" variant="secondary">
            Explore Games
          </CTAButton>
        </div>

        <div className="mt-14 w-full max-w-[760px]">
          <p className="eyebrow mb-4">Or drop straight into a game</p>
          <ul className="flex flex-wrap justify-center gap-2.5">
            {games.map((g) => {
              const Mark = GAME_MARKS[g.slug]
              return (
                <li key={g.slug}>
                  <Link
                    href={`/games/${g.slug}`}
                    className="inline-flex min-h-[48px] items-center gap-2.5 rounded-[var(--r-pill)] border border-[var(--line-strong)] bg-[var(--surface)] px-4 text-[0.9375rem] transition-colors hover:border-[var(--brand)]"
                  >
                    <Mark size={17} style={{ color: `var(${g.accentVar})` }} />
                    {g.name}
                  </Link>
                </li>
              )
            })}
          </ul>
        </div>
      </div>
    </section>
  )
}
