import { ogImage, OG_SIZE, OG_CONTENT_TYPE } from '@/lib/og'

export const alt = 'Fairway Games — six golf side games, scored in seconds'
export const size = OG_SIZE
export const contentType = OG_CONTENT_TYPE

export default function Image() {
  return ogImage({
    eyebrow: 'Golf side games',
    headline: 'Play more. Calculate less.',
    sub: 'Wolf, Skins, Nassau, Vegas and more — scored for you, between two shots.',
  })
}
