import Link from 'next/link'
import Image from 'next/image'
import type { Metadata } from 'next'
import { siteConfig } from '@config'
import { games } from '@/content/games'
import { generalFaq } from '@/content/site'
import { pageMetadata, jsonLd, faqSchema } from '@/lib/seo'
import { CTAButton } from '@/components/CTAButton'
import { DownloadButtons } from '@/components/DownloadButtons'
import { AppLanding } from '@/components/AppLanding'
import { PhoneMockup } from '@/components/PhoneMockup'
import { GameCard } from '@/components/GameCard'
import { SectionHeading } from '@/components/SectionHeading'
import { FAQ } from '@/components/FAQ'
import { JsonLd } from '@/components/JsonLd'
import { ContourBackdrop, RidgeDivider, BrandCrest } from '@/components/Art'
import {
  Offline,
  Players,
  Settings,
  Trophy,
  ChevronRight,
  Check,
  Handicap,
} from '@/components/Icons'

export const metadata: Metadata = pageMetadata({
  title: `${siteConfig.name} — Golf Side Games, Scored For You`,
  description: siteConfig.description,
  path: '/',
  keywords: [
    'golf games app',
    'golf side games',
    'golf betting games',
    'golf games for four players',
    'golf games for 3 players',
    'golf games for friends',
    'wolf golf app',
    'golf skins app',
  ],
})

export default function HomePage() {
  return (
    <>
      <Hero />
      <ValueStrip />
      <FirstTee />
      <GameModes />
      <Showcase />
      <HouseRules />
      <OfflineSection />
      <GolfTrips />
      <HomeFaq />
      <FinalCTA />
      <JsonLd data={jsonLd(faqSchema(generalFaq.slice(0, 8)))} />
    </>
  )
}

/* ------------------------------------------------------------------- hero */

/**
 * The homepage leads with the app itself — icon, store buttons, what you can
 * install today — rather than with an explanation of it. Someone arriving from
 * a link should be able to get the app without scrolling; the case for why
 * follows underneath for anyone who wants it.
 *
 * The block is shared with /download so the two can never disagree about
 * availability. See components/AppLanding.tsx.
 */
function Hero() {
  return (
    <AppLanding
      backdrop="fairway"
      headline={
        <>
          Your golf games.
          <br />
          <span className="text-[var(--brand)]">No scorekeeping headaches.</span>
        </>
      }
      lede="Play Wolf, Skins, Nassau, Vegas and more with your group. The app tracks the rules, points, teams and standings so you can focus on golf."
      phoneSrc="/app/05-wolf-pick.webp"
      phoneAlt="Fairway Games on hole 1 of a Wolf round: Marc is the Wolf, with Partner buttons beside Phil, Mike and John, plus Lone Wolf and Blind Wolf at double points."
      secondary={
        <div className="mt-7 grid gap-3 sm:flex sm:flex-wrap">
          <CTAButton href="/games" variant="secondary" size="md">
            Explore the Games
          </CTAButton>
          <CTAButton href="/how-it-works" variant="ghost" size="md">
            See How It Works
          </CTAButton>
        </div>
      }
    />
  )
}

/* ------------------------------------------------------------ value strip */

function ValueStrip() {
  const items = [
    {
      icon: Trophy,
      title: '6 game modes',
      body: 'Wolf, Skins, Nassau, Vegas, Dots and Team Match Play.',
    },
    {
      icon: Offline,
      title: 'Offline first',
      body: 'Works even when reception on the course is bad.',
    },
    { icon: Players, title: '3–4 players', body: 'Made for golf groups, not for solo practice.' },
    { icon: Settings, title: 'Custom rules', body: 'Adjust the points and your group’s house rules.' },
  ]

  return (
    <section className="border-y border-[var(--line)] bg-[var(--surface)]">
      <div className="rail grid gap-x-8 gap-y-8 py-12 sm:grid-cols-2 lg:grid-cols-4">
        {items.map(({ icon: Icon, title, body }) => (
          <div key={title} className="flex gap-4">
            <span
              className="mt-0.5 inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-[var(--r-md)] text-[var(--brand)]"
              style={{ background: 'var(--brand-soft)' }}
            >
              <Icon size={22} />
            </span>
            <div>
              <h2 className="text-[1.0625rem]">{title}</h2>
              <p className="mt-1 text-[0.875rem] leading-[1.5] text-[var(--text-muted)]">{body}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}

/* -------------------------------------------------------------- first tee */

function FirstTee() {
  const beats = [
    'Your group wants to play Wolf.',
    'One person remembers one rule.',
    'Another plays it differently.',
    'Someone has to work out the points.',
    'By hole 6 nobody knows the score.',
  ]

  return (
    <section className="section">
      <div className="rail grid items-center gap-14 lg:grid-cols-[minmax(0,0.92fr)_minmax(0,1.08fr)]">
        <div>
          <SectionHeading
            eyebrow="The problem"
            title="Made for the first tee."
            lede="Everybody has had this round. It is always the same five minutes."
          />

          <ol className="mt-8 space-y-0">
            {beats.map((beat, i) => (
              <li
                key={beat}
                className="flex gap-5 border-l-2 pb-5 pl-6 last:pb-0"
                style={{
                  borderColor: i === beats.length - 1 ? 'var(--bad)' : 'var(--line-strong)',
                }}
              >
                <span
                  className="num shrink-0 text-[1.125rem] leading-[1.4]"
                  style={{
                    color: i === beats.length - 1 ? 'var(--bad-text)' : 'var(--text-muted)',
                  }}
                >
                  {i + 1}
                </span>
                <p
                  className="text-[1.0625rem] leading-[1.45]"
                  style={{
                    color: i === beats.length - 1 ? 'var(--text)' : 'var(--text-muted)',
                    fontWeight: i === beats.length - 1 ? 600 : 400,
                  }}
                >
                  {beat}
                </p>
              </li>
            ))}
          </ol>

          <div
            className="mt-8 rounded-[var(--r-lg)] p-6"
            style={{ background: 'var(--brand-soft)' }}
          >
            <p className="display-3 text-[var(--brand-strong)]">
              You play the hole.
              <br />
              We keep the score.
            </p>
            <Link
              href="/how-it-works"
              className="mt-4 inline-flex min-h-[44px] items-center gap-1.5 font-display text-[0.9375rem] font-bold uppercase tracking-[0.06em] text-[var(--brand-strong)]"
            >
              See how it works
              <ChevronRight size={17} />
            </Link>
          </div>
        </div>

        {/* Three screens: pick the game, pick the players, start. */}
        <div className="grid grid-cols-3 items-end gap-2 sm:gap-4">
          {[
            { src: '/app/02-game-select.webp', alt: 'Choosing a game from the six on offer.', label: 'Choose game', tilt: -3 },
            { src: '/app/04-setup-players.webp', alt: 'Selecting the players for the round.', label: 'Add players', tilt: 0 },
            { src: '/app/06-wolf-scores.webp', alt: 'Entering scores with large plus and minus steppers.', label: 'Start round', tilt: 3 },
          ].map((s, i) => (
            <figure key={s.src} className="flex flex-col items-center gap-3">
              <PhoneMockup
                src={s.src}
                alt={s.alt}
                width={230}
                tilt={s.tilt}
                sizes="(max-width: 640px) 30vw, 230px"
                className={i === 1 ? 'z-10' : ''}
              />
              <figcaption className="eyebrow text-center">{s.label}</figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ------------------------------------------------------------- game modes */

function GameModes() {
  return (
    <section id="games" className="section bg-[var(--bg-deep)]">
      <div className="rail">
        <SectionHeading
          eyebrow="The games"
          title="Six games your group already plays."
          lede="Each one has its own rules screen, its own settings and its own worked example — so nobody has to be the person who knows the rules."
          align="center"
        />

        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {games.map((game) => (
            <GameCard key={game.slug} game={game} />
          ))}
        </div>

        <p className="mt-10 text-center text-[0.9375rem] text-[var(--text-muted)]">
          More formats are on the way — Bingo Bango Bongo and Sixes are next.{' '}
          <Link href="/games" className="text-[var(--brand)] underline underline-offset-4">
            Compare all six games
          </Link>
        </p>
      </div>
    </section>
  )
}

/* --------------------------------------------------------------- showcase */

function Showcase() {
  const screens = [
    { src: '/app/01-home.webp', alt: 'The Fairway Games home screen with the six game cards.', label: 'Home' },
    { src: '/app/05-wolf-pick.webp', alt: 'The Wolf partner-selection screen.', label: 'Wolf' },
    { src: '/app/10-vegas.webp', alt: 'The Vegas screen with both team numbers.', label: 'Vegas' },
    { src: '/app/13-leaderboard.webp', alt: 'The live leaderboard with each player’s movement.', label: 'Leaderboard' },
    { src: '/app/23-handicaps.webp', alt: 'The handicap screen showing what each player plays off.', label: 'Handicaps' },
    { src: '/app/14-result.webp', alt: 'The result screen with the winner and the final standings.', label: 'Result' },
  ]

  return (
    <section className="on-dark relative overflow-hidden">
      <ContourBackdrop
        opacity={0.1}
        className="pointer-events-none absolute inset-0 h-full w-full text-[var(--sand-300)]"
      />

      <div className="relative section-tight">
        <div className="rail">
          <SectionHeading
            eyebrow="Inside the app"
            title="Built to be looked at for four seconds."
            lede="Big numbers, big buttons, one decision on screen at a time. These are real screens from the product, not marketing mock-ups."
            align="center"
          />
        </div>

        {/* Horizontal snap rail on mobile, layered arrangement on desktop. */}
        <div className="mt-12">
          <ul className="snap-rail no-scrollbar lg:hidden">
            {screens.map((s) => (
              <li key={s.src} className="flex flex-col items-center gap-3">
                <PhoneMockup src={s.src} alt={s.alt} width={215} sizes="215px" />
                <span className="eyebrow">{s.label}</span>
              </li>
            ))}
          </ul>

          <div className="rail-wide hidden lg:block">
            <ul className="flex items-center justify-center">
              {screens.map((s, i) => {
                const offset = i - (screens.length - 1) / 2
                return (
                  <li
                    key={s.src}
                    className="group flex flex-col items-center gap-4 transition-transform duration-[var(--dur-card)] ease-[var(--ease-out)] hover:z-20 hover:-translate-y-3"
                    style={{
                      marginInline: '-14px',
                      zIndex: 10 - Math.abs(offset),
                      transform: `rotate(${offset * 2}deg) translateY(${Math.abs(offset) * 11}px)`,
                    }}
                  >
                    <PhoneMockup src={s.src} alt={s.alt} width={196} sizes="196px" />
                    <span className="eyebrow opacity-0 transition-opacity group-hover:opacity-100">
                      {s.label}
                    </span>
                  </li>
                )
              })}
            </ul>
          </div>
        </div>
      </div>

      <RidgeDivider className="block h-[70px] w-full text-[var(--bg)]" />
    </section>
  )
}

/* ------------------------------------------------------------- house rules */

function HouseRules() {
  const knobs = [
    'Points',
    'Carry-overs',
    'Handicaps',
    'Presses',
    'Flip rules',
    'Caps',
    'Dot achievements',
    'Team rotations',
  ]

  return (
    <section className="section">
      <div className="rail grid items-center gap-14 lg:grid-cols-[minmax(0,1.05fr)_minmax(0,1fr)]">
        <div className="order-2 flex justify-center lg:order-1">
          <PhoneMockup
            src="/app/23-handicaps.webp"
            alt="The Wolf settings sheet: an “even it up with handicaps” switch showing the shots each player receives, and steppers for the Wolf and Hunters point values."
            width={300}
            sizes="(max-width: 640px) 90vw, 300px"
          />
        </div>

        <div className="order-1 lg:order-2">
          <SectionHeading
            eyebrow="House rules"
            title="Your group. Your rules."
            lede="Golf games are rarely played the same way twice, let alone at two different clubs. Rather than pick a winner, the app lets you set it up the way your group already plays."
          />

          <ul className="mt-8 flex flex-wrap gap-2.5">
            {knobs.map((k) => (
              <li
                key={k}
                className="inline-flex min-h-[44px] items-center rounded-[var(--r-pill)] border border-[var(--line-strong)] bg-[var(--surface)] px-4 text-[0.9375rem]"
              >
                {k}
              </li>
            ))}
          </ul>

          <div className="mt-8 flex items-start gap-4 rounded-[var(--r-lg)] border border-[var(--line)] p-5">
            <span
              className="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-[var(--r-md)] text-[var(--accent)]"
              style={{ background: 'var(--accent-soft)' }}
            >
              <Handicap size={22} />
            </span>
            <p className="text-[0.9375rem] leading-[1.55] text-[var(--text-muted)]">
              <strong className="text-[var(--text)]">Set it once.</strong> Save your Saturday Wolf
              rules as a preset and next week the whole round is set up in one tap — same points,
              same carries, same arguments already settled.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}

/* ---------------------------------------------------------------- offline */

function OfflineSection() {
  return (
    <section className="section bg-[var(--bg-deep)]">
      <div className="rail grid items-center gap-14 lg:grid-cols-[minmax(0,1fr)_minmax(0,0.85fr)]">
        <div>
          <SectionHeading
            eyebrow="Offline"
            title="No signal? No problem."
            lede="Golf courses have dead spots — the back of the 12th, the trees on the 4th, the whole of a valley course. The app is built for that rather than hoping for it."
          />

          <ul className="mt-8 space-y-4">
            {[
              'The round, your players and your presets live on the phone, not in the cloud.',
              'Close the app, lock the phone, reopen it three holes later — the round is exactly where you left it.',
              'Scores entered with no signal go up the moment coverage comes back.',
              'When four people score the same hole from four phones, the scores merge player by player. A queued write from twenty minutes ago never wipes out somebody else’s number.',
            ].map((line) => (
              <li key={line} className="flex gap-3.5">
                <Check size={20} className="mt-1 shrink-0 text-[var(--good)]" />
                <span className="text-[0.9375rem] leading-[1.55] text-[var(--text-muted)] sm:text-base">
                  {line}
                </span>
              </li>
            ))}
          </ul>
        </div>

        {/* The offline state, drawn rather than screenshotted so the copy is exact. */}
        <div className="flex justify-center">
          <div className="card w-full max-w-[340px] overflow-hidden">
            <div
              className="flex items-center justify-between px-5 py-3.5 text-[0.8125rem]"
              style={{ background: 'var(--accent-soft)', color: 'var(--on-accent-soft)' }}
            >
              <span className="flex items-center gap-2 font-medium">
                <Offline size={16} />
                No connection
              </span>
              <span>2 holes queued</span>
            </div>
            <div className="px-6 py-8 text-center">
              <p className="eyebrow">Round saved</p>
              <p
                className="num mt-2 leading-none"
                style={{ fontSize: 'clamp(3rem, 2rem + 5vw, 4.25rem)' }}
              >
                12
                <span className="text-[var(--text-muted)]">/18</span>
              </p>
              <p className="mt-2 text-[0.875rem] text-[var(--text-muted)]">
                Skins · 3 skins carried
              </p>
              <p className="mt-6 text-[0.875rem] leading-[1.5] text-[var(--text-muted)]">
                Everything is on the phone. Nothing is waiting on a bar of signal.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

/* ------------------------------------------------------------- golf trips */

function GolfTrips() {
  const uses = [
    { title: 'Weekend trips', body: 'Four courses, three games, one running total across the lot.' },
    { title: 'Golf holidays', body: 'A league that keeps every round of the week in one place.' },
    { title: 'Club groups', body: 'Saved players and saved presets, so setup takes seconds.' },
    { title: 'Saturday foursomes', body: 'The same game, the same rules, every week, without the argument.' },
    { title: 'Ryder Cup weekends', body: 'Team Match with rotating pairs — everyone partners everyone.' },
    { title: 'Society days', body: 'Skins with a progressive pot so the 18th decides it.' },
  ]

  return (
    <section className="on-dark section relative overflow-hidden">
      <ContourBackdrop
        opacity={0.08}
        className="pointer-events-none absolute inset-0 h-full w-full text-[var(--sand-300)]"
      />
      <div className="rail relative">
        <SectionHeading
          eyebrow="Groups and trips"
          title="Built for golf trips."
          lede="Different courses. Different groups. Different games. One app that remembers all of it."
          align="center"
        />

        <ul className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {uses.map((u) => (
            <li
              key={u.title}
              className="rounded-[var(--r-lg)] border border-[var(--on-dark-line)] p-6"
              style={{ background: 'var(--on-dark-surface)' }}
            >
              <h3 className="text-[1.125rem]">{u.title}</h3>
              <p className="mt-2 text-[0.9375rem] leading-[1.5] text-[var(--on-dark-muted)]">
                {u.body}
              </p>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}

/* --------------------------------------------------------------- home FAQ */

function HomeFaq() {
  return (
    <section className="section">
      <div className="rail-narrow">
        <SectionHeading
          eyebrow="Questions"
          title="The things golfers ask first."
          align="center"
        />
        <FAQ items={generalFaq.slice(0, 6)} className="mt-10" />
        <p className="mt-8 text-center">
          <Link
            href="/faq"
            className="inline-flex min-h-[48px] items-center gap-1.5 font-display text-[0.9375rem] font-bold uppercase tracking-[0.06em] text-[var(--brand)]"
          >
            All questions
            <ChevronRight size={17} />
          </Link>
        </p>
      </div>
    </section>
  )
}

/* --------------------------------------------------------------- final CTA */

function FinalCTA() {
  return (
    <section className="on-dark relative overflow-hidden">
      <ContourBackdrop
        opacity={0.12}
        className="pointer-events-none absolute inset-0 h-full w-full text-[var(--sand-300)]"
      />
      <div className="rail relative py-[var(--section-y)] text-center">
        <div className="mx-auto mb-8 w-fit">
          <Image
            src="/brand/app-icon-512.webp"
            alt=""
            width={104}
            height={104}
            className="rounded-[22px] shadow-[var(--shadow-3)]"
          />
        </div>

        <h2 className="display-2 mx-auto max-w-[20ch]">Your next golf game starts here.</h2>

        {/* A list rather than one string, so a wrap never strands a separator
            at the end of a line. */}
        <ul className="mx-auto mt-5 flex max-w-[46ch] flex-wrap items-center justify-center gap-x-3 gap-y-1 font-display text-[1.125rem] uppercase tracking-[0.08em] text-[var(--accent)]">
          {games.map((g, i) => (
            <li key={g.slug} className="flex items-center gap-3">
              {g.name}
              {i < games.length - 1 && (
                <span aria-hidden className="text-[var(--on-dark-muted)]">
                  ·
                </span>
              )}
            </li>
          ))}
        </ul>

        <ul className="mx-auto mt-8 flex max-w-fit flex-col gap-2 text-[1.0625rem] text-[var(--on-dark-muted)] sm:flex-row sm:gap-8">
          {['No paper.', 'No calculators.', 'No arguments about the score.'].map((line) => (
            <li key={line}>{line}</li>
          ))}
        </ul>

        <DownloadButtons className="mt-10" align="center" onDark />

        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <CTAButton href="/download" variant="ghost" size="md" event="download-cta-final">
            All the ways to install it
          </CTAButton>
        </div>

        <p className="mt-8 flex items-center justify-center gap-2.5 text-[0.875rem] text-[var(--on-dark-muted)]">
          <BrandCrest size={22} />
          {siteConfig.tagline}
        </p>
      </div>
    </section>
  )
}
