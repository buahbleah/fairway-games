import type { Metadata } from 'next'
import { siteConfig } from '@config'
import { pageMetadata } from '@/lib/seo'
import { LegalPage, Placeholder } from '@/components/LegalPage'

export const metadata: Metadata = pageMetadata({
  title: 'Privacy Policy',
  description:
    'What Fairway Games stores, why, who can see it and how to delete it. No advertising, no analytics, no tracking.',
  path: '/privacy',
})

/**
 * This mirrors the policy shipped inside the app (src/screens/Privacy.tsx in
 * the app repo). The two must not drift: if the app starts collecting
 * something else, both have to change.
 *
 * Both app stores require a reachable privacy policy URL before they will
 * accept a build with sign-in. This page is that URL.
 */
export default function PrivacyPage() {
  const contact = siteConfig.contact.email

  return (
    <LegalPage
      title="Privacy Policy"
      updated="24 August 2026"
      intro="Written to describe what the app actually does, in the order a person would ask about it."
      crumbLabel="Privacy"
      path="/privacy"
    >
      <h2>The short version</h2>
      <ul>
        <li>You can play without an account. Those rounds never leave your phone.</li>
        <li>
          If you sign in, we store what your golf group needs to see: your name, email, handicap,
          optional photo, and the rounds you share.
        </li>
        <li>No advertising, no analytics, no tracking, and nothing sold to anybody.</li>
        <li>You can delete your account, and everything with it, from inside the app.</li>
      </ul>

      <h2>Who is responsible</h2>
      <p>
        The controller for the purposes of the GDPR and the Swiss FADP is{' '}
        <Placeholder>{siteConfig.contact.company}</Placeholder>,{' '}
        <Placeholder>{siteConfig.contact.address}</Placeholder>. Contact:{' '}
        <a href={`mailto:${contact}`}>{contact}</a>.
      </p>

      <h2>What is stored, and why</h2>
      <ul>
        <li>
          <strong>Your email</strong> — to sign you in and to let friends add you. Nobody can see it
          except people you play with.
        </li>
        <li>
          <strong>Your name, handicap and photo</strong> — shown to the people in your rounds and
          leagues. The photo is optional and is shrunk on your phone before it is sent.
        </li>
        <li>
          <strong>Your password</strong> — stored only as a scrypt hash. We cannot read it.
        </li>
        <li>
          <strong>Rounds, scores and leagues</strong> — so a shared round appears on everyone’s
          phone and the group can look back at past games.
        </li>
        <li>
          <strong>A session token</strong> — a cookie in the browser, or a token stored on the
          device in the app, so you stay signed in.
        </li>
      </ul>

      <h2>What is not collected</h2>
      <ul>
        <li>No location, no contacts, no camera access beyond a photo you pick yourself.</li>
        <li>No advertising identifiers and no third-party trackers or SDKs.</li>
        <li>No analytics of how you use the app.</li>
      </ul>

      <h2>This website</h2>
      <p>
        This site sets no cookies and runs no analytics, which is why there is no cookie banner —
        there is nothing to consent to. Your browser’s light or dark preference is remembered in
        local storage on your own device and is never sent anywhere. The site is hosted on Vercel,
        whose servers keep standard access logs (IP address, user agent, requested page) for
        security and abuse prevention.
      </p>
      <p>
        If cookieless analytics are ever added, this paragraph and the config in the repository
        change together, and anything requiring consent gets a consent gate first.
      </p>

      <h2>Who else can see it</h2>
      <ul>
        <li>
          <strong>People you play with</strong> — your name, photo, handicap and scores in rounds you
          share, and your name in leagues you join.
        </li>
        <li>
          <strong>Our hosting providers</strong> — the app runs on Vercel and the database is Neon.
          They process data on our behalf and do not use it for anything else.
        </li>
        <li>Nobody else. Your data is not sold, shared or used for advertising.</li>
      </ul>

      <h2>Where it is stored</h2>
      <ul>
        <li>
          On servers in the United States. If you are in Europe, that means your data is transferred
          outside the EEA under the provider’s standard contractual clauses.
        </li>
        <li>Rounds you play without an account stay on your device only.</li>
      </ul>

      <h2>How long it is kept</h2>
      <p>
        For as long as your account exists. Delete the account and the data goes with it, as
        described below.
      </p>

      <h2>Deleting your data</h2>
      <ul>
        <li>
          <strong>In the app:</strong> Settings → Edit profile → Delete my account. This removes your
          account, your friends list, the leagues you own and the rounds you started.
        </li>
        <li>
          Rounds started by somebody else stay with them, since they contain other players’ scores,
          but your name is detached from them.
        </li>
        <li>
          You can also write to <a href={`mailto:${contact}`}>{contact}</a> and ask us to delete
          everything.
        </li>
      </ul>

      <h2>Your rights</h2>
      <ul>
        <li>
          Under the GDPR and the Swiss FADP you may ask for a copy of your data, ask for it to be
          corrected, or ask for it to be erased.
        </li>
        <li>
          Write to <a href={`mailto:${contact}`}>{contact}</a> and we will answer within 30 days.
        </li>
        <li>
          You also have the right to complain to a supervisory authority — in Switzerland the FDPIC,
          or the data protection authority in your own country.
        </li>
      </ul>

      <h2>Children</h2>
      <p>
        The app is not aimed at children under 13, and we do not knowingly collect their data.
      </p>

      <h2>Changes</h2>
      <p>
        If this policy changes in a way that matters, the date at the top changes and the app will
        say so.
      </p>

      <p>
        Questions: <a href={`mailto:${contact}`}>{contact}</a>
      </p>
    </LegalPage>
  )
}
