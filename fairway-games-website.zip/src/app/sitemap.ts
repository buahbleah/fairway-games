import type { MetadataRoute } from 'next'
import { siteConfig } from '@config'
import { games } from '@/content/games'

/**
 * Priorities reflect what the site is for: the download page and the game rules
 * pages are the two things that matter, so they sit above the marketing pages.
 */
export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date()

  const staticRoutes: { path: string; priority: number; freq: 'weekly' | 'monthly' | 'yearly' }[] = [
    { path: '/', priority: 1, freq: 'weekly' },
    { path: '/games', priority: 0.9, freq: 'monthly' },
    { path: '/download', priority: 0.9, freq: 'weekly' },
    { path: '/how-it-works', priority: 0.7, freq: 'monthly' },
    { path: '/features', priority: 0.7, freq: 'monthly' },
    { path: '/faq', priority: 0.7, freq: 'monthly' },
    { path: '/about', priority: 0.4, freq: 'yearly' },
    { path: '/privacy', priority: 0.2, freq: 'yearly' },
    { path: '/terms', priority: 0.2, freq: 'yearly' },
  ]

  return [
    ...staticRoutes.map((r) => ({
      url: `${siteConfig.url}${r.path === '/' ? '' : r.path}`,
      lastModified: now,
      changeFrequency: r.freq,
      priority: r.priority,
    })),
    ...games.map((g) => ({
      url: `${siteConfig.url}/games/${g.slug}`,
      lastModified: now,
      changeFrequency: 'monthly' as const,
      priority: 0.8,
    })),
  ]
}
