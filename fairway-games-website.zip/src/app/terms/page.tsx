import type { Metadata } from 'next'
import { siteConfig } from '@config'
import { pageMetadata } from '@/lib/seo'
import { LegalPage, Placeholder } from '@/components/LegalPage'

export const metadata: Metadata = pageMetadata({
  title: 'Terms of Use',
  description:
    'The terms for using Fairway Games and this website. Plain language, no real money, and what happens if something goes wrong.',
  path: '/terms',
})

/**
 * A working draft, not legal advice.
 *
 * Everything marked as a placeholder needs a real value, and a Swiss lawyer
 * should read the whole thing before launch. See README, "Legal placeholders".
 */
export default function TermsPage() {
  const contact = siteConfig.contact.email

  return (
    <LegalPage
      title="Terms of Use"
      updated="24 August 2026"
      intro="The rules for using the app and this website, written to be read rather than skipped."
      crumbLabel="Terms"
      path="/terms"
    >
      <div
        className="rounded-[var(--r-md)] border p-5 not-prose"
        style={{ background: 'var(--accent-soft)', borderColor: 'var(--sand-400)' }}
      >
        <p className="text-[0.9375rem] leading-[1.55] text-[var(--on-accent-soft)]">
          <strong>Draft.</strong> This document is a working draft with the company details still to
          be filled in, and it has not been reviewed by a lawyer. Everything highlighted in sand
          needs a real value before launch.
        </p>
      </div>

      <h2>Who you are agreeing with</h2>
      <p>
        These terms are between you and <Placeholder>{siteConfig.contact.company}</Placeholder>,{' '}
        <Placeholder>{siteConfig.contact.address}</Placeholder> (“we”, “us”), the operator of{' '}
        {siteConfig.name}. Using the app or this website means you accept them.
      </p>

      <h2>What the app is</h2>
      <p>
        {siteConfig.name} is a scorekeeper for golf side games. It records scores, applies the rules
        you choose and works out points and standings. It is a convenience, not an official
        scoring system, and it is not affiliated with any governing body, tour or handicap
        authority.
      </p>

      <h2>Points are not money</h2>
      <p>
        The app deals only in points. There is no real money in it: no payments, no wallet, no
        stake held anywhere, and no gambling functionality of any kind. The optional “point value”
        setting is a label you choose for your own reference and moves nothing.
      </p>
      <p>
        Whatever your group does after the round is entirely between you. We are not a party to it,
        we do not record it, and we take no responsibility for any arrangement between players.
        Betting on golf may be regulated where you live — that is your responsibility to know.
      </p>

      <h2>Your account</h2>
      <ul>
        <li>You can use the app without an account. An account only adds friends, leagues and shared live rounds.</li>
        <li>Keep your password to yourself. You are responsible for what happens under your account.</li>
        <li>Give a real email address, since it is how your friends find you and how you recover access.</li>
        <li>You must be at least 13 years old to create an account.</li>
        <li>You can delete your account at any time from inside the app.</li>
      </ul>

      <h2>Fair use</h2>
      <p>Do not use the app or the site to:</p>
      <ul>
        <li>Impersonate somebody else, or add people to rounds and leagues who have not agreed to it.</li>
        <li>Upload a photo you do not have the right to use, or anything offensive.</li>
        <li>Attempt to break, overload, scrape or reverse-engineer the service.</li>
        <li>Do anything unlawful, or anything that would put us in breach of the law.</li>
      </ul>
      <p>
        We can suspend or remove an account that does any of the above. Where it is reasonable to do
        so, we will say why.
      </p>

      <h2>Your content</h2>
      <p>
        Scores, player names, league names and photos you add stay yours. You give us only the
        permission we need to store them and show them to the people you play with. Content in a
        round that other people also played in may remain visible to them after you leave, since it
        contains their scores as well as yours.
      </p>

      <h2>Our content</h2>
      <p>
        The app, this website, the design, the wordmark, the crest and the icon set are ours.
        Golf-game names — Wolf, Skins, Nassau, Vegas — are common terms and nobody owns them,
        including us.
      </p>

      <h2>Availability</h2>
      <p>
        We try to keep the service running and the maths correct, but we offer it “as is”. There is
        no guarantee that it will be available at all times, that every calculation will match your
        group’s interpretation of a rule, or that a shared round will always sync instantly.
      </p>
      <p>
        The app is designed to keep working offline precisely because networks fail, and a round
        played without an account never depends on us at all.
      </p>

      <h2>Liability</h2>
      <p>
        To the extent the law allows, we are not liable for indirect or consequential loss arising
        from your use of the app — including any dispute between players about a score, a rule or
        a settlement. Nothing here limits liability that cannot be limited by law, including for
        death, personal injury or intentional wrongdoing.
      </p>

      <h2>Changes</h2>
      <p>
        These terms can change. If a change matters, the date at the top changes and, where the
        change is significant, we will tell you in the app. Continuing to use the service after a
        change means you accept the new version.
      </p>

      <h2>Governing law</h2>
      <p>
        These terms are governed by <Placeholder>Swiss law</Placeholder>, with the courts of{' '}
        <Placeholder>[place of jurisdiction]</Placeholder> having jurisdiction, unless mandatory
        consumer protection law in your country of residence says otherwise.
      </p>

      <h2>Contact</h2>
      <p>
        <a href={`mailto:${contact}`}>{contact}</a>
      </p>
    </LegalPage>
  )
}
