import Script from 'next/script'
import { siteConfig } from '@config'

/**
 * ANALYTICS — off by default, and cookieless when on.
 *
 * The site ships with no analytics at all, which is why there is no cookie
 * banner: there is nothing to consent to. Setting `analytics.enabled` and a
 * provider in site.config.ts loads a single script from a provider that does
 * not set cookies or track people across sites (Plausible or Umami), which
 * under GDPR and the Swiss DSG does not require consent.
 *
 * If a provider that DOES require consent is ever added — Google Analytics,
 * Meta Pixel, anything with cross-site identifiers — a consent gate has to be
 * built first. See README, "Analytics and consent".
 *
 * Conceptual events are already marked up across the site with data-event
 * attributes, so no component needs changing when analytics is switched on:
 *   download-cta-header · download-cta-menu · download-cta-sticky
 *   download-cta-hero   · download-cta-final · store-click-android
 *   store-click-ios     · qr-shown           · faq-expand
 *   game-card-click
 */
export function Analytics() {
  const { analytics } = siteConfig

  if (!analytics.enabled || !analytics.provider) return null

  if (analytics.provider === 'plausible' && analytics.domain) {
    return (
      <Script
        defer
        data-domain={analytics.domain}
        src={analytics.scriptUrl ?? 'https://plausible.io/js/script.tagged-events.js'}
        strategy="afterInteractive"
      />
    )
  }

  if (analytics.provider === 'umami' && analytics.scriptUrl && analytics.domain) {
    return (
      <Script
        defer
        data-website-id={analytics.domain}
        src={analytics.scriptUrl}
        strategy="afterInteractive"
      />
    )
  }

  return null
}
