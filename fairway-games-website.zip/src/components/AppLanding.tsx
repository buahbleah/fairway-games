import Image from 'next/image'
import type { ReactNode } from 'react'
import { siteConfig, anyStoreLive } from '@config'
import { DownloadButtons, launchListHref } from './DownloadButtons'
import { PhoneMockup } from './PhoneMockup'
import { QRCode } from './QRCode'
import { CTAButton } from './CTAButton'
import { ContourBackdrop, HeroFairway } from './Art'
import { Money, Offline, Players } from './Icons'

/**
 * THE APP LANDING BLOCK
 *
 * The app-store furniture — icon, category line, store buttons, availability,
 * the trust line and a QR code — in one place, used by both the homepage and
 * /download.
 *
 * It is shared rather than duplicated because these two blocks must never
 * disagree about what you can install today. Everything they say comes from
 * site.config.ts, so changing a store status updates both at once.
 */

interface Props {
  /** The page's h1. Given as a node so each page can colour its own line break. */
  headline: ReactNode
  lede: string
  /** Screenshot for the device. */
  phoneSrc: string
  phoneAlt: string
  /** Rendered above the h1 on /download; the homepage has its own. */
  breadcrumbs?: ReactNode
  /** Extra buttons under the store badges — the homepage's secondary actions. */
  secondary?: ReactNode
  /** What the desktop QR code should open. Defaults to the site root. */
  qrTarget?: string
  /** The homepage wants the full course backdrop; /download the quieter one. */
  backdrop?: 'fairway' | 'contour'
}

export function AppLanding({
  headline,
  lede,
  phoneSrc,
  phoneAlt,
  breadcrumbs,
  secondary,
  qrTarget,
  backdrop = 'contour',
}: Props) {
  const live = anyStoreLive()
  const qrUrl = qrTarget ?? siteConfig.url

  return (
    <section className="relative overflow-hidden">
      {backdrop === 'fairway' ? (
        <>
          <div
            aria-hidden
            className="pointer-events-none absolute right-[-28%] top-[-14%] h-[132%] w-[112%] opacity-[0.55] sm:right-[-10%] sm:w-[78%] lg:right-[-4%] lg:w-[62%]"
            style={{
              maskImage: 'linear-gradient(to right, transparent 0%, #000 26%)',
              WebkitMaskImage: 'linear-gradient(to right, transparent 0%, #000 26%)',
            }}
          >
            <HeroFairway className="h-full w-full" />
          </div>
          <ContourBackdrop
            opacity={0.09}
            className="pointer-events-none absolute inset-x-0 bottom-0 h-[52%] w-full text-[var(--brand)]"
          />
        </>
      ) : (
        <ContourBackdrop
          opacity={0.08}
          className="pointer-events-none absolute inset-0 h-full w-full text-[var(--brand)]"
        />
      )}

      <div className="rail relative grid items-center gap-12 py-12 sm:py-16 lg:grid-cols-[minmax(0,1fr)_360px] lg:gap-14">
        <div className="anim-rise">
          {breadcrumbs}

          {/* App-store identity row: icon, name, what kind of thing this is. */}
          <div className="mb-7 flex items-center gap-4">
            <Image
              src="/brand/app-icon-512.webp"
              alt=""
              width={76}
              height={76}
              priority
              className="rounded-[17px] shadow-[var(--shadow-2)]"
            />
            <div>
              <p className="font-display text-[1.375rem] font-bold uppercase tracking-[0.08em]">
                {siteConfig.name}
              </p>
              <p className="text-[0.9375rem] text-[var(--text-muted)]">
                Sports · Free · Android &amp; iPhone
              </p>
            </div>
          </div>

          <h1 className="display-1">{headline}</h1>
          <p className="lede mt-5">{lede}</p>

          <DownloadButtons className="mt-8" />

          {live ? (
            <div
              className="mt-6 rounded-[var(--r-lg)] border border-[var(--line-strong)] p-6"
              style={{ background: 'var(--accent-soft)' }}
            >
              <p className="eyebrow mb-2" style={{ color: 'var(--on-accent-soft)' }}>
                Where it stands today
              </p>
              <ul className="space-y-2 text-[0.9375rem] leading-[1.55] text-[var(--on-accent-soft)]">
                <li>
                  <strong>Android:</strong> live on Google Play&rsquo;s internal test track. The
                  link works once your Google account has been added as a tester.
                </li>
                <li>
                  <strong>iPhone:</strong> no store build yet — but the whole app runs in Safari,
                  and Add to Home Screen gives you the icon, full screen and offline play.
                </li>
              </ul>
            </div>
          ) : (
            <div
              className="mt-6 rounded-[var(--r-lg)] border border-[var(--line-strong)] p-6"
              style={{ background: 'var(--accent-soft)' }}
            >
              <p className="eyebrow mb-2" style={{ color: 'var(--on-accent-soft)' }}>
                Not on the stores yet
              </p>
              <p className="text-[0.9375rem] leading-[1.55] text-[var(--on-accent-soft)]">
                The app is built and playing rounds — the store listings are in progress. Leave your
                email and you will get one message when it goes live, and nothing else.
              </p>
              <CTAButton
                href={launchListHref()}
                variant="primary"
                size="md"
                className="mt-5"
                event="launch-list-click"
                external={Boolean(siteConfig.launchListUrl)}
              >
                Join the Launch List
              </CTAButton>
            </div>
          )}

          {secondary}

          <ul className="mt-8 space-y-3">
            {[
              { icon: Money, t: 'No adverts, no tracking, no analytics inside the app.' },
              { icon: Offline, t: 'Works with no signal. A solo round needs no account at all.' },
              { icon: Players, t: 'Points are points — there is no real money anywhere in it.' },
            ].map(({ icon: Icon, t }) => (
              <li key={t} className="flex items-center gap-3">
                <Icon size={19} className="shrink-0 text-[var(--brand)]" />
                <span className="text-[0.9375rem] text-[var(--text-muted)]">{t}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="flex flex-col items-center gap-8">
          <PhoneMockup
            src={phoneSrc}
            alt={phoneAlt}
            width={310}
            priority
            glow
            sizes="(max-width: 640px) 90vw, 310px"
          />

          {/* Desktop gets a QR code; phones already have the store buttons. */}
          <div className="card hidden items-center gap-5 p-5 lg:flex" data-event="qr-shown">
            <QRCode
              value={qrUrl}
              size={126}
              title={`QR code linking to ${qrUrl}`}
              className="rounded-[var(--r-sm)]"
            />
            <div className="max-w-[19ch]">
              <p className="eyebrow mb-1.5">On a laptop?</p>
              <p className="text-[0.9375rem] leading-[1.45] text-[var(--text-muted)]">
                Point your phone camera here to open this page on the device you actually play with.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
