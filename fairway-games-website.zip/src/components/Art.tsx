/**
 * COURSE GEOMETRY
 *
 * Abstract fairway shapes, carried over from the app's src/ui/art.tsx and
 * extended for the wider canvases a website has. Everything is token-driven so
 * it works in both themes, and every piece is decorative — never the only
 * carrier of meaning.
 *
 * The rule from the app's design system holds here: the golf reference comes
 * from geometry and palette, not from photographs or scattered golf balls.
 */

/** The crest from the app icon, without the wordmark. Used as the site mark. */
export function BrandCrest({ size = 36, className }: { size?: number; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="122 56 268 268"
      className={className}
      aria-hidden
      focusable="false"
    >
      <defs>
        <linearGradient id="fw-gold" x1=".15" y1="0" x2=".85" y2="1">
          <stop offset="0%" stopColor="#f6e2a4" />
          <stop offset="35%" stopColor="#d9b45f" />
          <stop offset="70%" stopColor="#b98d3c" />
          <stop offset="100%" stopColor="#f0d68f" />
        </linearGradient>
        <linearGradient id="fw-sky" x1=".5" y1="0" x2=".5" y2="1">
          <stop offset="0%" stopColor="#bfe3ea" />
          <stop offset="55%" stopColor="#e4f2e2" />
          <stop offset="100%" stopColor="#f6f6e6" />
        </linearGradient>
        <linearGradient id="fw-turf" x1=".5" y1="0" x2=".5" y2="1">
          <stop offset="0%" stopColor="#3f9a55" />
          <stop offset="100%" stopColor="#186434" />
        </linearGradient>
        <linearGradient id="fw-fairway" x1=".5" y1="0" x2=".5" y2="1">
          <stop offset="0%" stopColor="#8ed36f" />
          <stop offset="100%" stopColor="#5cb65c" />
        </linearGradient>
        <linearGradient id="fw-star" x1=".3" y1="0" x2=".7" y2="1">
          <stop offset="0%" stopColor="#ffffff" />
          <stop offset="100%" stopColor="#9dc9e0" />
        </linearGradient>
        <clipPath id="fw-crest-clip">
          <circle cx="256" cy="190" r="116" />
        </clipPath>
      </defs>

      <circle cx="256" cy="190" r="130" fill="url(#fw-gold)" />
      <circle cx="256" cy="190" r="119" fill="#0a3320" />

      <g clipPath="url(#fw-crest-clip)">
        <rect x="140" y="74" width="232" height="232" fill="url(#fw-sky)" />
        <g stroke="#ffffff" strokeOpacity=".55" strokeWidth="3" strokeLinecap="round">
          <path d="M256 126 214 96M256 126 298 96M256 126 190 132M256 126 322 132" />
        </g>
        <path d="M256 84 268 122 306 134 268 146 256 184 244 146 206 134 244 122Z" fill="#2a6f8e" />
        <path
          d="M256 96 265 126 295 134 265 142 256 172 247 142 217 134 247 126Z"
          fill="url(#fw-star)"
        />
        <path d="M256 108 261 129 282 134 261 139 256 160 251 139 230 134 251 129Z" fill="#ffffff" />
        <path
          d="M140 214c26-6 44-22 62-22s30 14 54 12 40-18 62-16 34 18 54 18v24H140Z"
          fill="#2c7a49"
          fillOpacity=".55"
        />
        <path d="M140 206h232v100H140Z" fill="url(#fw-turf)" />
        <path
          d="M140 306C146 272 186 250 236 240C272 233 292 224 300 208L324 214C316 244 288 258 248 268C214 276 200 290 198 306Z"
          fill="url(#fw-fairway)"
        />
        <path
          d="M300 250c18-6 34-2 40 8s-4 22-22 24-32-4-34-14 2-14 16-18Z"
          fill="#f0dcae"
          stroke="#c9ad78"
          strokeWidth="2"
        />
        <ellipse cx="238" cy="222" rx="34" ry="14" fill="#7ecb6a" />
        <path d="M244 222v-44" stroke="#f7f5ec" strokeWidth="4" strokeLinecap="round" />
        <path d="M244 180 274 189 244 199Z" fill="#d94f3d" />
        <circle cx="226" cy="224" r="4" fill="#ffffff" />
        <g fill="#14522e">
          <path d="M330 210 314 210 330 178 346 210Z" />
          <path d="M330 190 318 190 330 164 342 190Z" />
          <path d="M330 174 320 174 330 152 340 174Z" />
          <rect x="327" y="206" width="6" height="10" />
          <path d="M356 212 342 212 356 184 370 212Z" />
          <path d="M356 194 346 194 356 170 366 194Z" />
          <rect x="353" y="208" width="6" height="10" />
          <path d="M170 214 156 214 170 186 184 214Z" />
          <path d="M170 196 160 196 170 172 180 196Z" />
          <rect x="167" y="210" width="6" height="10" />
          <path d="M194 216 183 216 194 194 205 216Z" />
          <rect x="191" y="212" width="6" height="9" />
        </g>
      </g>

      <circle
        cx="256"
        cy="190"
        r="114"
        fill="none"
        stroke="#f6e2a4"
        strokeOpacity=".45"
        strokeWidth="2"
      />
    </svg>
  )
}

/** Soft contour lines — a green read from above. Sits behind hero areas. */
export function ContourBackdrop({
  opacity = 0.14,
  className,
}: {
  opacity?: number
  className?: string
}) {
  return (
    <svg
      className={className}
      viewBox="0 0 400 220"
      preserveAspectRatio="xMidYMid slice"
      aria-hidden
      focusable="false"
      style={{ opacity }}
    >
      <g fill="none" stroke="currentColor" strokeWidth="1.2">
        <path d="M-20 168c60-46 118-52 176-24s112 16 168-30" />
        <path d="M-20 190c62-50 124-58 186-28s118 14 174-36" />
        <path d="M-20 146c56-42 108-46 160-22s106 12 160-28" />
        <path d="M-20 124c50-36 96-40 142-18s96 8 148-24" />
        <path d="M-20 104c44-30 84-34 124-14s86 4 134-20" />
        <path d="M-20 84c40-26 76-30 112-12s78 2 122-18" />
      </g>
    </svg>
  )
}

/**
 * The hero backdrop: a fairway curving away from the tee, a bunker, the green
 * and a flag — all abstract, all behind the phone. Deliberately not a photo:
 * the app UI is the hero and a busy photograph would compete with it.
 */
export function HeroFairway({ className }: { className?: string }) {
  return (
    <svg
      className={className}
      viewBox="0 0 600 600"
      preserveAspectRatio="xMidYMid slice"
      aria-hidden
      focusable="false"
    >
      <defs>
        <radialGradient id="fw-dawn" cx=".62" cy=".26" r=".62">
          <stop offset="0%" stopColor="var(--sand-400)" stopOpacity=".38" />
          <stop offset="100%" stopColor="var(--sand-400)" stopOpacity="0" />
        </radialGradient>
      </defs>

      <circle cx="372" cy="156" r="300" fill="url(#fw-dawn)" />

      {/* the fairway, drawn as one thick stroke with a lighter core */}
      <path
        d="M188 640c-24-150 6-262 96-330 66-50 132-72 168-140"
        fill="none"
        stroke="var(--brand-soft)"
        strokeWidth="150"
        strokeLinecap="round"
        opacity=".9"
      />
      <path
        d="M188 640c-24-150 6-262 96-330 66-50 132-72 168-140"
        fill="none"
        stroke="var(--surface)"
        strokeWidth="96"
        strokeLinecap="round"
        opacity=".5"
      />

      {/* green and bunkers */}
      <ellipse cx="466" cy="140" rx="98" ry="52" fill="var(--brand-soft)" />
      <ellipse cx="466" cy="140" rx="62" ry="32" fill="none" stroke="var(--brand)" strokeWidth="1.5" opacity=".28" />
      <ellipse cx="330" cy="268" rx="46" ry="22" fill="var(--accent-soft)" />
      <ellipse cx="556" cy="222" rx="34" ry="18" fill="var(--accent-soft)" />

      {/* flagstick */}
      <path d="M470 140V54" stroke="var(--text-muted)" strokeWidth="4" strokeLinecap="round" opacity=".55" />
      <path d="M470 58l44 14-44 15z" fill="var(--accent)" opacity=".75" />
      <circle cx="444" cy="142" r="7" fill="var(--surface)" stroke="var(--line-strong)" strokeWidth="1.5" />
    </svg>
  )
}

/** A fairway seen from the tee: dogleg, bunkers, green with flag. */
export function FairwayScene({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 300 200" aria-hidden focusable="false">
      <path
        d="M96 200c-6-52 4-88 30-108s58-26 74-48"
        fill="none"
        stroke="var(--green-200)"
        strokeWidth="54"
        strokeLinecap="round"
      />
      <path
        d="M96 200c-6-52 4-88 30-108s58-26 74-48"
        fill="none"
        stroke="var(--green-100)"
        strokeWidth="38"
        strokeLinecap="round"
      />
      <ellipse cx="204" cy="40" rx="34" ry="18" fill="var(--green-300)" />
      <ellipse cx="160" cy="86" rx="16" ry="8" fill="var(--sand-300)" />
      <ellipse cx="232" cy="66" rx="13" ry="7" fill="var(--sand-300)" />
      <path d="M206 40V14" stroke="var(--ink-700)" strokeWidth="2" strokeLinecap="round" />
      <path d="M206 15l13 4.4-13 4.6z" fill="var(--clay-500)" />
      <circle cx="196" cy="41" r="3" fill="var(--cream-100)" stroke="var(--ink-300)" strokeWidth=".8" />
    </svg>
  )
}

/** Empty state: a ball resting by the cup on an otherwise empty green. */
export function EmptyGreen({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 200 140" aria-hidden focusable="false">
      <ellipse cx="100" cy="104" rx="82" ry="30" fill="var(--brand-soft)" />
      <ellipse cx="100" cy="104" rx="54" ry="19" fill="none" stroke="var(--brand)" strokeWidth="1" opacity=".35" />
      <ellipse cx="112" cy="100" rx="9" ry="3.6" fill="var(--green-700)" opacity=".8" />
      <path d="M112 100V26" stroke="var(--text-muted)" strokeWidth="2.4" strokeLinecap="round" />
      <path d="M112 28l20 6.6-20 7z" fill="var(--accent)" />
      <circle cx="86" cy="103" r="6" fill="var(--surface)" stroke="var(--line-strong)" strokeWidth="1.2" />
      <circle cx="84" cy="101" r="1" fill="var(--text-faint)" />
      <circle cx="88" cy="104" r="1" fill="var(--text-faint)" />
    </svg>
  )
}

/** A ridge of fairway used to close dark sections without a hard edge. */
export function RidgeDivider({ className, flip = false }: { className?: string; flip?: boolean }) {
  return (
    <svg
      className={className}
      viewBox="0 0 1440 90"
      preserveAspectRatio="none"
      aria-hidden
      focusable="false"
      style={flip ? { transform: 'scaleY(-1)' } : undefined}
    >
      <path d="M0 62c220-42 420-42 720 0s500 42 720 0v28H0z" fill="currentColor" opacity=".45" />
      <path d="M0 74c240-32 440-32 720 0s480 32 720 0v16H0z" fill="currentColor" />
    </svg>
  )
}
