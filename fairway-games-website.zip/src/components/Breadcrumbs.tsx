import Link from 'next/link'
import { ChevronRight } from './Icons'

export interface Crumb {
  name: string
  path: string
}

export function Breadcrumbs({ crumbs }: { crumbs: Crumb[] }) {
  return (
    <nav aria-label="Breadcrumb" className="mb-6">
      <ol className="flex flex-wrap items-center gap-1.5 text-[0.8125rem] text-[var(--text-muted)]">
        {crumbs.map((c, i) => {
          const last = i === crumbs.length - 1
          return (
            <li key={c.path} className="flex items-center gap-1.5">
              {last ? (
                <span aria-current="page" className="inline-flex min-h-[32px] items-center text-[var(--text)]">
                  {c.name}
                </span>
              ) : (
                <>
                  <Link href={c.path} className="inline-flex min-h-[32px] items-center transition-colors hover:text-[var(--brand)]">
                    {c.name}
                  </Link>
                  <ChevronRight size={13} className="text-[var(--text-faint)]" />
                </>
              )}
            </li>
          )
        })}
      </ol>
    </nav>
  )
}
