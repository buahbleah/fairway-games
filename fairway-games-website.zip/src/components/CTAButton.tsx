import Link from 'next/link'
import type { ReactNode } from 'react'

type Variant = 'primary' | 'secondary' | 'ghost' | 'accent'
type Size = 'md' | 'lg'

interface Props {
  href: string
  children: ReactNode
  variant?: Variant
  size?: Size
  className?: string
  /** Analytics hook — read by the (disabled by default) analytics module. */
  event?: string
  external?: boolean
  ariaLabel?: string
}

/**
 * The one button on the site.
 *
 * Sizes match the app's touch targets: 48px minimum, 56px comfortable. Nothing
 * here is smaller than a thumb, on any breakpoint.
 */
const variants: Record<Variant, string> = {
  primary:
    'bg-[var(--brand)] text-[var(--text-on-brand)] border border-transparent shadow-[var(--shadow-2)] hover:brightness-110 active:brightness-95',
  accent:
    'bg-[var(--accent)] text-[var(--ink-900)] border border-transparent shadow-[var(--shadow-2)] hover:brightness-105 active:brightness-95',
  secondary:
    'bg-[var(--surface)] text-[var(--text)] border border-[var(--line-strong)] hover:border-[var(--brand)] hover:text-[var(--brand)]',
  ghost:
    'bg-transparent text-[var(--text)] border border-[var(--line-strong)] hover:border-[var(--brand)] hover:text-[var(--brand)]',
}

const sizes: Record<Size, string> = {
  md: 'min-h-[48px] px-5 text-[0.9375rem]',
  lg: 'min-h-[56px] px-7 text-base sm:text-[1.0625rem]',
}

export function CTAButton({
  href,
  children,
  variant = 'primary',
  size = 'lg',
  className = '',
  event,
  external = false,
  ariaLabel,
}: Props) {
  const cls = [
    'inline-flex items-center justify-center gap-2 rounded-[var(--r-md)] font-display font-bold',
    'tracking-[0.04em] uppercase whitespace-nowrap',
    'transition-[filter,border-color,color,transform] duration-[var(--dur-quick)] ease-[var(--ease-out)]',
    'active:scale-[0.985]',
    variants[variant],
    sizes[size],
    className,
  ].join(' ')

  if (external) {
    return (
      <a
        href={href}
        className={cls}
        data-event={event}
        aria-label={ariaLabel}
        rel="noopener noreferrer"
        target="_blank"
      >
        {children}
      </a>
    )
  }

  return (
    <Link href={href} className={cls} data-event={event} aria-label={ariaLabel}>
      {children}
    </Link>
  )
}
