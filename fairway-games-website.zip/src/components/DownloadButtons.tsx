import { siteConfig, isStoreLinked, type StoreConfig } from '@config'

/**
 * Store buttons.
 *
 * A button only becomes a link when site.config.ts gives that platform a URL.
 * There are no invented store links anywhere in this repository — a dead store
 * link is worse than an honest "not yet".
 *
 * Four states, one per StoreStatus:
 *   live         → a normal store badge
 *   testing      → the same badge, labelled as a test track, with the caveat
 *                  shown underneath so nobody clicks through and gets rejected
 *   web          → opens the web app instead of a store
 *   coming-soon  → a dashed, non-interactive placeholder
 */

function GooglePlayGlyph({ size = 22 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={(size * 26) / 24}
      viewBox="0 0 24 26"
      aria-hidden
      focusable="false"
      className="shrink-0"
    >
      {/* The Play triangle, in Google's four colours. Recognisable at a glance,
          which is the entire job of a store badge. */}
      <path d="M2.6 1.3a1.7 1.7 0 0 0-.5 1.2v21a1.7 1.7 0 0 0 .5 1.2L14 13.5v-.2z" fill="#00D3FF" />
      <path d="M17.8 17.3 14 13.5v-.2l3.8-3.8.1.1 4.5 2.6c1.3.7 1.3 1.9 0 2.6z" fill="#FFCE00" />
      <path d="m17.9 17.4-3.9-3.9-11.4 11.4a1.4 1.4 0 0 0 1.7.1z" fill="#FF3A44" />
      <path d="M17.9 8.6 4.3 1a1.4 1.4 0 0 0-1.7.1l11.4 11.4z" fill="#00E676" />
    </svg>
  )
}

function AppleGlyph({ size = 22 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={(size * 26) / 22}
      viewBox="0 0 22 26"
      aria-hidden
      focusable="false"
      className="shrink-0"
    >
      <path
        d="M17.9 13.7c0-3 2.4-4.4 2.5-4.5-1.4-2-3.5-2.3-4.2-2.3-1.8-.2-3.5 1-4.4 1-.9 0-2.3-1-3.8-1-2 0-3.8 1.1-4.8 2.9-2 3.5-.5 8.8 1.5 11.6 1 1.4 2.1 3 3.6 2.9 1.5-.1 2-.9 3.8-.9s2.3.9 3.8.9 2.6-1.4 3.5-2.8c1.1-1.6 1.6-3.2 1.6-3.3-.1 0-3.1-1.2-3.1-4.5zM15 4.9c.8-1 1.3-2.3 1.2-3.7-1.2 0-2.6.8-3.4 1.8-.7.9-1.4 2.2-1.2 3.5 1.3.1 2.6-.7 3.4-1.6z"
        fill="currentColor"
      />
    </svg>
  )
}

interface Labels {
  line1: string
  line2: string
}

function labelsFor(platform: 'android' | 'ios', store: StoreConfig): Labels {
  if (platform === 'android') {
    switch (store.status) {
      case 'live':
        return { line1: 'Get it on', line2: 'Google Play' }
      case 'testing':
        return { line1: 'Join the test on', line2: 'Google Play' }
      case 'web':
        return { line1: 'Open the', line2: 'Web App' }
      default:
        return { line1: 'Coming soon to', line2: 'Google Play' }
    }
  }
  switch (store.status) {
    case 'live':
      return { line1: 'Download on the', line2: 'App Store' }
    case 'testing':
      return { line1: 'Join the beta on', line2: 'TestFlight' }
    case 'web':
      return { line1: 'On iPhone — open the', line2: 'Web App' }
    default:
      return { line1: 'Coming soon to', line2: 'App Store' }
  }
}

function StoreButton({
  platform,
  onDark = false,
}: {
  platform: 'android' | 'ios'
  onDark?: boolean
}) {
  const store = siteConfig.stores[platform]
  const linked = isStoreLinked(store)
  const Glyph = platform === 'android' ? GooglePlayGlyph : AppleGlyph
  const { line1, line2 } = labelsFor(platform, store)

  const shell = [
    'inline-flex min-h-[62px] w-full items-center gap-3.5 rounded-[var(--r-md)] px-5 py-3 text-left sm:w-auto',
    'transition-[filter,border-color,transform] duration-[var(--dur-quick)] ease-[var(--ease-out)]',
    linked
      ? // Inside a dark band the badge is always cream; on the page it follows
        // the theme, so it never ends up dark-on-dark or light-on-light.
        onDark
        ? 'bg-[var(--cream-100)] text-[var(--ink-900)] shadow-[var(--shadow-2)] hover:brightness-95 active:scale-[0.985]'
        : 'bg-[var(--store-bg)] text-[var(--store-text)] shadow-[var(--shadow-2)] hover:brightness-110 active:scale-[0.985]'
      : 'cursor-default border border-dashed border-[var(--line-strong)] bg-transparent text-[var(--text-muted)]',
  ].join(' ')

  const inner = (
    <>
      {/* The Apple mark inherits the button's text colour; the Play mark keeps
          Google's own colours, which is how the badge is recognised. */}
      <Glyph />
      <span className="leading-tight">
        <span className="block text-[0.6875rem] uppercase tracking-[0.12em] opacity-80">
          {line1}
        </span>
        <span className="block font-display text-[1.0625rem] font-bold">{line2}</span>
      </span>
    </>
  )

  // A store link leaves the site, so it opens in a new tab. The web app is the
  // same product on the same origin — that one opens in place.
  const external = store.status === 'live' || store.status === 'testing'

  const button = linked ? (
    <a
      href={store.url}
      className={shell}
      data-event={`store-click-${platform}`}
      {...(external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
    >
      {inner}
    </a>
  ) : (
    <span className={shell} aria-label={`${line2}: coming soon`}>
      {inner}
    </span>
  )

  if (!store.note) return button

  return (
    <span className="flex w-full flex-col gap-1.5 sm:w-auto">
      {button}
      <span
        className={`max-w-[30ch] text-[0.75rem] leading-[1.4] ${
          onDark ? 'text-[var(--on-dark-muted)]' : 'text-[var(--text-muted)]'
        }`}
      >
        {store.note}
      </span>
    </span>
  )
}

export function DownloadButtons({
  className = '',
  align = 'start',
  onDark = false,
}: {
  className?: string
  align?: 'start' | 'center'
  onDark?: boolean
}) {
  return (
    <div
      className={`flex flex-col flex-wrap gap-4 sm:flex-row sm:items-start ${
        align === 'center' ? 'sm:justify-center' : ''
      } ${className}`}
    >
      <StoreButton platform="android" onDark={onDark} />
      <StoreButton platform="ios" onDark={onDark} />
    </div>
  )
}

/** Launch-list destination: a real form if configured, otherwise email. */
export function launchListHref() {
  return (
    siteConfig.launchListUrl ??
    `mailto:${siteConfig.contact.email}?subject=Fairway%20Games%20launch%20list`
  )
}
