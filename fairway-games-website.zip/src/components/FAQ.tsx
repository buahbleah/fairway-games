import { ChevronDown } from './Icons'

export interface FaqShape {
  q: string
  a: string
}

/**
 * Native <details>/<summary>.
 *
 * Chosen over a JavaScript accordion on purpose: it is keyboard accessible and
 * screen-reader correct without a line of script, the answers are in the DOM so
 * search engines index them, and Ctrl+F finds text inside a closed item in
 * modern browsers. The whole component ships zero client JavaScript.
 */
export function FAQ({ items, className = '' }: { items: readonly FaqShape[]; className?: string }) {
  return (
    <div className={`divide-y divide-[var(--line)] border-y border-[var(--line)] ${className}`}>
      {items.map((item) => (
        <details key={item.q} className="group" data-event="faq-expand">
          <summary
            className="flex min-h-[64px] cursor-pointer list-none items-center justify-between gap-5 py-5 font-display text-[1.0625rem] font-bold leading-snug transition-colors hover:text-[var(--brand)] sm:text-[1.1875rem] [&::-webkit-details-marker]:hidden"
          >
            {item.q}
            <ChevronDown
              size={22}
              className="shrink-0 text-[var(--text-muted)] transition-transform duration-[var(--dur-quick)] ease-[var(--ease-out)] group-open:rotate-180"
            />
          </summary>
          <p className="max-w-[68ch] pb-6 pr-8 text-[0.9375rem] leading-[1.6] text-[var(--text-muted)] sm:text-base">
            {item.a}
          </p>
        </details>
      ))}
    </div>
  )
}
