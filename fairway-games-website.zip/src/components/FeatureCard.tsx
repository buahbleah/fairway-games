import type { Feature } from '@/content/site'
import {
  Settings,
  Leaderboard,
  Offline,
  Players,
  Bookmark,
  History,
  Undo,
  Handicap,
  Info,
  Trophy,
  Moon,
  Money,
  type IconProps,
} from './Icons'

const ICONS: Record<Feature['icon'], (p: IconProps) => React.ReactElement> = {
  settings: Settings,
  leaderboard: Leaderboard,
  offline: Offline,
  players: Players,
  bookmark: Bookmark,
  history: History,
  undo: Undo,
  handicap: Handicap,
  info: Info,
  trophy: Trophy,
  moon: Moon,
  money: Money,
}

export function FeatureCard({ feature }: { feature: Feature }) {
  const Icon = ICONS[feature.icon]

  return (
    <article className="card flex h-full flex-col p-6 transition-[transform,box-shadow] duration-[var(--dur-card)] ease-[var(--ease-out)] hover:-translate-y-1 hover:shadow-[var(--shadow-2)]">
      <span
        className="inline-flex h-12 w-12 items-center justify-center rounded-[var(--r-md)] text-[var(--brand)]"
        style={{ background: 'var(--brand-soft)' }}
      >
        <Icon size={24} />
      </span>
      <h3 className="mt-4 text-[1.1875rem]">{feature.title}</h3>
      <p className="mt-2 text-[0.9375rem] leading-[1.55] text-[var(--text-muted)]">
        {feature.body}
      </p>
    </article>
  )
}
