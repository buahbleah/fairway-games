import Link from 'next/link'
import { siteConfig } from '@config'
import { footerNav } from '@/content/site'
import { BrandCrest } from './Art'

function Column({ title, links }: { title: string; links: { href: string; label: string }[] }) {
  return (
    <div>
      <h2 className="eyebrow mb-4">{title}</h2>
      <ul className="space-y-1">
        {links.map((l) => {
          // The web app is a separate deployment behind a rewrite, so it is a
          // plain anchor — Next must not try to client-navigate to it.
          const isAbsolute = l.href.startsWith('http')
          const cls =
            'inline-flex min-h-[44px] items-center text-[0.9375rem] text-[var(--text-muted)] transition-colors hover:text-[var(--brand)]'
          return (
            <li key={l.href}>
              {isAbsolute ? (
                <a href={l.href} className={cls}>
                  {l.label}
                </a>
              ) : (
                <Link href={l.href} className={cls}>
                  {l.label}
                </Link>
              )}
            </li>
          )
        })}
      </ul>
    </div>
  )
}

export function Footer() {
  const year = new Date().getFullYear()
  const socials = [
    siteConfig.social.instagram && { href: siteConfig.social.instagram, label: 'Instagram' },
    siteConfig.social.x && { href: siteConfig.social.x, label: 'X' },
  ].filter(Boolean) as { href: string; label: string }[]

  return (
    <footer className="on-dark mt-auto border-t border-[var(--on-dark-line)]">
      <div className="rail py-14">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1fr]">
          <div>
            <Link href="/" className="inline-flex min-h-[44px] items-center gap-2.5">
              <BrandCrest size={38} />
              <span className="font-display text-[1.125rem] font-bold uppercase tracking-[0.13em]">
                {siteConfig.name}
              </span>
            </Link>
            <p className="mt-4 max-w-[34ch] text-[0.9375rem] leading-[1.55] text-[var(--on-dark-muted)]">
              Six golf side games, scored in seconds between two shots. {siteConfig.tagline}
            </p>
            {socials.length > 0 && (
              <ul className="mt-5 flex gap-4">
                {socials.map((s) => (
                  <li key={s.label}>
                    <a
                      href={s.href}
                      rel="noopener noreferrer"
                      target="_blank"
                      className="inline-flex min-h-[44px] items-center text-[0.9375rem] underline underline-offset-4 hover:text-[var(--accent)]"
                    >
                      {s.label}
                    </a>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <Column title="Play" links={footerNav.play} />
          <Column title="Product" links={footerNav.product} />
          <Column title="Legal" links={footerNav.legal} />
        </div>

        <div className="mt-12 flex flex-col gap-3 border-t border-[var(--on-dark-line)] pt-7 text-[0.8125rem] text-[var(--on-dark-muted)] sm:flex-row sm:items-center sm:justify-between">
          <p>
            © {year} {siteConfig.name}. Points, not money — there is no gambling in the app.
          </p>
          <p>
            <a
              href={`mailto:${siteConfig.contact.email}`}
              className="underline underline-offset-4 hover:text-[var(--accent)]"
            >
              {siteConfig.contact.email}
            </a>
          </p>
        </div>
      </div>
    </footer>
  )
}
