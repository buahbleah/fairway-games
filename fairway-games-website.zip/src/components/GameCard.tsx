import Link from 'next/link'
import type { Game } from '@/content/types'
import { GAME_MARKS, ChevronRight, Players } from './Icons'

/** Three pips, filled to the game's complexity. Not colour alone — the label
 *  is always written out next to it. */
function ComplexityMeter({ level, label }: { level: 1 | 2 | 3; label: string }) {
  return (
    <span className="inline-flex items-center gap-2">
      <span aria-hidden className="flex gap-[3px]">
        {[1, 2, 3].map((i) => (
          <span
            key={i}
            className="block h-[7px] w-[7px] rounded-full"
            style={{
              background: i <= level ? 'currentColor' : 'transparent',
              boxShadow: i <= level ? 'none' : 'inset 0 0 0 1.5px currentColor',
              opacity: i <= level ? 0.9 : 0.4,
            }}
          />
        ))}
      </span>
      <span>{label}</span>
    </span>
  )
}

export function GameCard({ game, className = '' }: { game: Game; className?: string }) {
  const Mark = GAME_MARKS[game.slug]

  return (
    <article
      className={`group card relative flex h-full flex-col overflow-hidden p-6 transition-[transform,box-shadow,border-color] duration-[var(--dur-card)] ease-[var(--ease-out)] hover:-translate-y-1 hover:shadow-[var(--shadow-3)] focus-within:-translate-y-1 ${className}`}
      style={{ borderColor: 'var(--line)' }}
    >
      {/* the game's own accent, used as a soft field in the corner */}
      <span
        aria-hidden
        className="pointer-events-none absolute -bottom-16 -right-16 h-48 w-48 rounded-full opacity-70 transition-transform duration-[var(--dur-card)] ease-[var(--ease-out)] group-hover:scale-110"
        style={{ background: `var(${game.accentVar}-soft)` }}
      />

      <div className="relative flex items-start justify-between gap-4">
        <span
          className="inline-flex h-14 w-14 items-center justify-center rounded-[var(--r-md)]"
          style={{ background: `var(${game.accentVar}-soft)`, color: `var(${game.accentVar})` }}
        >
          <Mark size={28} />
        </span>
        {game.alsoKnownAs && (
          <span className="eyebrow text-right leading-tight">
            also called
            <br />
            {game.alsoKnownAs.slice(0, 2).join(' · ')}
          </span>
        )}
      </div>

      <h3 className="relative mt-5 text-[1.5rem]">{game.name}</h3>
      <p className="relative mt-2 flex-1 text-[0.9375rem] leading-[1.5] text-[var(--text-muted)]">
        {game.cardLine}
      </p>

      <dl className="relative mt-5 flex flex-wrap items-center gap-x-5 gap-y-2 text-[0.8125rem] text-[var(--text-muted)]">
        <div className="flex items-center gap-2">
          <dt className="sr-only">Players</dt>
          <Players size={16} />
          <dd>{game.players}</dd>
        </div>
        <div className="flex items-center gap-2">
          <dt className="sr-only">Complexity</dt>
          <dd style={{ color: `var(${game.accentVar}-text)` }}>
            <ComplexityMeter level={game.complexityLevel} label={game.complexity} />
          </dd>
        </div>
      </dl>

      <Link
        href={`/games/${game.slug}`}
        className="relative mt-5 inline-flex min-h-[48px] items-center gap-1.5 font-display text-[0.9375rem] font-bold uppercase tracking-[0.06em] transition-colors"
        style={{ color: `var(${game.accentVar}-text)` }}
      >
        {/* stretched link: the whole card is the target, keyboard focus is on the link */}
        <span className="absolute inset-[-1.5rem] z-10" aria-hidden />
        Learn {game.name}
        <ChevronRight
          size={17}
          className="transition-transform duration-[var(--dur-quick)] group-hover:translate-x-1"
        />
      </Link>
    </article>
  )
}
