import type { WorkedExample } from '@/content/types'

/**
 * A worked hole, styled like the app's own example block: a card, tabular
 * numbers, the deciding rows emphasised, and the outcome in a band underneath.
 *
 * Team sides are marked with a name and a fill, never colour alone — the same
 * rule the app's design system sets out.
 */
export function GameRulesExample({
  example,
  accentVar,
  className = '',
}: {
  example: WorkedExample
  accentVar: string
  className?: string
}) {
  return (
    <figure className={`card overflow-hidden ${className}`}>
      <figcaption className="border-b border-[var(--line)] px-6 py-5">
        <p className="eyebrow mb-1.5">Worked example</p>
        <h3 className="text-[1.125rem] leading-snug">{example.title}</h3>
        {example.intro && (
          <p className="mt-2 text-[0.9375rem] leading-[1.5] text-[var(--text-muted)]">
            {example.intro}
          </p>
        )}
      </figcaption>

      {/* The table can be wider than a 320px phone once a label is long. It
          scrolls inside its own box rather than widening the page. */}
      <div className="overflow-x-auto">
        <table className="w-full">
          <caption className="sr-only">{example.title} — scores and outcome</caption>
          <tbody>
            {example.rows.map((row, i) => (
            <tr
              key={`${row.label}-${i}`}
              className="border-b border-[var(--line)] last:border-b-0"
              style={
                row.emphasis
                  ? { background: `var(${accentVar}-soft)` }
                  : undefined
              }
            >
              <th
                scope="row"
                className="w-full py-3.5 pl-6 pr-3 text-left text-[0.9375rem] font-normal"
                style={{
                  color: row.emphasis ? 'var(--text)' : 'var(--text-muted)',
                  fontWeight: row.emphasis ? 600 : 400,
                }}
              >
                {row.side && (
                  <span
                    aria-hidden
                    className="mr-2.5 inline-block h-2.5 w-2.5 rounded-full align-[1px]"
                    style={{
                      background: row.side === 'a' ? 'var(--team-green)' : 'var(--team-sand)',
                    }}
                  />
                )}
                {row.label}
              </th>
              <td
                className="num whitespace-nowrap py-3.5 pl-3 pr-6 text-right text-[1.0625rem]"
                style={{
                  color: row.emphasis ? `var(${accentVar}-text)` : 'var(--text)',
                  fontSize: row.emphasis ? '1.25rem' : undefined,
                }}
              >
                {row.value}
              </td>
            </tr>
          ))}
          </tbody>
        </table>
      </div>

      <div
        className="px-6 py-5"
        style={{ background: `var(${accentVar}-deep)`, color: 'var(--cream-100)' }}
      >
        <p className="eyebrow mb-1" style={{ color: 'inherit', opacity: 0.75 }}>
          Result
        </p>
        <p className="font-display text-[1.1875rem] font-bold leading-snug">{example.result}</p>
      </div>
    </figure>
  )
}
