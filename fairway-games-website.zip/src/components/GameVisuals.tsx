/**
 * One bespoke visual per game page — the piece that makes each rules page feel
 * designed rather than templated. Every one of them is CSS and inline SVG: no
 * images, no libraries, no layout shift.
 */

import { MarkWolf, Ball } from './Icons'

/* ------------------------------------------------------------------- Vegas */

/**
 * The number build. Two scores slide together into one two-digit number, and
 * the difference lands underneath. This is the whole game in one graphic, and
 * it is the reason the Vegas page converts: people who did not understand
 * Vegas understand it after looking at this for three seconds.
 */
export function VegasNumberBuild() {
  const Team = ({
    name,
    a,
    b,
    number,
    tone,
    delay,
  }: {
    name: string
    a: string
    b: string
    number: string
    tone: 'green' | 'sand'
    delay: number
  }) => (
    <div className="flex flex-col items-center gap-3">
      <p className="eyebrow">{name}</p>
      <div className="flex items-center gap-2.5">
        <span
          className="num flex h-14 w-14 items-center justify-center rounded-[var(--r-md)] text-[1.75rem] sm:h-16 sm:w-16 sm:text-[2rem]"
          style={{
            background: tone === 'green' ? 'var(--team-green-soft)' : 'var(--team-sand-soft)',
            color: tone === 'green' ? 'var(--team-green)' : 'var(--on-accent-soft)',
          }}
        >
          {a}
        </span>
        <span aria-hidden className="text-[var(--text-muted)]">
          +
        </span>
        <span
          className="num flex h-14 w-14 items-center justify-center rounded-[var(--r-md)] text-[1.75rem] sm:h-16 sm:w-16 sm:text-[2rem]"
          style={{
            background: tone === 'green' ? 'var(--team-green-soft)' : 'var(--team-sand-soft)',
            color: tone === 'green' ? 'var(--team-green)' : 'var(--on-accent-soft)',
          }}
        >
          {b}
        </span>
      </div>
      <svg width="20" height="22" viewBox="0 0 20 22" aria-hidden className="text-[var(--text-faint)]">
        <path
          d="M10 2v14M4.5 11.5 10 17l5.5-5.5"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.75"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
      <span
        className="num anim-land rounded-[var(--r-md)] px-5 py-2 text-[2.75rem] leading-none sm:text-[3.5rem]"
        style={{
          animationDelay: `${delay}ms`,
          background: tone === 'green' ? 'var(--team-green)' : 'var(--team-sand)',
          // Sand is a light fill: cream on it is 3.5:1. Ink on it is 5.1:1.
          color: tone === 'green' ? 'var(--cream-100)' : 'var(--ink-900)',
        }}
      >
        {number}
      </span>
    </div>
  )

  return (
    <div className="card p-6 sm:p-8">
      <div className="flex flex-wrap items-start justify-center gap-8 sm:gap-14">
        <Team name="Marc + Phil" a="4" b="5" number="45" tone="green" delay={80} />
        <span className="self-center pt-14 font-display text-[1.5rem] text-[var(--text-muted)]">
          vs
        </span>
        <Team name="Mike + John" a="3" b="6" number="36" tone="sand" delay={200} />
      </div>

      <div className="mt-8 border-t border-[var(--line)] pt-7 text-center">
        <p className="eyebrow">The difference is the damage</p>
        <p
          className="num anim-land mt-2 leading-none"
          style={{
            fontSize: 'var(--display-num)',
            color: 'var(--game-vegas-text)',
            animationDelay: '340ms',
          }}
        >
          9
        </p>
        <p className="mt-3 text-[0.9375rem] text-[var(--text-muted)]">
          45 against 36. Mike and John win nine points — not one.
        </p>
      </div>
    </div>
  )
}

/* ------------------------------------------------------------------- Skins */

/** Three holes, one tie, and the pot doubling. */
export function SkinsCarryStrip() {
  const holes = [
    { hole: 1, value: 1, outcome: 'Marc wins', state: 'won' as const },
    { hole: 2, value: 1, outcome: 'Tied — carries', state: 'tied' as const },
    { hole: 3, value: 2, outcome: 'Mike wins 2', state: 'won' as const },
  ]

  return (
    <div className="card overflow-hidden">
      <div className="grid grid-cols-3 divide-x divide-[var(--line)]">
        {holes.map((h) => (
          <div key={h.hole} className="p-5 text-center sm:p-6">
            <p className="eyebrow">Hole {h.hole}</p>
            <p
              className="num mt-3 leading-none"
              style={{
                fontSize: 'clamp(2.5rem, 1.5rem + 4vw, 4rem)',
                color: h.value > 1 ? 'var(--game-skins-text)' : 'var(--text)',
              }}
            >
              {h.value}
            </p>
            <p className="mt-1 text-[0.75rem] uppercase tracking-[0.1em] text-[var(--text-muted)]">
              {h.value === 1 ? 'skin' : 'skins'}
            </p>
            <p
              className="mt-4 inline-flex items-center gap-1.5 rounded-[var(--r-pill)] px-3 py-1.5 text-[0.8125rem] font-medium"
              style={{
                background: h.state === 'won' ? 'var(--good-soft)' : 'var(--accent-soft)',
                color: h.state === 'won' ? 'var(--good-text)' : 'var(--on-accent-soft)',
              }}
            >
              {h.outcome}
            </p>
          </div>
        ))}
      </div>
      <p className="border-t border-[var(--line)] px-6 py-4 text-center text-[0.875rem] text-[var(--text-muted)]">
        Tie a hole and nobody wins it. The skin rolls forward, so the next tee is worth double.
      </p>
    </div>
  )
}

/* ------------------------------------------------------------------ Nassau */

/** Three matches as three bars. */
export function NassauThreeMatches() {
  const matches = [
    { label: 'Front nine', holes: '1–9', status: 'Lost 2 & 1', won: false },
    { label: 'Back nine', holes: '10–18', status: 'Won 3 & 2', won: true },
    { label: 'Overall', holes: '1–18', status: 'Won 1 up', won: true },
  ]

  return (
    <div className="card p-6 sm:p-8">
      <ul className="space-y-4">
        {matches.map((m) => (
          <li key={m.label}>
            <div className="flex items-baseline justify-between gap-4">
              <p className="font-display text-[1.0625rem] font-bold">
                {m.label}{' '}
                <span className="font-text text-[0.8125rem] font-normal text-[var(--text-faint)]">
                  holes {m.holes}
                </span>
              </p>
              <p
                className="num whitespace-nowrap text-[1.0625rem]"
                style={{ color: m.won ? 'var(--good-text)' : 'var(--bad-text)' }}
              >
                {m.won ? '▲' : '▼'} {m.status}
              </p>
            </div>
            <div
              className="mt-2 h-3 overflow-hidden rounded-[var(--r-pill)]"
              style={{ background: 'var(--game-nassau-soft)' }}
            >
              <div
                className="h-full rounded-[var(--r-pill)]"
                style={{
                  width: m.label === 'Overall' ? '100%' : '50%',
                  marginLeft: m.label === 'Back nine' ? '50%' : 0,
                  background: 'var(--game-nassau)',
                  opacity: m.won ? 1 : 0.45,
                }}
              />
            </div>
          </li>
        ))}
      </ul>
      <p className="mt-6 border-t border-[var(--line)] pt-5 text-[0.9375rem] text-[var(--text-muted)]">
        One bad nine costs one bet, not the round. That is why golfers have played a Nassau for a
        hundred years.
      </p>
    </div>
  )
}

/* -------------------------------------------------------------------- Dots */

/** The dot list, exactly as it ships — the "Dot Builder" the brief asked for. */
export function DotBuilder() {
  const dots = [
    { emoji: '🐦', name: 'Birdie', pts: 1, on: true, note: 'Automatic' },
    { emoji: '🦅', name: 'Eagle', pts: 2, on: true, note: 'Automatic' },
    { emoji: '🎯', name: 'Greenie', pts: 1, on: true, note: 'Closest on a par 3' },
    { emoji: '🏖', name: 'Sandy', pts: 1, on: true, note: 'Up and down from sand' },
    { emoji: '⛳', name: 'Chip-In', pts: 1, on: true, note: 'Holed from off the green' },
    { emoji: '🐍', name: 'Snake', pts: -1, on: true, note: 'Three-putt' },
    { emoji: '📏', name: 'Long Putt', pts: 1, on: false, note: 'Outside an agreed distance' },
    { emoji: '🚩', name: 'Poley', pts: 1, on: false, note: 'From a flagstick’s length' },
    { emoji: '🌳', name: 'Barkie', pts: 1, on: false, note: 'Tree, and still a par' },
    { emoji: '🏌', name: 'Arnie', pts: 1, on: false, note: 'Par without a fairway' },
  ]

  return (
    <div className="card overflow-hidden">
      <div className="flex items-center justify-between border-b border-[var(--line)] px-6 py-4">
        <p className="eyebrow">Dot builder</p>
        <p className="text-[0.8125rem] text-[var(--text-muted)]">6 of 11 on</p>
      </div>
      <ul className="divide-y divide-[var(--line)]">
        {dots.map((d) => (
          <li key={d.name} className="flex items-center gap-4 px-6 py-3.5">
            <span aria-hidden className="text-[1.25rem]">
              {d.emoji}
            </span>
            <span className="flex-1">
              <span className="block font-display text-[0.9375rem] font-bold">{d.name}</span>
              <span className="block text-[0.8125rem] text-[var(--text-muted)]">{d.note}</span>
            </span>
            <span
              className="num text-[1rem]"
              style={{ color: d.pts > 0 ? 'var(--good-text)' : 'var(--bad-text)' }}
            >
              {d.pts > 0 ? `+${d.pts}` : d.pts}
            </span>
            <span
              aria-hidden
              className="relative block h-[26px] w-[46px] shrink-0 rounded-[var(--r-pill)] transition-colors"
              style={{ background: d.on ? 'var(--game-dots)' : 'var(--line-strong)' }}
            >
              <span
                className="absolute top-[3px] block h-[20px] w-[20px] rounded-full bg-[var(--cream-100)] transition-[left]"
                style={{ left: d.on ? '23px' : '3px' }}
              />
            </span>
            <span className="sr-only">{d.on ? 'on' : 'off'}</span>
          </li>
        ))}
      </ul>
      <p className="border-t border-[var(--line)] px-6 py-4 text-[0.875rem] text-[var(--text-muted)]">
        Rename any dot, change what it pays, or add one of your own. Your group already has a dot
        nobody else has heard of — put it in the list.
      </p>
    </div>
  )
}

/* -------------------------------------------------------------------- Wolf */

/** The Wolf's decision, drawn as three doors. */
export function WolfChoice() {
  const options = [
    { title: 'Take a partner', points: '+2 each', note: 'Safe. Two balls, best one counts.' },
    { title: 'Lone Wolf', points: '+3', note: 'Alone against three. Lose it and they get 2 each.' },
    { title: 'Blind Wolf', points: '+6', note: 'Alone, before a single drive. Double points.' },
  ]

  return (
    <div className="grid gap-4 sm:grid-cols-3">
      {options.map((o, i) => (
        <div
          key={o.title}
          className="card flex flex-col p-6"
          style={
            i > 0
              ? { borderStyle: 'dashed', borderColor: 'var(--game-wolf)', borderWidth: 1.5 }
              : undefined
          }
        >
          <span
            className="inline-flex h-11 w-11 items-center justify-center rounded-[var(--r-md)]"
            style={{ background: 'var(--game-wolf-soft)', color: 'var(--game-wolf-text)' }}
          >
            {i === 0 ? <Ball size={22} /> : <MarkWolf size={22} />}
          </span>
          <h3 className="mt-4 text-[1.125rem]">{o.title}</h3>
          <p
            className="num mt-2 text-[2rem] leading-none"
            style={{ color: 'var(--game-wolf-text)' }}
          >
            {o.points}
          </p>
          <p className="mt-3 text-[0.875rem] leading-[1.5] text-[var(--text-muted)]">{o.note}</p>
        </div>
      ))}
    </div>
  )
}

/* -------------------------------------------------------------- Team Match */

/** The match status ladder — how a 2v2 result is written. */
export function MatchStatusLadder() {
  const rows = [
    { code: 'AS', meaning: 'All square. The match is level.' },
    { code: '1 UP', meaning: 'One hole ahead.' },
    { code: 'DORMIE', meaning: 'Up by exactly the holes remaining. Cannot lose from here.' },
    { code: '4 & 3', meaning: 'Four up with three to play. Finished on the 15th.' },
  ]

  return (
    <div className="card overflow-hidden">
      <ul className="divide-y divide-[var(--line)]">
        {rows.map((r) => (
          <li key={r.code} className="flex items-center gap-5 px-6 py-4">
            <span
              className="num inline-flex min-w-[104px] justify-center rounded-[var(--r-sm)] px-3 py-2 text-[1.0625rem]"
              style={{ background: 'var(--game-match-soft)', color: 'var(--game-match-text)' }}
            >
              {r.code}
            </span>
            <span className="text-[0.9375rem] text-[var(--text-muted)]">{r.meaning}</span>
          </li>
        ))}
      </ul>
    </div>
  )
}

export const GAME_VISUALS: Record<string, () => React.ReactElement> = {
  wolf: WolfChoice,
  skins: SkinsCarryStrip,
  nassau: NassauThreeMatches,
  vegas: VegasNumberBuild,
  dots: DotBuilder,
  'team-match-play': MatchStatusLadder,
}
