'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useEffect, useRef, useState } from 'react'
import { siteConfig } from '@config'
import { primaryNav } from '@/content/site'
import { games } from '@/content/games'
import { BrandCrest } from './Art'
import { GAME_MARKS, Menu, Close, ChevronRight } from './Icons'
import { ThemeToggle } from './ThemeToggle'

export function Header() {
  const pathname = usePathname()
  const [open, setOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const panelRef = useRef<HTMLDivElement>(null)
  const triggerRef = useRef<HTMLButtonElement>(null)

  // Close the menu on navigation.
  useEffect(() => {
    setOpen(false)
  }, [pathname])

  // A solid header once the page has moved, so the wordmark never sits on art.
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  // Escape closes, and focus returns to the trigger rather than the page top.
  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setOpen(false)
        triggerRef.current?.focus()
      }
    }
    document.addEventListener('keydown', onKey)
    document.body.style.overflow = 'hidden'
    return () => {
      document.removeEventListener('keydown', onKey)
      document.body.style.overflow = ''
    }
  }, [open])

  const isActive = (href: string) =>
    href === '/' ? pathname === '/' : pathname === href || pathname.startsWith(`${href}/`)

  return (
    <header
      className="sticky top-0 z-50 transition-[background-color,border-color,box-shadow] duration-[var(--dur-card)]"
      style={{
        background: scrolled || open ? 'color-mix(in srgb, var(--bg) 88%, transparent)' : 'transparent',
        backdropFilter: scrolled || open ? 'saturate(1.4) blur(14px)' : undefined,
        WebkitBackdropFilter: scrolled || open ? 'saturate(1.4) blur(14px)' : undefined,
        borderBottom: `1px solid ${scrolled || open ? 'var(--line)' : 'transparent'}`,
      }}
    >
      <div className="rail flex h-[72px] items-center justify-between gap-4">
        <Link
          href="/"
          className="flex min-h-[44px] items-center gap-2.5 rounded-[var(--r-sm)]"
          aria-label={`${siteConfig.name} — home`}
        >
          <BrandCrest size={34} />
          <span className="font-display text-[1.0625rem] font-bold uppercase tracking-[0.13em]">
            {siteConfig.name}
          </span>
        </Link>

        {/* desktop nav */}
        <nav aria-label="Primary" className="hidden lg:block">
          <ul className="flex items-center gap-1">
            {primaryNav.map((item) => (
              <li key={item.href}>
                <Link
                  href={item.href}
                  aria-current={isActive(item.href) ? 'page' : undefined}
                  className="inline-flex min-h-[44px] items-center rounded-[var(--r-sm)] px-4 text-[0.9375rem] font-medium transition-colors hover:text-[var(--brand)]"
                  style={{ color: isActive(item.href) ? 'var(--brand)' : 'var(--text-muted)' }}
                >
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <div className="flex items-center gap-2">
          <ThemeToggle className="hidden sm:inline-flex" />
          <Link
            href="/download"
            data-event="download-cta-header"
            className="hidden min-h-[44px] items-center rounded-[var(--r-md)] bg-[var(--brand)] px-5 font-display text-[0.875rem] font-bold uppercase tracking-[0.06em] text-[var(--text-on-brand)] transition-[filter] hover:brightness-110 sm:inline-flex"
          >
            Get the App
          </Link>

          <button
            ref={triggerRef}
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-expanded={open}
            aria-controls="mobile-menu"
            aria-label={open ? 'Close menu' : 'Open menu'}
            className="inline-flex h-11 w-11 items-center justify-center rounded-[var(--r-md)] text-[var(--text)] transition-colors hover:bg-[var(--surface-2)] lg:hidden"
          >
            {open ? <Close size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      {/* mobile menu */}
      {open && (
        <div
          id="mobile-menu"
          ref={panelRef}
          className="anim-rise max-h-[calc(100dvh-72px)] overflow-y-auto border-t border-[var(--line)] bg-[var(--bg)] lg:hidden"
        >
          <nav aria-label="Mobile" className="rail py-6">
            <p className="eyebrow mb-3">Games</p>
            <ul className="grid grid-cols-2 gap-2">
              {games.map((g) => {
                const Mark = GAME_MARKS[g.slug]
                return (
                  <li key={g.slug}>
                    <Link
                      href={`/games/${g.slug}`}
                      className="flex min-h-[56px] items-center gap-3 rounded-[var(--r-md)] border border-[var(--line)] px-3 text-[0.9375rem] font-medium"
                    >
                      <span
                        className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-[var(--r-xs)]"
                        style={{
                          background: `var(${g.accentVar}-soft)`,
                          color: `var(${g.accentVar})`,
                        }}
                      >
                        <Mark size={18} />
                      </span>
                      {g.name}
                    </Link>
                  </li>
                )
              })}
            </ul>

            <p className="eyebrow mb-3 mt-7">Product</p>
            <ul className="divide-y divide-[var(--line)] border-y border-[var(--line)]">
              {primaryNav.map((item) => (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    aria-current={isActive(item.href) ? 'page' : undefined}
                    className="flex min-h-[56px] items-center justify-between text-[1.0625rem] font-medium"
                  >
                    {item.label}
                    <ChevronRight size={18} className="text-[var(--text-faint)]" />
                  </Link>
                </li>
              ))}
            </ul>

            <div className="mt-6 flex items-center gap-3">
              <Link
                href="/download"
                data-event="download-cta-menu"
                className="inline-flex min-h-[56px] flex-1 items-center justify-center rounded-[var(--r-md)] bg-[var(--brand)] px-6 font-display font-bold uppercase tracking-[0.06em] text-[var(--text-on-brand)]"
              >
                Get the App
              </Link>
              <ThemeToggle className="border border-[var(--line)] sm:hidden" />
            </div>
          </nav>
        </div>
      )}
    </header>
  )
}
