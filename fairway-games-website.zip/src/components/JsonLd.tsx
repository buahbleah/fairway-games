/**
 * Renders a JSON-LD block. Kept as its own component so no page has to think
 * about dangerouslySetInnerHTML, and so the escaping happens in one place.
 */
export function JsonLd({ data }: { data: Record<string, unknown> }) {
  return (
    <script
      type="application/ld+json"
      // JSON.stringify output is escaped for the two sequences that can break
      // out of a <script> element.
      dangerouslySetInnerHTML={{
        __html: JSON.stringify(data).replace(/</g, '\\u003c').replace(/-->/g, '--\\u003e'),
      }}
    />
  )
}
