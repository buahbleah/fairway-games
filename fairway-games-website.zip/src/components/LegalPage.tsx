import type { ReactNode } from 'react'
import { Breadcrumbs } from './Breadcrumbs'
import { ContourBackdrop } from './Art'

/** Marks a value that still has to be filled in before the site goes live.
 *  Rendered visibly, on purpose — a placeholder that looks finished is worse
 *  than one that shouts. Every occurrence is listed in the README. */
export function Placeholder({ children }: { children: ReactNode }) {
  return (
    <mark
      className="rounded-[var(--r-xs)] px-1.5 py-0.5 font-medium"
      style={{ background: 'var(--accent-soft)', color: 'var(--on-accent-soft)' }}
      title="Placeholder — replace before publishing"
    >
      {children}
    </mark>
  )
}

export function LegalPage({
  title,
  updated,
  intro,
  crumbLabel,
  path,
  children,
}: {
  title: string
  updated: string
  intro: string
  crumbLabel: string
  path: string
  children: ReactNode
}) {
  return (
    <>
      <section className="relative overflow-hidden border-b border-[var(--line)]">
        <ContourBackdrop
          opacity={0.06}
          className="pointer-events-none absolute inset-0 h-full w-full text-[var(--brand)]"
        />
        <div className="rail relative py-12 sm:py-16">
          <Breadcrumbs crumbs={[{ name: 'Home', path: '/' }, { name: crumbLabel, path }]} />
          <h1 className="display-2 max-w-[20ch]">{title}</h1>
          <p className="mt-4 text-[0.875rem] text-[var(--text-muted)]">Last updated: {updated}</p>
          <p className="lede mt-5">{intro}</p>
        </div>
      </section>

      <section className="section">
        <div className="rail-narrow">
          <article className="prose-fw">{children}</article>
        </div>
      </section>
    </>
  )
}
