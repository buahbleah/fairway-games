import Image from 'next/image'

interface Props {
  src: string
  alt: string
  /**
   * The device's maximum rendered width in CSS pixels. It is a *maximum*, not a
   * fixed width: a fixed inline width makes the mockup the widest thing in its
   * grid cell, which drags the whole column past the viewport on a 320px phone.
   */
  width?: number
  priority?: boolean
  className?: string
  /** Tilt the device slightly, for layered showcase arrangements. */
  tilt?: number
  /** Adds the sand ring behind the device used in the hero. */
  glow?: boolean
  sizes?: string
}

/**
 * A device frame around a real app screenshot.
 *
 * The screenshots are 780×1688 captures of the actual product — not redrawn
 * marketing mock-ups — so what a visitor sees here is what they get. The frame
 * is drawn in CSS rather than as an image so it stays crisp and costs nothing.
 */
export function PhoneMockup({
  src,
  alt,
  width = 300,
  priority = false,
  className = '',
  tilt = 0,
  glow = false,
  sizes,
}: Props) {
  return (
    <div
      className={`relative w-full ${className}`}
      style={{ maxWidth: width, transform: tilt ? `rotate(${tilt}deg)` : undefined }}
    >
      {glow && (
        <div
          aria-hidden
          className="pointer-events-none absolute -inset-[12%] rounded-full blur-3xl"
          style={{
            background:
              'radial-gradient(closest-side, var(--accent-soft), transparent 72%)',
            opacity: 0.9,
          }}
        />
      )}

      {/* device body */}
      <div
        className="relative rounded-[2.6rem] p-[3px]"
        style={{
          background: 'linear-gradient(160deg, var(--ink-500), var(--ink-900) 42%, var(--ink-700))',
          boxShadow: 'var(--shadow-3)',
        }}
      >
        <div
          className="relative overflow-hidden rounded-[2.45rem] bg-[var(--green-900)]"
          style={{ aspectRatio: '780 / 1688' }}
        >
          <Image
            src={src}
            alt={alt}
            width={780}
            height={1688}
            priority={priority}
            sizes={sizes ?? `(max-width: 640px) 90vw, ${width}px`}
            className="h-full w-full object-cover object-top"
          />

          {/* screen sheen — subtle, and behind nothing interactive */}
          <div
            aria-hidden
            className="pointer-events-none absolute inset-0"
            style={{
              background:
                'linear-gradient(112deg, rgba(255,255,255,0.14) 0%, rgba(255,255,255,0) 38%)',
            }}
          />
        </div>

        {/* dynamic-island style cutout */}
        <div
          aria-hidden
          className="absolute left-1/2 top-[10px] h-[18px] w-[74px] -translate-x-1/2 rounded-full"
          style={{ background: 'var(--ink-900)' }}
        />
      </div>
    </div>
  )
}
