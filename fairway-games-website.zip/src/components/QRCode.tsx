import qr from 'qrcode-generator'

/**
 * A QR code rendered as inline SVG on the server.
 *
 * No image request, no third-party QR service (which would leak the visitor's
 * IP to someone else), no client JavaScript. The value is whatever the site
 * config says the public URL is, so it is correct on every deployment and
 * never a made-up production link.
 */
export function QRCode({
  value,
  size = 148,
  title,
  className = '',
}: {
  value: string
  size?: number
  title: string
  className?: string
}) {
  const code = qr(0, 'M')
  code.addData(value)
  code.make()

  const count = code.getModuleCount()
  const quiet = 2
  const dim = count + quiet * 2

  const paths: string[] = []
  for (let row = 0; row < count; row++) {
    for (let col = 0; col < count; col++) {
      if (code.isDark(row, col)) {
        paths.push(`M${col + quiet} ${row + quiet}h1v1h-1z`)
      }
    }
  }

  return (
    <svg
      viewBox={`0 0 ${dim} ${dim}`}
      width={size}
      height={size}
      role="img"
      aria-label={title}
      className={className}
      shapeRendering="crispEdges"
    >
      <title>{title}</title>
      <rect width={dim} height={dim} fill="var(--cream-100)" rx="0.8" />
      <path d={paths.join('')} fill="var(--green-800)" />
    </svg>
  )
}
