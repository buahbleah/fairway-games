import type { ReactNode } from 'react'

interface Props {
  eyebrow?: string
  title: ReactNode
  lede?: ReactNode
  align?: 'left' | 'center'
  as?: 'h2' | 'h3'
  className?: string
  id?: string
}

export function SectionHeading({
  eyebrow,
  title,
  lede,
  align = 'left',
  as: Tag = 'h2',
  className = '',
  id,
}: Props) {
  return (
    <div
      className={`${align === 'center' ? 'mx-auto text-center' : ''} ${className}`}
      style={align === 'center' ? { maxWidth: '46rem' } : undefined}
    >
      {eyebrow && (
        <p className="eyebrow mb-3 flex items-center gap-3">
          {align === 'center' && <span aria-hidden className="h-px flex-1 bg-[var(--line)]" />}
          {eyebrow}
          <span aria-hidden className="h-px flex-1 bg-[var(--line)]" />
        </p>
      )}
      <Tag id={id} className={Tag === 'h2' ? 'display-2' : 'display-3'}>
        {title}
      </Tag>
      {lede && <div className={`lede mt-5 ${align === 'center' ? 'mx-auto' : ''}`}>{lede}</div>}
    </div>
  )
}
