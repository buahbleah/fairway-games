'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useEffect, useState } from 'react'
import { Download } from './Icons'

/**
 * Sticky CTA, phones only.
 *
 * Three rules, all of them there so it helps rather than annoys:
 *  1. It does not appear until the visitor has scrolled past the hero, so the
 *     first screen is never covered.
 *  2. It hides itself on /download — offering a download button on the download
 *     page is noise.
 *  3. It is a single 56px bar, not a sheet, and it sits above the safe area so
 *     it never fights the home indicator.
 */
export function StickyMobileCTA() {
  const pathname = usePathname()
  const [show, setShow] = useState(false)

  useEffect(() => {
    const onScroll = () => setShow(window.scrollY > 620)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  if (pathname === '/download') return null

  return (
    <div
      aria-hidden={!show}
      className="pointer-events-none fixed inset-x-0 bottom-0 z-40 px-4 pb-[calc(env(safe-area-inset-bottom,0px)+0.75rem)] sm:hidden"
      style={{
        transform: show ? 'none' : 'translateY(130%)',
        opacity: show ? 1 : 0,
        transition:
          'transform var(--dur-card) var(--ease-out), opacity var(--dur-quick) var(--ease-out)',
      }}
    >
      <Link
        href="/download"
        tabIndex={show ? undefined : -1}
        data-event="download-cta-sticky"
        className="pointer-events-auto flex min-h-[56px] items-center justify-center gap-2.5 rounded-[var(--r-md)] bg-[var(--brand)] font-display text-[1rem] font-bold uppercase tracking-[0.06em] text-[var(--text-on-brand)] shadow-[var(--shadow-3)]"
      >
        <Download size={20} />
        Get the App
      </Link>
    </div>
  )
}
