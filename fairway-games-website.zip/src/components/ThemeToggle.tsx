'use client'

import { useEffect, useState } from 'react'
import { Sun, Moon } from './Icons'

type Theme = 'light' | 'dark'

/**
 * Light / dark toggle.
 *
 * Dark is the site's default and is expressed by the ABSENCE of a data-theme
 * attribute, so light is the only state that has to be written down. The
 * inline script in the document head applies a stored light preference before
 * first paint; this component mirrors and changes it.
 */
export function ThemeToggle({ className = '' }: { className?: string }) {
  const [theme, setTheme] = useState<Theme | null>(null)

  useEffect(() => {
    // Dark is the default; only an explicit light choice sets the attribute.
    const explicit = document.documentElement.getAttribute('data-theme') as Theme | null
    setTheme(explicit === 'light' ? 'light' : 'dark')
  }, [])

  function toggle() {
    const next: Theme = theme === 'dark' ? 'light' : 'dark'
    setTheme(next)
    // Dark is the absence of the attribute, so switching back removes it.
    if (next === 'light') document.documentElement.setAttribute('data-theme', 'light')
    else document.documentElement.removeAttribute('data-theme')
    try {
      localStorage.setItem('fw-theme', next)
    } catch {
      /* private mode, blocked storage — the toggle still works for this visit */
    }
  }

  const label = theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'

  return (
    <button
      type="button"
      onClick={toggle}
      aria-label={label}
      title={label}
      className={`inline-flex h-11 w-11 items-center justify-center rounded-[var(--r-md)] text-[var(--text-muted)] transition-colors hover:bg-[var(--surface-2)] hover:text-[var(--text)] ${className}`}
    >
      {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
    </button>
  )
}
