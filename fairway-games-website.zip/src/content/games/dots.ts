import type { Game } from '../types'

export const dots: Game = {
  slug: 'dots',
  name: 'Dots',
  pageTitle: 'Golf Dots, Junk and Trash Rules',
  tagline: 'Earn points for birdies, greenies, sandies and everything else worth doing.',
  cardLine: 'Earn points for birdies, greenies, sandies and custom achievements.',
  summary:
    'Dots — also called Junk, Trash or Garbage — pays points for the moments a scorecard misses. Birdies, greenies, sandies, chip-ins. And it takes points back for a three-putt.',
  alsoKnownAs: ['Junk', 'Trash', 'Garbage'],
  players: '2–4 players',
  playersMin: 2,
  playersMax: 4,
  complexity: 'Easy',
  complexityLevel: 2,
  accentVar: '--game-dots',
  explainTime: 'Read the list, start playing',
  hook: 'The scorecard says you made 5. It does not say you holed a 40-footer from the car park.',

  sections: [
    {
      title: 'How it runs',
      body: [
        'Play your normal golf and enter your scores as usual.',
        'After the hole the app asks “anything extra?” and you tap whatever anybody earned. It takes a few seconds.',
        'Birdies and eagles are picked up automatically from the score. You only tap the things the app cannot see — a greenie, a sandy, a chip-in, a three-putt.',
      ],
    },
    {
      title: 'The dots that ship on by default',
      body: [
        'Birdie +1 — one under par, counted automatically.',
        'Eagle +2 — two under par, counted automatically, and it replaces the birdie.',
        'Greenie +1 — closest to the pin on a par 3, having hit the green from the tee.',
        'Sandy +1 — up and down out of a bunker.',
        'Chip-In +1 — holed from off the green.',
        'Snake −1 — a three-putt. The one dot nobody wants.',
      ],
    },
    {
      title: 'And the ones waiting to be switched on',
      body: [
        'Long Putt +1 — a putt holed from outside an agreed distance, usually about ten metres.',
        'Poley +1 — holing a putt from at least the length of the flagstick.',
        'Barkie +1 — hitting a tree during the hole and still making par or better.',
        'Arnie +1 — par or better without ever being on the fairway, named after Arnold Palmer’s scrambling.',
        'Disaster −1 — double bogey or worse, counted automatically.',
      ],
    },
    {
      title: 'Your own dots',
      body: [
        'Every dot is editable. Rename it, change what it pays, switch it off, or add one of your own.',
        'That matters because no two groups agree on what a sandy is worth, and half of them have a dot nobody else has ever heard of.',
        'The Dot Builder in the app is a list you can edit in about thirty seconds before the round.',
      ],
    },
  ],

  example: {
    title: 'Hole 12, a par 3',
    intro: 'One hole, four different afternoons.',
    rows: [
      { label: 'Marc — tee shot to three metres, holes the putt', value: 'Birdie +1, Greenie +1', emphasis: true },
      { label: 'Phil — bunker, splashes out, one putt', value: 'Sandy +1' },
      { label: 'Mike — on the green, three putts', value: 'Snake −1' },
      { label: 'John — par', value: 'Nothing' },
    ],
    result: 'Marc +2 · Phil +1 · Mike −1 · John 0',
  },

  adjustable: [
    { name: 'Active dots', text: 'Switch any dot on or off, rename it, change what it is worth, or add your own.', isDefault: true },
    { name: 'Greenies count on', text: 'Par 3s only — the usual rule — or every approach hit in regulation.', isDefault: true },
    { name: 'A greenie needs', text: 'Par or better, or no score requirement at all.', isDefault: true },
    { name: 'A sandy needs', text: 'Par or better, or just the up and down whatever the score.', isDefault: true },
    { name: 'Snake', text: 'Every three-putt pays, or holder-style: whoever three-putted last is stuck with it at the 18th.', isDefault: true },
    { name: 'Long putt distance', text: 'How far out a putt has to be to earn the dot.' },
  ],

  appDoes: [
    'Detects birdies, eagles, albatrosses, holes in one and disasters from the score alone.',
    'Keeps the running total for every player, including the negatives.',
    'Carries the snake correctly when it is played holder-style — the last three-putter pays at the 18th.',
    'Applies the score requirements you set for greenies and sandies.',
    'Remembers your group’s custom dot list as a preset for next time.',
  ],

  definitions: [
    { term: 'Greenie', text: 'Closest to the pin on a par 3, having found the green from the tee.' },
    { term: 'Sandy', text: 'Up and down from a bunker.' },
    { term: 'Snake', text: 'A three-putt.' },
    { term: 'Barkie', text: 'Hitting a tree and still making par.' },
    { term: 'Poley', text: 'Holing a putt from at least a flagstick’s length.' },
    { term: 'Arnie', text: 'Par or better without touching the fairway.' },
  ],

  faq: [
    {
      q: 'What is the Dots game in golf?',
      a: 'A side game that pays points for things a scorecard does not record — birdies, greenies, sandies, chip-ins — and takes them away for a three-putt. It runs alongside your normal round.',
    },
    {
      q: 'Is Dots the same as Junk, Trash or Garbage?',
      a: 'Yes. Same game, four names, depending on who you play with. The app calls it Dots and lists the others so people find it.',
    },
    {
      q: 'Can we use our own dots?',
      a: 'That is the point of it. Every dot can be renamed, repriced, switched off, or invented from scratch. If your group pays for something nobody else has heard of, add it in the Dot Builder.',
    },
    {
      q: 'What is a snake in golf?',
      a: 'A three-putt. Some groups charge it every time; others play it holder-style, where whoever three-putted most recently carries the snake and pays at the 18th. The app supports both.',
    },
    {
      q: 'Do we have to tap in every birdie?',
      a: 'No. Birdies, eagles and disasters come straight from the score. You only tap the things the app cannot see from a number — greenies, sandies, chip-ins, three-putts.',
    },
  ],

  seo: {
    title: 'Golf Dots Game (Junk, Trash): Rules and Point List',
    description:
      'The golf dots game explained — also called Junk, Trash or Garbage. Birdies, greenies, sandies, chip-ins and snakes, with the full point list and a free app that lets you build your own dots.',
    keywords: [
      'golf dots game',
      'junk golf game',
      'trash golf game',
      'garbage golf game',
      'golf side bets',
      'greenie sandy golf',
      'what is a snake in golf',
    ],
    ogHeadline: 'Golf Dots, Junk & Trash',
  },

  screenshot: '/app/11-dots.webp',
  screenshotAlt:
    'The Fairway Games Dots screen asking “anything extra?” with tappable chips for greenie, sandy, chip-in and snake next to each player.',
}
