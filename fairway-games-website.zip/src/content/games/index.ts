/**
 * The only file that knows all six games exist.
 *
 * Adding a seventh — Bingo Bango Bongo, Sixes, Quota — is one import and one
 * array entry. Every route, card, nav list, sitemap entry and OpenGraph image
 * follows from here.
 */

import type { Game } from '../types'
import { wolf } from './wolf'
import { skins } from './skins'
import { nassau } from './nassau'
import { vegas } from './vegas'
import { dots } from './dots'
import { teamMatchPlay } from './team-match-play'

export const games: Game[] = [wolf, skins, nassau, vegas, dots, teamMatchPlay]

export const gameBySlug = (slug: string): Game | undefined => games.find((g) => g.slug === slug)

export const gameSlugs = games.map((g) => g.slug)

export { wolf, skins, nassau, vegas, dots, teamMatchPlay }
