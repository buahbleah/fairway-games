import type { Game } from '../types'

export const nassau: Game = {
  slug: 'nassau',
  name: 'Nassau',
  pageTitle: 'Nassau Golf Game Rules',
  tagline: 'Three matches in one round: front nine, back nine and overall.',
  cardLine: 'Three matches at once — front nine, back nine and the eighteen.',
  summary:
    'A Nassau is three bets at once: the front nine, the back nine and the full eighteen. Each is a match — you win a hole, you go one up. Losing one bet and winning the other two is a good day.',
  players: '2–4 players',
  playersMin: 2,
  playersMax: 4,
  complexity: 'Medium',
  complexityLevel: 3,
  accentVar: '--game-nassau',
  explainTime: 'A minute on the first tee',
  hook: 'Three chances to have a good day, and a way back into the round at the turn.',

  sections: [
    {
      title: 'Three matches, one round',
      body: [
        'The front nine is its own match over holes 1 to 9.',
        'The back nine is its own match over holes 10 to 18.',
        'The overall match runs across all eighteen.',
        'Each is worth its own stake, so a bad front nine costs you one bet, not the round.',
      ],
    },
    {
      title: 'Match play, not totals',
      body: [
        'Lowest score on the hole wins the hole. By how much does not matter — a 4 beating a 9 is worth exactly one hole.',
        'Level is called ALL SQUARE, written AS. One hole ahead is 1 UP.',
        'A match is over as soon as one side leads by more holes than are left. Three up with two to play is written 3 & 2.',
        'This is why a Nassau survives a blow-up hole and a stroke-play bet does not.',
      ],
    },
    {
      title: 'Presses',
      body: [
        'A press is a brand new bet that starts on the next hole and runs to the end of that nine. It never changes the original bet — it sits alongside it.',
        'Automatic presses open by themselves the moment a side goes a set number of holes down. Two down is the usual trigger; the app lets you set anything from one to five.',
        'Manual presses are asked for by the side that is behind, which is the traditional way and keeps a little theatre in it.',
        'Re-presses let a press that itself falls behind be pressed again. Off by default — that is where the arithmetic normally collapses, and it is exactly the part the app is happy to do.',
      ],
    },
    {
      title: 'Singles or teams',
      body: [
        'Two players go head to head.',
        'Four players can play as two pairs — four-ball, where the better ball of each pair counts.',
        'Or everyone plays their own Nassau against everyone else: with four players that is six simultaneous matches, each with three segments. Nobody is scoring that on a card.',
      ],
    },
  ],

  example: {
    title: 'A typical Nassau',
    intro: 'One bet lost, two won. Front nine slipped away, the back nine came good.',
    rows: [
      { label: 'Front nine', value: 'Lost 2 & 1' },
      { label: 'Back nine', value: 'Won 3 & 2', emphasis: true },
      { label: 'Overall 18', value: 'Won 1 up', emphasis: true },
    ],
    result: 'Two of the three bets won',
  },

  adjustable: [
    { name: 'Played as', text: 'Automatic, every player for themselves, or two teams.', isDefault: true },
    { name: 'Front nine / back nine / overall', text: 'Each segment has its own stake.', isDefault: true },
    { name: 'Presses', text: 'Off by default. Switch on and choose how they open.' },
    { name: 'Automatic presses', text: 'A new bet opens by itself when a side goes far enough down.' },
    { name: 'Press trigger', text: 'How many holes down starts an automatic press. Default 2.' },
    { name: 'Re-presses', text: 'A press that falls behind can itself be pressed.' },
    { name: 'Press the overall match too', text: 'Off by default — most groups only press the nine they are on.' },
    { name: 'Press value', text: 'Same as the original bet, or a custom amount.' },
    { name: 'Handicaps', text: 'Four-ball match play is normally 90% off the low player; singles is 100%.' },
  ],

  appDoes: [
    'Runs all three segments at once and shows each match’s status on the hole screen.',
    'Writes results in proper match-play notation — 1 UP, AS, dormie, 3 & 2.',
    'Closes a match out the moment it is mathematically over.',
    'Opens automatic presses on the right hole and runs each one to the end of its nine.',
    'Keeps every press as a separate live bet, including re-presses, without a scrap of paper.',
    'Builds the round-robin when everyone plays everyone — six matches, eighteen bets, all live.',
  ],

  definitions: [
    { term: 'AS', text: 'All square — the match is level.' },
    { term: '1 UP', text: 'One hole ahead.' },
    { term: 'Dormie', text: 'Ahead by exactly the number of holes left. You cannot lose from here.' },
    { term: '3 & 2', text: 'Three holes up with only two to play — the match is over.' },
    { term: 'Press', text: 'A new bet started mid-round by the side that is behind.' },
  ],

  faq: [
    {
      q: 'What is a Nassau in golf?',
      a: 'Three separate match-play bets running at the same time: the front nine, the back nine, and the overall eighteen. Each is settled on its own, so you can lose one and still finish ahead.',
    },
    {
      q: 'What does a press mean in a Nassau?',
      a: 'A press is a brand new bet opened mid-round by the side that is behind. It starts on the next hole and runs to the end of that nine. The original bet keeps running untouched.',
    },
    {
      q: 'What is an automatic press?',
      a: 'A press that opens by itself as soon as a side falls a set number of holes down — usually two. Nobody has to ask, and nobody forgets. The app opens it on the right hole and tracks it separately.',
    },
    {
      q: 'Can four players play a Nassau?',
      a: 'Yes, two ways. As two teams playing four-ball, where the better ball of each pair counts. Or as a round robin where everyone plays their own Nassau against everyone else — that is six matches with three segments each, which is where the app earns its keep.',
    },
    {
      q: 'Does a Nassau work with handicaps?',
      a: 'Yes. Shots are given on the hardest holes by stroke index. Four-ball match play is normally played off 90% of course handicap from the lowest player; singles match play is 100%.',
    },
  ],

  seo: {
    title: 'Nassau Golf Game: Rules, Presses and How to Play',
    description:
      'The Nassau golf bet explained: front nine, back nine and overall, match-play scoring, automatic and manual presses, team and individual Nassau. Free app that scores it live.',
    keywords: [
      'nassau golf game',
      'nassau golf rules',
      'golf nassau betting',
      'how to play nassau',
      'golf press rules',
      'automatic press golf',
      'nassau golf app',
    ],
    ogHeadline: 'Nassau Golf Rules',
  },

  screenshot: '/app/09-nassau.webp',
  screenshotAlt:
    'The Fairway Games Nassau screen showing the front nine, back nine and overall matches running side by side with their current status.',
}
