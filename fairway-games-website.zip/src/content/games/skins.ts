import type { Game } from '../types'

export const skins: Game = {
  slug: 'skins',
  name: 'Skins',
  pageTitle: 'Skins Golf Game Rules',
  tagline: 'Every hole has a prize. Ties make the next one bigger.',
  cardLine: 'Every hole has value. Ties make the next one even bigger.',
  summary:
    'Each hole is a separate prize called a skin. The lowest score on the hole wins it outright — but tie the hole and nobody wins, so the prize rolls forward and the next hole is worth more.',
  players: '2–4 players',
  playersMin: 2,
  playersMax: 4,
  complexity: 'Easy',
  complexityLevel: 1,
  accentVar: '--game-skins',
  explainTime: 'Thirty seconds on the first tee',
  hook: 'Nothing focuses a group like standing on a tee that is worth four holes.',

  sections: [
    {
      title: 'Winning a skin',
      body: [
        'Everyone plays their own ball. The single lowest score on the hole wins the skin.',
        'Two or more players tied for lowest means no winner — even if one of them is having the round of their life.',
        'That one rule is what makes Skins different from stroke play: a 3 is worth nothing if somebody else also makes 3.',
      ],
    },
    {
      title: 'The pot',
      body: [
        'Every hole is worth one skin by default, and one skin is worth whatever your group decides.',
        'Tie a hole and the skin carries: the next hole is now worth two. Tie that one as well and it is worth three.',
        'The running pot is always shown at the top of the hole screen, so everyone knows what is on the table before they hit.',
      ],
    },
    {
      title: 'Progressive skins',
      body: [
        'An optional rule that makes the round build to a finish, whatever happens on the front nine.',
        'Holes 1–6 are worth one skin, 7–12 are worth two, 13–17 are worth three and the 18th is worth five.',
        'Every tier is editable, and individual holes can be given their own value — a five-skin 18th, an island green, whatever your group likes.',
      ],
    },
    {
      title: 'Validation skins',
      body: [
        'Another optional rule, for groups who think one lucky hole should not decide the money.',
        'A skin is only provisional until you tie or better the following hole. Fail to validate and it drops straight back into the pot for everybody.',
        'Off by default, because it surprises people the first time it happens.',
      ],
    },
  ],

  example: {
    title: 'A carry-over',
    intro: 'Three holes, one tie, and the pot doubles.',
    rows: [
      { label: 'Hole 1 — Marc 4, Phil 5, Mike 5, John 6', value: 'Marc wins 1 skin', emphasis: true },
      { label: 'Hole 2 — Marc 4, Phil 4, Mike 5, John 6', value: 'Tied. Nobody wins.' },
      { label: 'Hole 3 is now worth', value: '2 skins', emphasis: true },
      { label: 'Hole 3 — Mike is lowest', value: 'Mike wins 2 skins', emphasis: true },
    ],
    result: 'Marc 1 · Mike 2 · Phil 0 · John 0',
  },

  adjustable: [
    { name: 'Skin value', text: 'What one skin is worth. Every hole starts at this.', isDefault: true },
    { name: 'When a hole is tied', text: 'Carry it forward (the classic), no carry, or split the skin.', isDefault: true },
    { name: 'Progressive skins', text: 'Later holes are automatically worth more, so the round builds.' },
    { name: 'Custom hole values', text: 'Give any individual hole its own value.' },
    { name: 'Validation skins', text: 'A skin is only yours once you tie or win the following hole.' },
    { name: 'If the last hole is tied', text: 'Split the remaining pot, void it, or carry to a play-off.', isDefault: true },
    { name: 'Handicaps', text: 'Net or gross. Skins is usually played off full handicap or off the low player.' },
  ],

  appDoes: [
    'Tracks the carry across every tied hole and shows the pot before you tee off.',
    'Finds the single lowest score and refuses to award a skin when two players tie.',
    'Applies progressive tiers and any custom hole values automatically.',
    'Holds provisional skins when validation is on and settles them a hole later.',
    'Splits or voids the pot correctly when the 18th is tied.',
    'Converts to net scores by stroke index when handicaps are on.',
  ],

  definitions: [
    { term: 'Skin', text: 'The prize attached to a single hole.' },
    { term: 'Carry', text: 'A skin nobody won, added to the next hole.' },
    { term: 'Pot', text: 'Everything on offer on the hole you are about to play.' },
    { term: 'Validation', text: 'The optional rule that a skin must be confirmed on the following hole.' },
  ],

  faq: [
    {
      q: 'What happens when two players tie a hole in Skins?',
      a: 'Nobody wins it. By default the skin carries into the next hole, which is then worth two. You can also set the app to drop the skin entirely, or to split it between the tied players.',
    },
    {
      q: 'How many players can play Skins?',
      a: 'Two to four. It works with any of those, though carries happen more often with more players, which is exactly what makes a four-ball game fun.',
    },
    {
      q: 'What are progressive skins?',
      a: 'A rule that makes later holes worth more automatically — one skin on holes 1–6, two on 7–12, three on 13–17 and five on the 18th by default. It keeps the whole round live even if someone runs away with the front nine.',
    },
    {
      q: 'Do we have to play Skins for money?',
      a: 'No. The app counts points, and an optional point value is there only if your group wants one. Leave it off and Skins is just a scoreboard.',
    },
    {
      q: 'Can we give holes different values?',
      a: 'Yes. Any hole can be given its own skin value before the round — a five-skin 18th, a double-value island green, whatever your group already does.',
    },
  ],

  seo: {
    title: 'Skins Golf Game: Rules, Carry-Overs and Scoring',
    description:
      'The golf skins game explained: how a skin is won, why ties carry over, progressive and validation skins, and how to score it. Free app that tracks the pot for you.',
    keywords: [
      'skins golf game',
      'golf skins rules',
      'how to play skins in golf',
      'golf skins scoring',
      'skins carry over golf',
      'golf skins app',
    ],
    ogHeadline: 'Skins Golf Rules',
  },

  screenshot: '/app/08-skins.webp',
  screenshotAlt:
    'The Fairway Games Skins screen showing the pot for the current hole, carried skins and each player’s score entry.',
}
