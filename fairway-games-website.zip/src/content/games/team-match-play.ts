import type { Game } from '../types'

export const teamMatchPlay: Game = {
  slug: 'team-match-play',
  name: 'Team Match',
  pageTitle: 'Team Match Play Golf Rules',
  tagline: 'Two teams battle hole by hole.',
  cardLine: 'Two teams. One hole at a time.',
  summary:
    'Two teams of two, hole by hole. Win a hole and your team goes one up. The size of the win does not matter — a 4 beating a 9 is worth exactly the same as a 4 beating a 5.',
  alsoKnownAs: ['Four-Ball', 'Foursomes', 'Scramble'],
  players: '4 players',
  playersMin: 4,
  playersMax: 4,
  complexity: 'Easy',
  complexityLevel: 1,
  accentVar: '--game-match',
  explainTime: 'Everybody already knows this one',
  hook: 'The Ryder Cup format, with the scoring nobody at your club can ever quite agree on.',

  sections: [
    {
      title: 'The format',
      body: [
        'Four-Ball is the common one: everyone plays their own ball and the better score of each pair counts.',
        'Foursomes is alternate shot — one ball per team, hit in turn. Fast, and a real test of a partnership.',
        'Scramble: both partners hit, the team plays the better shot, one score per team. Friendly to higher handicaps.',
        'Whichever you choose, each hole is its own contest and the lowest team score wins it.',
      ],
    },
    {
      title: 'Reading the match',
      body: [
        'Level is ALL SQUARE, shown as AS.',
        'One hole ahead is 1 UP. Two ahead is 2 UP, and so on.',
        'Ahead by exactly as many holes as are left is DORMIE — from there the leading team cannot lose.',
        'The match ends the moment one team is up by more holes than remain. Nobody plays the last two holes of a match that is already over.',
      ],
    },
    {
      title: 'How results are written',
      body: [
        '3 & 2 means three holes up with two to play — the match finished on the 16th.',
        '4 & 3 means four up with three to play, finished on the 15th.',
        '1 up means it went all the way to the 18th and was won by a single hole.',
        'Level after 18 is a halved match by default. Switch to sudden death and you play on until a hole is won.',
      ],
    },
    {
      title: 'Concessions',
      body: [
        'A hole can be conceded when it is clearly gone — no need to hole out for a nine.',
        'A whole match can be conceded too. That is normal golf etiquette, not giving up.',
        'The app records a concession as a hole won, so the notation stays correct.',
      ],
    },
  ],

  example: {
    title: 'Hole 8 · Four-Ball',
    intro: 'Phil takes six, which does not matter at all. Marc’s four is the team’s score.',
    rows: [
      { label: 'Marc', value: '4', emphasis: true, side: 'a' },
      { label: 'Phil', value: '6', side: 'a' },
      { label: 'Team Green counts', value: '4', emphasis: true, side: 'a' },
      { label: 'Mike', value: '5', side: 'b' },
      { label: 'John', value: '5', side: 'b' },
      { label: 'Team Sand counts', value: '5', emphasis: true, side: 'b' },
    ],
    result: 'Team Green win the hole · 1 UP',
  },

  adjustable: [
    { name: 'Format', text: 'Four-Ball, Foursomes or Scramble.', isDefault: true },
    { name: 'Teams', text: 'Same all round, or rotate every six holes so everyone partners everyone.', isDefault: true },
    { name: 'A halved hole', text: 'Halved as standard, or carried so the next hole is worth two.', isDefault: true },
    { name: 'Concessions', text: 'Allow a hole or the whole match to be given to the other side.', isDefault: true },
    { name: 'Level after 18', text: 'A halved match, or sudden death until a hole is won.', isDefault: true },
    { name: 'Points for the win', text: 'What each player on the winning team gets.', isDefault: true },
    { name: 'Points per hole won', text: 'Optional. Some groups also pay for each hole on top of the match.' },
    { name: 'Handicaps', text: 'Shots given on the hardest holes by stroke index, off the low player.' },
  ],

  appDoes: [
    'Compares the two team scores and moves the match on, hole by hole.',
    'Writes the status in correct notation — AS, 2 UP, dormie — and says who is up.',
    'Closes the match the instant it is mathematically decided, and writes the result as 4 & 3.',
    'Rotates the pairings every six holes when rotation is on.',
    'Carries halved holes forward when that rule is switched on.',
    'Runs sudden-death extra holes and keeps the numbering right.',
  ],

  definitions: [
    { term: 'AS', text: 'All square. The match is level.' },
    { term: 'Dormie', text: 'Up by exactly the number of holes left.' },
    { term: '4 & 3', text: 'Four up with three to play. The match is over.' },
    { term: 'Halved', text: 'A tied hole, or a tied match.' },
    { term: 'Concede', text: 'Giving a hole, a putt or the match to the opposition.' },
    { term: 'Four-Ball', text: 'Both partners play their own ball; the better score counts.' },
  ],

  faq: [
    {
      q: 'What is team match play in golf?',
      a: 'Two teams of two playing hole by hole rather than counting total strokes. Win a hole and you go one up. How much you win it by makes no difference.',
    },
    {
      q: 'What is the difference between four-ball and foursomes?',
      a: 'In four-ball everyone plays their own ball and the better score of each pair counts. In foursomes the pair shares one ball and alternates shots. The app supports both, plus scramble.',
    },
    {
      q: 'What does 4 & 3 mean?',
      a: 'Four holes up with three to play. The trailing team cannot catch up, so the match ends on the 15th green. The app writes results this way automatically.',
    },
    {
      q: 'What does dormie mean?',
      a: 'A team is dormie when it is ahead by exactly the number of holes remaining. From there it cannot lose the match — the worst outcome is a half.',
    },
    {
      q: 'Can we play 2v2 match play with handicaps?',
      a: 'Yes. Turn handicaps on and shots are given on the hardest holes by stroke index, off the lowest handicap in the group. The app shows exactly what each player will receive before anyone tees off.',
    },
  ],

  seo: {
    title: 'Team Match Play Golf: Four-Ball Rules and Scoring',
    description:
      '2v2 golf match play explained: four-ball, foursomes and scramble, all square, dormie, 4 & 3 and concessions. Free app that tracks the match and writes the result for you.',
    keywords: [
      'team match play golf',
      'four-ball match play',
      '2v2 golf match play',
      'golf match play rules',
      'what does dormie mean golf',
      'four ball golf app',
    ],
    ogHeadline: 'Team Match Play Rules',
  },

  screenshot: '/app/12-team-match.webp',
  screenshotAlt:
    'The Fairway Games Team Match screen showing Team Green against Team Sand with the match status and holes won.',
}
