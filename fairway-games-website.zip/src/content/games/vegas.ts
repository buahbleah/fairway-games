import type { Game } from '../types'

export const vegas: Game = {
  slug: 'vegas',
  name: 'Vegas',
  pageTitle: 'Vegas Golf Made Simple',
  tagline: 'Team scores combine into numbers, creating big swings and dramatic holes.',
  cardLine: 'Turn team scores into numbers and watch the points swing.',
  summary:
    'Four players, two pairs. Each pair’s two scores are put side by side to make one number, lowest first. The pair with the lower number wins the difference in points.',
  players: '4 players',
  playersMin: 4,
  playersMax: 4,
  complexity: 'Medium',
  complexityLevel: 3,
  accentVar: '--game-vegas',
  explainTime: 'One number and everyone gets it',
  hook: 'A 4 and a 5 make 45, not 9. That one sentence is the entire game — and the reason it swings so hard.',

  sections: [
    {
      title: 'The number is not a total',
      body: [
        'A 4 and a 5 make 45. Not 9. The two scores are written next to each other, not added up.',
        'The lower score always goes first: a 3 and a 6 make 36, never 63.',
        'One bad hole from one partner turns a 45 into a 49 — and against a 36 that is thirteen points instead of nine. This is why Vegas swings harder than any other game in the app.',
      ],
    },
    {
      title: 'Scoring the hole',
      body: [
        'Take the difference between the two team numbers.',
        'Each point of difference is worth the point multiplier, which is one by default.',
        'The winning pair gains that amount and the losing pair loses it, so the table always balances to zero.',
        'A cap can be set so no single hole costs more than a fixed amount. Off by default — a disaster hole costs the full amount unless you say otherwise.',
      ],
    },
    {
      title: 'Flipping',
      body: [
        'Flipping reverses the other team’s number so the higher score reads first: 56 becomes 65.',
        'The usual trigger is a birdie. Some groups only allow a natural birdie — one made without a handicap shot. Others reserve it for an eagle.',
        'Flipping exists because a good score deserves to hurt the other side. It is optional and every group plays it differently, which is exactly why the app makes it a setting rather than a rule.',
      ],
    },
    {
      title: 'Rotating partners',
      body: [
        'Teams can stay fixed for the round, or change every six holes so everyone partners everyone.',
        'Holes 1–6, 7–12 and 13–18 each get a different pairing — a Vegas and Sixes hybrid.',
        'The app works out the three pairings and switches them at the right hole.',
      ],
    },
  ],

  example: {
    title: 'Hole 7',
    intro: 'Marc and Phil against Mike and John. Mike makes a 3 and the hole is gone.',
    rows: [
      { label: 'Marc', value: '4', side: 'a' },
      { label: 'Phil', value: '5', side: 'a' },
      { label: 'Team A number', value: '45', emphasis: true, side: 'a' },
      { label: 'Mike', value: '3', side: 'b' },
      { label: 'John', value: '6', side: 'b' },
      { label: 'Team B number', value: '36', emphasis: true, side: 'b' },
      { label: 'Difference', value: '9', emphasis: true },
    ],
    result: 'Mike and John win 9 points',
  },

  adjustable: [
    { name: 'Point multiplier', text: 'Every point of difference is worth this much. Default 1×.', isDefault: true },
    { name: 'Flip rule', text: 'No flipping, birdie flips, natural birdie only, or eagle flips.', isDefault: true },
    { name: 'Cap on one hole', text: 'Limit the damage of one catastrophic hole. Off by default.' },
    { name: 'Birdie bonus', text: 'Flat extra points on top of the difference for each birdie.' },
    { name: 'Eagle bonus', text: 'The same, for an eagle.' },
    { name: 'Teams', text: 'Fixed for the round, or change every six holes so everyone partners everyone.', isDefault: true },
    { name: 'Handicaps', text: '90% off the low player keeps it fair without killing the swings.' },
  ],

  appDoes: [
    'Builds the two-digit number for each team, lowest digit first, every hole.',
    'Applies the flip when a birdie or eagle triggers it — including natural-birdie-only, which needs the handicap shots to be known.',
    'Takes the difference and applies the multiplier and any cap.',
    'Adds birdie and eagle bonuses on top.',
    'Rotates the pairings at holes 7 and 13 when rotation is on.',
    'Keeps the running total balanced so the table always adds to zero.',
  ],

  definitions: [
    { term: 'Team number', text: 'The two partners’ scores written side by side, lowest first.' },
    { term: 'Flip', text: 'Reversing the other team’s number so the higher score reads first.' },
    { term: 'The difference', text: 'What the hole is worth. 45 against 36 is nine points.' },
    { term: 'Natural birdie', text: 'A birdie made without a handicap shot on that hole.' },
  ],

  faq: [
    {
      q: 'How does Vegas golf scoring work?',
      a: 'Each pair’s two scores are placed side by side, lowest first, to make one number. A 4 and a 5 make 45. The team with the lower number wins the difference between the two numbers in points.',
    },
    {
      q: 'Why is a 4 and a 5 worth 45 and not 9?',
      a: 'Because Vegas is about the gap between two numbers, not the sum of two scores. Writing them side by side means a single bad score moves the number by ten rather than by one — which is where all the drama comes from.',
    },
    {
      q: 'What does flipping mean in Vegas golf?',
      a: 'A flip reverses the other team’s number so the higher score reads first — 56 becomes 65. A birdie is the usual trigger. It is optional, and the app supports birdie, natural birdie only, or eagle.',
    },
    {
      q: 'Can you cap the damage on one hole?',
      a: 'Yes. Turn the cap on and set a maximum, and no hole can cost more than that. It is off by default because the risk is the point, but a blow-up hole in a big-multiplier game is why the setting exists.',
    },
    {
      q: 'Do you need exactly four players for Vegas?',
      a: 'Yes. Vegas is two pairs by definition. With three players, Wolf or Skins is the better game.',
    },
  ],

  seo: {
    title: 'Vegas Golf Game: Rules, Scoring and Flips Explained',
    description:
      'How Vegas golf scoring works: two scores become one number, the difference is the damage. Flips, caps, multipliers and rotating partners explained, with a free app that does the maths.',
    keywords: [
      'vegas golf game',
      'vegas golf rules',
      'golf vegas scoring',
      'how to play vegas golf',
      'vegas golf flip rule',
      'vegas golf app',
    ],
    ogHeadline: 'Vegas Golf Rules',
  },

  screenshot: '/app/10-vegas.webp',
  screenshotAlt:
    'The Fairway Games Vegas screen showing both team numbers built from the four scores, with the difference and the points at stake.',
}
