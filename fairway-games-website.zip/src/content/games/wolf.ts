import type { Game } from '../types'

export const wolf: Game = {
  slug: 'wolf',
  name: 'Wolf',
  pageTitle: 'Wolf Golf Game Rules',
  tagline: 'Choose a teammate or go alone. The app tracks everything.',
  cardLine: 'Choose a partner after the tee shots — or take everyone on as the Lone Wolf.',
  summary:
    'Every hole one player is the Wolf. After watching the others drive, the Wolf either picks a partner for that hole — or plays alone against everybody for a bigger prize.',
  players: '3–4 players',
  playersMin: 3,
  playersMax: 4,
  complexity: 'Medium',
  complexityLevel: 3,
  accentVar: '--game-wolf',
  explainTime: 'Two minutes on the first tee',
  hook: 'The best hole in golf is the one where somebody says “I’ve got this” and means it.',

  sections: [
    {
      title: 'How a hole runs',
      body: [
        'The Wolf tees off first, then each other player drives in turn.',
        'Straight after a player’s drive the Wolf must either take them as partner, or pass and watch the next player. Pass on someone and they are gone for that hole — you cannot come back to them.',
        'Pass on everybody and the Wolf plays the hole alone. That is the Lone Wolf.',
        'Each side plays best ball: only the lower score on the team counts.',
      ],
    },
    {
      title: 'The points',
      body: [
        'Wolf and partner win the hole: 2 points each.',
        'The other pair — the Hunters — win: 3 points each.',
        'Lone Wolf wins: 3 points.',
        'Lone Wolf loses: 2 points to each opponent.',
        'The asymmetry is the whole game. Taking a partner is safe and pays less; going alone pays more and usually costs you.',
      ],
    },
    {
      title: 'Blind Wolf',
      body: [
        'Before anyone hits — including the Wolf — the Wolf can declare blind, going alone without seeing a single drive.',
        'Lone Wolf points are multiplied when the Wolf goes blind. The app ships with 2×, and the multiplier is adjustable up to 5×.',
        'Some groups call this the Pig. Same idea, different animal.',
      ],
    },
    {
      title: 'Rotation',
      body: [
        'The Wolf passes to the next player each hole so everyone is Wolf the same number of times.',
        'Eighteen holes does not divide evenly by four players, so holes 17 and 18 need a rule. The app gives you three: carry the rotation on, give the Wolf to whoever is last, or make the leader defend.',
        'With three players the rotation divides cleanly and this never comes up.',
      ],
    },
  ],

  example: {
    title: 'Hole 4 · Marc is the Wolf and takes Phil',
    intro: 'Marc drives first, likes what Phil does off the tee, and takes him before Mike hits.',
    rows: [
      { label: 'Marc', value: '4', side: 'a' },
      { label: 'Phil', value: '5', side: 'a' },
      { label: 'Wolf team best ball', value: '4', emphasis: true, side: 'a' },
      { label: 'Mike', value: '5', side: 'b' },
      { label: 'John', value: '6', side: 'b' },
      { label: 'Hunters best ball', value: '5', emphasis: true, side: 'b' },
    ],
    result: 'Marc and Phil win the hole · +2 each',
  },

  adjustable: [
    { name: 'Wolf + partner win', text: 'Points to the Wolf and their partner. Default 2.', isDefault: true },
    { name: 'Hunters win', text: 'Points to each opponent when the Wolf’s team loses. Default 3.', isDefault: true },
    { name: 'Lone Wolf wins', text: 'Points for beating the whole field alone. Default 3.', isDefault: true },
    { name: 'Lone Wolf loses', text: 'Points to each opponent when a Lone Wolf is beaten. Default 2.', isDefault: true },
    { name: 'Blind Wolf', text: 'Declare alone before any drive. On by default, with a 2× multiplier.', isDefault: true },
    { name: 'When the hole is tied', text: 'No points, carry over, ties to the field, or ties to the Wolf.' },
    { name: 'Maximum carry', text: 'Stops the pot running away on a long string of tied holes.' },
    { name: 'Wolf rotation', text: 'Tee order, or an order you set yourself in Round Setup.' },
    { name: 'Left-over holes', text: 'Who is Wolf on 17 and 18 when four players do not divide into 18.' },
    { name: 'Handicaps', text: 'Net or gross, with an allowance off the low player. 100% is the usual for Wolf.' },
  ],

  appDoes: [
    'Works out whose turn it is to be Wolf, hole by hole, including the left-over holes.',
    'Compares best ball against best ball once the four scores are in.',
    'Applies the right points to the right players — the split is different for every outcome.',
    'Handles carries when a hole is tied and the pot rolls forward.',
    'Applies the blind multiplier without anyone having to remember it was declared.',
    'Gives shots on the correct holes by stroke index when handicaps are switched on.',
  ],

  definitions: [
    { term: 'Wolf', text: 'The player choosing a partner on that hole. Tees off first.' },
    { term: 'Hunters', text: 'The players not on the Wolf’s team.' },
    { term: 'Lone Wolf', text: 'The Wolf plays the hole alone against everyone else.' },
    { term: 'Blind Wolf', text: 'Going alone before seeing any drive, for higher stakes.' },
    { term: 'Pig', text: 'Another name for the Lone Wolf, used by some groups.' },
  ],

  faq: [
    {
      q: 'How many players do you need for Wolf?',
      a: 'Four is the classic game, and three works perfectly well — the Wolf simply has one fewer partner to choose from. The app supports both.',
    },
    {
      q: 'When exactly does the Wolf have to choose?',
      a: 'Immediately after each drive, before the next player hits. Once you pass on someone you cannot go back to them. That is what makes the last player a gamble: you have to decide about the first three before you see what they can do.',
    },
    {
      q: 'Can we change the Wolf scoring?',
      a: 'Yes. All four point values are editable before the round, and you can save your group’s numbers as a preset so Saturday’s game is set up in one tap.',
    },
    {
      q: 'What happens when the hole is tied?',
      a: 'Your choice. The app offers four options: nothing happens, the points carry into the next hole, the tie goes to the field so the Wolf must win outright, or the tie goes to the Wolf’s team.',
    },
    {
      q: 'Who is the Wolf on holes 17 and 18?',
      a: 'With four players the rotation does not divide evenly into 18 holes. You can carry the rotation on, hand the Wolf to whoever is last — a real chance to catch up — or make the leader defend.',
    },
    {
      q: 'Does Wolf work with handicaps?',
      a: 'Yes. Switch handicaps on and shots are given on the hardest holes by stroke index, off the lowest handicap in the group. Wolf is a match format, so 100% allowance is the usual setting.',
    },
  ],

  seo: {
    title: 'Wolf Golf Game: Rules, Scoring and How to Play',
    description:
      'How to play the Wolf golf game: rotation, partner selection, Lone Wolf and Blind Wolf, plus the points for every outcome. Free app that scores Wolf for you as you play.',
    keywords: [
      'wolf golf game',
      'wolf golf rules',
      'how to play wolf golf',
      'wolf golf scoring',
      'lone wolf golf',
      'blind wolf golf',
      'wolf golf app',
    ],
    ogHeadline: 'How to Play Wolf Golf',
  },

  screenshot: '/app/05-wolf-pick.webp',
  screenshotAlt:
    'The Fairway Games Wolf screen on hole 1: Marc is the Wolf, with Partner buttons next to Phil, Mike and John, and options for Lone Wolf and Blind Wolf at double points.',
}
