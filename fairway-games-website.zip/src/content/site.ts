/**
 * Site-wide content: features, the four-step flow, the general FAQ and the
 * navigation. Kept as data so a copy change never means touching a component.
 */

import { webAppUrl } from '@config'
import { games } from './games'

/* ------------------------------------------------------------------ features */

export interface Feature {
  title: string
  body: string
  /** Icon key resolved in FeatureCard. */
  icon:
    | 'settings'
    | 'leaderboard'
    | 'offline'
    | 'players'
    | 'bookmark'
    | 'history'
    | 'undo'
    | 'handicap'
    | 'info'
    | 'trophy'
    | 'moon'
    | 'money'
}

export const features: Feature[] = [
  {
    title: 'Custom rules',
    body: 'Every golf group plays things slightly differently. Adjust the points, the carries, the flips and the caps before the round — then never argue about them again.',
    icon: 'settings',
  },
  {
    title: 'Live leaderboards',
    body: 'Always know who is winning, and by how much. Movement is shown as well as position, so ▲2 next to a name tells the story a rank number cannot.',
    icon: 'leaderboard',
  },
  {
    title: 'Offline first',
    body: 'Golf courses have dead spots. The whole round lives on your phone, so scores entered with no signal are never lost and go up the moment it comes back.',
    icon: 'offline',
  },
  {
    title: 'Saved players',
    body: 'Your regular group is ready in seconds. Add friends by email and start a league that keeps every round you have ever played in one place.',
    icon: 'players',
  },
  {
    title: 'Saved presets',
    body: 'Save your Saturday Wolf rules once. Next week the whole setup is one tap, with the same points, the same carries and the same house rules.',
    icon: 'bookmark',
  },
  {
    title: 'Hole history',
    body: 'See exactly what happened on every hole — who won it, what it was worth, and how the standings moved. Nothing is a mystery at the 19th.',
    icon: 'history',
  },
  {
    title: 'Undo and edit',
    body: 'Fix a mistake in one tap. Undo is always one press from the hole screen and tells you what it will undo. Any earlier hole can be edited and everything recalculates.',
    icon: 'undo',
  },
  {
    title: 'Handicaps',
    body: 'One switch turns any game into a fair contest. Shots are given on the hardest holes by stroke index, and the app shows what each player receives before anyone tees off.',
    icon: 'handicap',
  },
  {
    title: 'Game explanations',
    body: 'Nobody has to know the rules. Every game has a rules screen written for someone who has never played it — with a worked example using the settings your group actually chose.',
    icon: 'info',
  },
  {
    title: 'Final results',
    body: 'The winner, the standings and the round’s story on one screen the moment the 18th is in. Share it as a designed card or as plain text.',
    icon: 'trophy',
  },
  {
    title: 'Dark and sunlight modes',
    body: 'A dark composition built for early tee times and the clubhouse, and a high-contrast sunlight mode for when you cannot see the screen at all.',
    icon: 'moon',
  },
  {
    title: 'Points, not money',
    body: 'The app counts points. An optional point value is there if your group wants one, but there is no money anywhere in the product and no gambling of any kind.',
    icon: 'money',
  },
]

/* ------------------------------------------------------------ how it works */

export interface Step {
  n: number
  title: string
  body: string
  screenshot: string
  alt: string
}

export const steps: Step[] = [
  {
    n: 1,
    title: 'Pick a game',
    body: 'Wolf, Skins, Nassau, Vegas, Dots or Team Match. Tap the one your group wants — and if somebody does not know it, the rules screen explains it in two minutes.',
    screenshot: '/app/02-game-select.webp',
    alt: 'The game selection screen showing all six games as cards with their own marks.',
  },
  {
    n: 2,
    title: 'Add your group',
    body: 'Three or four players, picked from your saved list. Set the course, and even it up with handicaps if you want to — the app shows what everyone plays off before anyone tees off.',
    screenshot: '/app/04-setup-players.webp',
    alt: 'The round setup screen with players being selected for the round.',
  },
  {
    n: 3,
    title: 'Play golf',
    body: 'Enter scores as you go. One decision on screen at a time, buttons big enough for a gloved thumb, and the whole thing takes a few seconds between two shots.',
    screenshot: '/app/06-wolf-scores.webp',
    alt: 'The score entry screen with large plus and minus steppers for each player.',
  },
  {
    n: 4,
    title: 'Let the app do the maths',
    body: 'Points, teams, carries, presses and standings update themselves. You put the phone away and go and hit your next shot.',
    screenshot: '/app/13-leaderboard.webp',
    alt: 'The live leaderboard showing each player’s points and their movement up or down.',
  },
]

/* -------------------------------------------------------------------- FAQ */

export interface FaqEntry {
  q: string
  a: string
}

export const generalFaq: FaqEntry[] = [
  {
    q: 'Does the app work offline?',
    a: 'Yes, and it is built for it rather than hoping for it. The round, your players, your presets and your preferences all live on the phone. Once the app has been opened while online it works in aeroplane mode, and scores entered with no signal go up the moment coverage comes back.',
  },
  {
    q: 'How many players can play?',
    a: 'Between two and four depending on the game. Skins, Dots and Nassau run from two players; Wolf needs three or four; Vegas and Team Match need exactly four. The app tells you before you start.',
  },
  {
    q: 'Can we change the Wolf scoring?',
    a: 'Yes. All four Wolf point values are editable, along with the blind multiplier, what happens on a tied hole and who is Wolf on the left-over holes. Save it as a preset and next Saturday is one tap.',
  },
  {
    q: 'Can we play without money?',
    a: 'That is the default. The app counts points and nothing else. An optional point value exists if your group settles up afterwards, but there is no money inside the app, no payments and no gambling.',
  },
  {
    q: 'Does the app calculate handicaps?',
    a: 'Yes. Turn handicaps on and shots are given on the hardest holes by stroke index, off the lowest handicap in the group. Round setup shows exactly what each player will play off before anyone tees off, and each game uses the allowance that suits it — 100% for match formats, 90% for four-ball.',
  },
  {
    q: 'Does it support 9-hole rounds?',
    a: 'Yes. Set the course to nine holes and every game adapts — Nassau becomes a single match rather than three, and the games that use tiers scale with it.',
  },
  {
    q: 'Can I edit a previous hole?',
    a: 'Any hole, at any time. The round is stored as a list of hole entries and everything else is worked out from them, so correcting the 4th at the 12th tee recalculates the standings, the carries and the match status instantly.',
  },
  {
    q: 'What happens if we close the app?',
    a: 'Nothing is lost. Close it, lock the phone, take a call, reopen it three holes later — the round is exactly where you left it, including the undo history.',
  },
  {
    q: 'Can we save regular playing partners?',
    a: 'Yes. Saved players make setup a few seconds. Sign in and you can also add friends by email, start a league with a join code, and keep every round your group has played in one place.',
  },
  {
    q: 'Can everyone score from their own phone?',
    a: 'Yes, if you sign in. Invite the group to a round and everyone enters scores from their own phone, with the card filling in on every screen. Scores are merged player by player, so a phone that was offline for twenty minutes never wipes out what somebody else entered.',
  },
  {
    q: 'Which games are supported?',
    a: `Six: ${games.map((g) => g.name).join(', ')}. Each has its own rules screen, its own settings and its own worked example.`,
  },
  {
    q: 'Are more games coming?',
    a: 'Yes. The app is built so a new game is a self-contained module rather than a rewrite, and a shortlist of the next formats is already drawn up. Bingo Bango Bongo and Sixes are top of it.',
  },
  {
    q: 'How do I get it on my phone?',
    a: 'On Android, the app is on Google Play’s internal test track — the link on the download page installs it once your Google account has been added as a tester. On iPhone there is no store build yet, but the whole app runs in Safari: open it, then Share → Add to Home Screen, and it installs with the app icon, runs full screen and works offline.',
  },
  {
    q: 'Do I need an account?',
    a: 'No. A solo round needs no account and no connection at all. Signing in only adds the things that need other people: friends, leagues and live shared scoring.',
  },
  {
    q: 'Is there advertising or tracking?',
    a: 'No adverts, no third-party tracking, no analytics inside the app. You can delete your account and everything with it from inside Settings whenever you like.',
  },
]

/* ------------------------------------------------------------- navigation */

export const primaryNav = [
  { href: '/games', label: 'Games' },
  { href: '/features', label: 'Features' },
  { href: '/how-it-works', label: 'How It Works' },
  { href: '/faq', label: 'FAQ' },
]

export const footerNav = {
  play: games.map((g) => ({ href: `/games/${g.slug}`, label: g.name })),
  product: [
    { href: '/features', label: 'Features' },
    { href: webAppUrl, label: 'Play in the browser' },
    { href: '/how-it-works', label: 'How It Works' },
    { href: '/download', label: 'Download' },
    { href: '/faq', label: 'FAQ' },
    { href: '/about', label: 'About' },
  ],
  legal: [
    { href: '/privacy', label: 'Privacy' },
    { href: '/terms', label: 'Terms' },
  ],
}
