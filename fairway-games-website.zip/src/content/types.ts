/**
 * CONTENT MODEL
 *
 * Every game page on this site is rendered from one of these objects. Adding a
 * seventh game — Bingo Bango Bongo, Sixes, Quota — means adding one file to
 * src/content/games/ and one line to the index. No page or route changes.
 *
 * The shape deliberately mirrors the app's RulesDoc (src/core/types.ts) so the
 * rules a golfer reads on the website are the rules the app will show them.
 */

import type { GameMarkKey } from '@/components/Icons'

export type Complexity = 'Easy' | 'Medium'

/** A single row in a worked scoring example. */
export interface ExampleRow {
  label: string
  value: string
  /** Emphasised rows carry the numbers that decide the hole. */
  emphasis?: boolean
  /** Optional side, used to colour team examples green vs sand. */
  side?: 'a' | 'b'
}

export interface WorkedExample {
  title: string
  /** One line of setup, shown above the rows. */
  intro?: string
  rows: ExampleRow[]
  result: string
}

export interface RulesSection {
  title: string
  body: string[]
}

/** An option the golfer can change in the app before the round starts. */
export interface AdjustableRule {
  name: string
  text: string
  /** What the app ships with, so the page can show "default" vs "optional". */
  isDefault?: boolean
}

export interface Definition {
  term: string
  text: string
}

export interface FaqItem {
  q: string
  a: string
}

export interface GameSeo {
  title: string
  description: string
  /** Informational search terms this page is written to answer. */
  keywords: string[]
  /** Short line used on the OpenGraph card. */
  ogHeadline: string
}

export interface Game {
  slug: GameMarkKey
  /** Display name, matching the app exactly. */
  name: string
  /** H1 on the game page — written for search, not for the app's home screen. */
  pageTitle: string
  tagline: string
  /** One line for the game card on the homepage. */
  cardLine: string
  /** The app's own summary of the game. */
  summary: string
  /** Other names golfers use for the same game. */
  alsoKnownAs?: string[]
  players: string
  playersMin: number
  playersMax: number
  complexity: Complexity
  /** 1–3, used for the three-pip complexity meter. */
  complexityLevel: 1 | 2 | 3
  /** CSS token name for this game's accent, e.g. '--game-wolf'. */
  accentVar: string
  /** How long it takes to explain on the first tee. */
  explainTime: string
  /** The single sentence that makes someone want to play it. */
  hook: string
  sections: RulesSection[]
  example: WorkedExample
  adjustable: AdjustableRule[]
  /** What the app computes so nobody has to. */
  appDoes: string[]
  definitions: Definition[]
  faq: FaqItem[]
  seo: GameSeo
  /** Screenshot in public/app used for this game's phone mockup. */
  screenshot: string
  screenshotAlt: string
}
