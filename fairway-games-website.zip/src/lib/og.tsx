import { ImageResponse } from 'next/og'
import { siteConfig } from '@config'

/**
 * THE OPENGRAPH TEMPLATE
 *
 * One reusable composition for every social card: a deep fairway-green field,
 * the crest, an eyebrow, the headline, and a sand rule. Rendered at request
 * time by Next's Satori-based renderer, cached at the edge.
 *
 * Satori supports a subset of CSS — flexbox only, no grid, no CSS variables —
 * so the palette is repeated here as literals. They are the same values as
 * tokens.css; if the brand green ever changes, it changes in both places.
 */

export const OG_SIZE = { width: 1200, height: 630 }
export const OG_CONTENT_TYPE = 'image/png'

const GREEN_800 = '#0e2b21'
const GREEN_950 = '#071410'
const SAND_400 = '#d9b472'
const SAND_300 = '#e7cd9c'
const CREAM = '#f4f1e8'

interface OgInput {
  /** Small tracked label above the headline. */
  eyebrow?: string
  /** The headline. Keep it under about 40 characters. */
  headline: string
  /** One supporting line under the rule. */
  sub?: string
  /** Accent colour for the rule and eyebrow — a per-game accent, or sand. */
  accent?: string
}

export function ogImage({ eyebrow, headline, sub, accent = SAND_400 }: OgInput) {
  const host = siteConfig.url.replace(/^https?:\/\//, '').replace(/\/$/, '')

  return new ImageResponse(
    (
      <div
        style={{
          width: '100%',
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'space-between',
          // A floor on the gap, so a two-line headline never lets the sub and
          // the footer touch.
          gap: 26,
          background: `linear-gradient(135deg, ${GREEN_800} 0%, ${GREEN_950} 100%)`,
          padding: '68px 76px',
          position: 'relative',
        }}
      >
        {/* contour geometry, the same motif as the site heroes */}
        <svg
          width="1200"
          height="630"
          viewBox="0 0 1200 630"
          style={{ position: 'absolute', top: 0, left: 0, opacity: 0.13 }}
        >
          <g fill="none" stroke={SAND_300} strokeWidth="2.5">
            <path d="M-60 470c180-130 354-148 528-68s336 46 504-86" />
            <path d="M-60 534c186-142 372-164 558-80s354 40 522-102" />
            <path d="M-60 408c168-118 324-130 480-62s318 34 480-80" />
            <path d="M-60 346c150-102 288-114 426-52s288 24 444-68" />
            <path d="M-60 288c132-86 252-98 372-42s258 12 402-58" />
          </g>
        </svg>

        {/* The dawn-light motif, drawn as concentric SVG rings rather than a
            radial-gradient: Satori renders radial gradients as a hard disc. */}
        <svg
          width="700"
          height="700"
          viewBox="0 0 700 700"
          style={{ position: 'absolute', top: -230, right: -180 }}
        >
          {[330, 268, 206, 144].map((r, i) => (
            <circle
              key={r}
              cx="350"
              cy="350"
              r={r}
              fill="none"
              stroke={SAND_400}
              strokeOpacity={0.05 + i * 0.025}
              strokeWidth={i === 0 ? 2 : 1.5}
            />
          ))}
        </svg>

        {/* header: crest + wordmark */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 18 }}>
          <svg width="58" height="58" viewBox="122 56 268 268">
            <circle cx="256" cy="190" r="130" fill={SAND_400} />
            <circle cx="256" cy="190" r="119" fill="#0a3320" />
            <circle cx="256" cy="190" r="116" fill="#e4f2e2" />
            <path d="M140 206h232v100H140Z" fill="#2a7a44" />
            <path
              d="M140 306C146 272 186 250 236 240C272 233 292 224 300 208L324 214C316 244 288 258 248 268C214 276 200 290 198 306Z"
              fill="#7ec867"
            />
            <path
              d="M256 96 265 126 295 134 265 142 256 172 247 142 217 134 247 126Z"
              fill="#2a6f8e"
            />
            <ellipse cx="238" cy="222" rx="34" ry="14" fill="#8ed36f" />
            <path d="M241 222v-46h6v46z" fill="#f7f5ec" />
            <path d="M247 178 277 187 247 197Z" fill="#d94f3d" />
            <circle cx="256" cy="190" r="116" fill="none" stroke={SAND_400} strokeWidth="5" />
          </svg>
          <div
            style={{
              display: 'flex',
              fontSize: 27,
              letterSpacing: 5,
              color: CREAM,
              fontWeight: 700,
            }}
          >
            FAIRWAY GAMES
          </div>
        </div>

        {/* body */}
        <div style={{ display: 'flex', flexDirection: 'column' }}>
          {eyebrow && (
            <div
              style={{
                display: 'flex',
                fontSize: 22,
                letterSpacing: 6,
                color: accent,
                fontWeight: 700,
                marginBottom: 22,
              }}
            >
              {eyebrow.toUpperCase()}
            </div>
          )}

          <div
            style={{
              display: 'flex',
              fontSize: headline.length > 30 ? 78 : 94,
              lineHeight: 1.02,
              color: CREAM,
              fontWeight: 700,
              letterSpacing: -1.5,
              maxWidth: 920,
            }}
          >
            {headline}
          </div>

          <div style={{ display: 'flex', width: 148, height: 6, background: accent, marginTop: 34 }} />

          {sub && (
            <div
              style={{
                display: 'flex',
                fontSize: 31,
                color: 'rgba(244,241,232,0.72)',
                marginTop: 26,
                maxWidth: 880,
              }}
            >
              {sub}
            </div>
          )}
        </div>

        {/* footer */}
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'flex-end',
            fontSize: 23,
            color: 'rgba(244,241,232,0.55)',
          }}
        >
          <div style={{ display: 'flex' }}>Wolf · Skins · Nassau · Vegas · Dots · Match Play</div>
          {/* The domain, not a second tagline — on the home card the tagline is
              already the headline, and a card should say where it comes from. */}
          <div style={{ display: 'flex', color: accent }}>{host}</div>
        </div>
      </div>
    ),
    OG_SIZE,
  )
}
