import type { Metadata } from 'next'
import { siteConfig } from '@config'

/**
 * One place that builds page metadata, so every page gets a canonical, an
 * OpenGraph card and Twitter tags without any of them being hand-written.
 */

interface PageMetaInput {
  title: string
  description: string
  /** Path with a leading slash, e.g. '/games/wolf'. */
  path: string
  /** Overrides the default OG image route. */
  ogImage?: string
  keywords?: readonly string[]
  type?: 'website' | 'article'
}

export function pageMetadata({
  title,
  description,
  path,
  ogImage,
  keywords,
  type = 'website',
}: PageMetaInput): Metadata {
  const url = `${siteConfig.url}${path === '/' ? '' : path}`
  const image = ogImage ?? `${path === '/' ? '' : path}/opengraph-image`

  return {
    title,
    description,
    keywords: keywords ? [...keywords] : undefined,
    alternates: { canonical: url },
    openGraph: {
      type,
      url,
      siteName: siteConfig.name,
      title,
      description,
      images: [{ url: image, width: 1200, height: 630, alt: title }],
      locale: 'en',
    },
    twitter: {
      card: 'summary_large_image',
      title,
      description,
      images: [image],
    },
  }
}

/* ------------------------------------------------------------ structured data */

export function organizationSchema() {
  return {
    '@type': 'Organization',
    '@id': `${siteConfig.url}/#organization`,
    name: siteConfig.name,
    url: siteConfig.url,
    logo: `${siteConfig.url}/brand/app-icon-512.png`,
    email: siteConfig.contact.email,
  }
}

export function websiteSchema() {
  return {
    '@type': 'WebSite',
    '@id': `${siteConfig.url}/#website`,
    url: siteConfig.url,
    name: siteConfig.name,
    description: siteConfig.description,
    inLanguage: 'en',
    publisher: { '@id': `${siteConfig.url}/#organization` },
  }
}

/**
 * SoftwareApplication / MobileApplication for the app itself.
 *
 * Deliberately conservative: no aggregateRating and no review, because we have
 * no ratings yet and inventing them is both dishonest and a manual action
 * waiting to happen.
 */
export function appSchema() {
  return {
    '@type': ['SoftwareApplication', 'MobileApplication'],
    '@id': `${siteConfig.url}/#app`,
    name: siteConfig.name,
    description: siteConfig.description,
    applicationCategory: 'SportsApplication',
    operatingSystem: 'Android, iOS',
    url: `${siteConfig.url}/download`,
    image: `${siteConfig.url}/brand/app-icon-512.png`,
    offers: {
      '@type': 'Offer',
      price: '0',
      priceCurrency: 'CHF',
    },
    publisher: { '@id': `${siteConfig.url}/#organization` },
  }
}

export function faqSchema(items: readonly { q: string; a: string }[]) {
  return {
    '@type': 'FAQPage',
    mainEntity: items.map((item) => ({
      '@type': 'Question',
      name: item.q,
      acceptedAnswer: { '@type': 'Answer', text: item.a },
    })),
  }
}

export function breadcrumbSchema(crumbs: readonly { name: string; path: string }[]) {
  return {
    '@type': 'BreadcrumbList',
    itemListElement: crumbs.map((c, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      name: c.name,
      item: `${siteConfig.url}${c.path === '/' ? '' : c.path}`,
    })),
  }
}

/** Wraps one or more schema nodes into a single @graph document. */
export function jsonLd(...nodes: Record<string, unknown>[]) {
  return {
    '@context': 'https://schema.org',
    '@graph': nodes,
  }
}
