import { NextResponse, type NextRequest } from 'next/server'

/**
 * /play → /play/
 *
 * The app's Vite build uses `base: './'`, so its assets are requested relative
 * to the current directory. At `/play` the browser resolves `./assets/…`
 * against the site root and every asset 404s; at `/play/` it resolves
 * correctly. So the slashless form has to redirect.
 *
 * This lives in middleware rather than in next.config's `redirects()` for a
 * specific reason: Next normalises the trailing slash when matching a redirect
 * `source`, so a rule written as `/play` also matches `/play/` — and the
 * redirect then fires on its own destination, forever. That is an
 * ERR_TOO_MANY_REDIRECTS loop, and it is invisible until something is actually
 * proxied through it.
 *
 * Middleware sees the exact pathname, so the comparison below is honest: only
 * the slashless form redirects, and `/play/` falls straight through to the
 * rewrite in next.config.ts.
 */
export function middleware(request: NextRequest) {
  if (request.nextUrl.pathname === '/play') {
    // A plain URL, not request.nextUrl.clone(): NextURL re-normalises the
    // trailing slash the moment you assign it, so the clone would redirect
    // /play to /play — a loop with extra steps.
    const target = new URL(request.url)
    target.pathname = '/play/'
    return NextResponse.redirect(target.toString(), 308)
  }
  return NextResponse.next()
}

// Only ever run for this one path. Everything else on the site is static and
// should not pay for a middleware invocation.
export const config = {
  matcher: ['/play', '/play/'],
}
